Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Newline 91:92
Newline 170:171
Newline 235:236
Newline 238:239
Newline 318:319
Newline 399:400
Newline 447:448
Newline 448:449
Fn 449:451
Ident 452:460 text="classify"
LParen 460:461
Ident 461:462 text="d"
Colon 462:463
Ident 464:470 text="string"
Question 470:471
RParen 471:472
Arrow 473:475
Ident 476:482 text="string"
LBrace 483:484
Newline 484:485
Match 489:494
LParen 495:496
Ident 496:497 text="d"
RParen 497:498
LBrace 499:500
Newline 500:501
Case 505:509
None 510:514
Arrow 515:517
Str 518:524 T("none")
Newline 524:525
Case 529:533
Ident 534:538 text="some"
LParen 538:539
Ident 539:540 text="p"
RParen 540:541
If 542:544
Ident 545:548 text="len"
LParen 548:549
Ident 549:550 text="p"
RParen 550:551
Gt 552:553
Number 554:555 text="0" suf="" isf=0 int=0
Arrow 556:558
Str 559:568 T("present")
Newline 568:569
Case 573:577
Ident 578:582 text="some"
LParen 582:583
Ident 583:584 text="_"
RParen 584:585
Arrow 586:588
Str 589:596 T("empty")
Newline 596:597
RBrace 601:602
Newline 602:603
RBrace 603:604
Newline 604:605
Newline 605:606
Fn 606:608
Ident 609:613 text="main"
LParen 613:614
RParen 614:615
LBrace 616:617
Newline 617:618
Var 622:625
Ident 626:627 text="d"
Assign 628:629
Ident 630:641 text="current_dir"
LParen 641:642
RParen 642:643
Newline 643:644
Ident 648:655 text="println"
LParen 655:656
Str 656:664 T("class:")
Comma 664:665
Ident 666:674 text="classify"
LParen 674:675
Ident 675:676 text="d"
RParen 676:677
RParen 677:678
Newline 678:679
Newline 679:680
Newline 759:760
Newline 793:794
Ident 798:805 text="println"
LParen 805:806
Str 806:820 T("class again:")
Comma 820:821
Ident 822:830 text="classify"
LParen 830:831
Ident 831:842 text="current_dir"
LParen 842:843
RParen 843:844
RParen 844:845
RParen 845:846
Newline 846:847
Newline 847:848
Newline 927:928
Newline 1008:1009
Newline 1038:1039
Ident 1043:1050 text="println"
LParen 1050:1051
Str 1051:1058 T("none:")
Comma 1058:1059
Ident 1060:1068 text="classify"
LParen 1068:1069
None 1069:1073
RParen 1073:1074
RParen 1074:1075
Newline 1075:1076
RBrace 1076:1077
Eof 1077:1077
