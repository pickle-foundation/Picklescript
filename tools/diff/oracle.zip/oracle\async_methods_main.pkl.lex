Newline 71:72
Newline 74:75
Newline 150:151
Newline 229:230
Newline 301:302
Newline 375:376
Newline 398:399
Newline 399:400
Class 400:405
Ident 406:417 text="Thermometer"
LBrace 418:419
Newline 419:420
Let 424:427
Ident 428:432 text="base"
Colon 432:433
Ident 434:437 text="int"
Newline 437:438
Newline 438:439
Constructor 443:454
LParen 454:455
Ident 455:459 text="mult"
Colon 459:460
Ident 461:464 text="int"
RParen 464:465
LBrace 466:467
Newline 467:468
This 476:480
Dot 480:481
Ident 481:485 text="base"
Assign 486:487
Ident 488:492 text="mult"
Newline 492:493
RBrace 497:498
Newline 498:499
Newline 499:500
Async 504:509
Fn 510:512
Ident 513:524 text="read_offset"
LParen 524:525
RParen 525:526
Arrow 527:529
Ident 530:533 text="int"
LBrace 534:535
Newline 535:536
This 544:548
Dot 548:549
Ident 549:553 text="base"
Star 554:555
Number 556:558 text="10" suf="" isf=0 int=10
Newline 558:559
RBrace 563:564
Newline 564:565
Newline 565:566
Async 570:575
Fn 576:578
Ident 579:587 text="scale_by"
LParen 587:588
Ident 588:589 text="k"
Colon 589:590
Ident 591:594 text="int"
RParen 594:595
Arrow 596:598
Ident 599:602 text="int"
LBrace 603:604
Newline 604:605
This 613:617
Dot 617:618
Ident 618:622 text="base"
Star 623:624
Ident 625:626 text="k"
Newline 626:627
RBrace 631:632
Newline 632:633
Newline 633:634
Static 638:644
Async 645:650
Fn 651:653
Ident 654:663 text="calibrate"
LParen 663:664
Ident 664:665 text="n"
Colon 665:666
Ident 667:670 text="int"
RParen 670:671
Arrow 672:674
Ident 675:678 text="int"
LBrace 679:680
Newline 680:681
Ident 689:690 text="n"
Plus 691:692
Number 693:694 text="5" suf="" isf=0 int=5
Newline 694:695
RBrace 699:700
Newline 700:701
RBrace 701:702
Newline 702:703
Newline 703:704
Class 704:709
Ident 710:714 text="Ramp"
LBrace 715:716
Newline 716:717
Let 721:724
Ident 725:729 text="step"
Colon 729:730
Ident 731:734 text="int"
Newline 734:735
Newline 735:736
Constructor 740:751
LParen 751:752
Ident 752:756 text="step"
Colon 756:757
Ident 758:761 text="int"
RParen 761:762
LBrace 763:764
Newline 764:765
This 773:777
Dot 777:778
Ident 778:782 text="step"
Assign 783:784
Ident 785:789 text="step"
Newline 789:790
RBrace 794:795
Newline 795:796
Newline 796:797
Async 801:806
Fn 807:809
Ident 810:814 text="tick"
LParen 814:815
Ident 815:818 text="acc"
Colon 818:819
Ident 820:823 text="int"
RParen 823:824
Arrow 825:827
Ident 828:831 text="int"
LBrace 832:833
Newline 833:834
Ident 842:845 text="acc"
Plus 846:847
This 848:852
Dot 852:853
Ident 853:857 text="step"
Newline 857:858
RBrace 862:863
Newline 863:864
Newline 864:865
Async 869:874
Fn 875:877
Ident 878:885 text="current"
LParen 885:886
RParen 886:887
Arrow 888:890
Ident 891:894 text="int"
LBrace 895:896
Newline 896:897
This 905:909
Dot 909:910
Ident 910:914 text="step"
Newline 914:915
RBrace 919:920
Newline 920:921
RBrace 921:922
Newline 922:923
Newline 923:924
Class 924:929
Ident 930:937 text="Stepper"
Extends 938:945
Ident 946:950 text="Ramp"
LBrace 951:952
Newline 952:953
Override 957:965
Async 966:971
Fn 972:974
Ident 975:982 text="current"
LParen 982:983
RParen 983:984
Arrow 985:987
Ident 988:991 text="int"
LBrace 992:993
Newline 993:994
This 1002:1006
Dot 1006:1007
Ident 1007:1011 text="step"
Star 1012:1013
Number 1014:1017 text="100" suf="" isf=0 int=100
Newline 1017:1018
RBrace 1022:1023
Newline 1023:1024
Newline 1024:1025
Override 1029:1037
Async 1038:1043
Fn 1044:1046
Ident 1047:1051 text="tick"
LParen 1051:1052
Ident 1052:1055 text="acc"
Colon 1055:1056
Ident 1057:1060 text="int"
RParen 1060:1061
Arrow 1062:1064
Ident 1065:1068 text="int"
LBrace 1069:1070
Newline 1070:1071
Ident 1079:1082 text="acc"
Plus 1083:1084
This 1085:1089
Dot 1089:1090
Ident 1090:1094 text="step"
Plus 1095:1096
Number 1097:1101 text="1000" suf="" isf=0 int=1000
Newline 1101:1102
RBrace 1106:1107
Newline 1107:1108
RBrace 1108:1109
Newline 1109:1110
Newline 1110:1111
Class 1111:1116
Ident 1117:1122 text="Vault"
Lt 1122:1123
Ident 1123:1124 text="T"
Gt 1124:1125
LBrace 1126:1127
Newline 1127:1128
Let 1132:1135
Ident 1136:1140 text="item"
Colon 1140:1141
Ident 1142:1143 text="T"
Newline 1143:1144
Newline 1144:1145
Constructor 1149:1160
LParen 1160:1161
Ident 1161:1165 text="item"
Colon 1165:1166
Ident 1167:1168 text="T"
RParen 1168:1169
LBrace 1170:1171
Newline 1171:1172
This 1180:1184
Dot 1184:1185
Ident 1185:1189 text="item"
Assign 1190:1191
Ident 1192:1196 text="item"
Newline 1196:1197
RBrace 1201:1202
Newline 1202:1203
Newline 1203:1204
Async 1208:1213
Fn 1214:1216
Ident 1217:1221 text="pick"
LParen 1221:1222
RParen 1222:1223
Arrow 1224:1226
Ident 1227:1228 text="T"
LBrace 1229:1230
Newline 1230:1231
This 1239:1243
Dot 1243:1244
Ident 1244:1248 text="item"
Newline 1248:1249
RBrace 1253:1254
Newline 1254:1255
RBrace 1255:1256
Newline 1256:1257
Newline 1257:1258
Async 1258:1263
Fn 1264:1266
Ident 1267:1275 text="passthru"
Lt 1275:1276
Ident 1276:1277 text="T"
Gt 1277:1278
LParen 1278:1279
Ident 1279:1280 text="v"
Colon 1280:1281
Ident 1282:1283 text="T"
RParen 1283:1284
Arrow 1285:1287
Ident 1288:1289 text="T"
LBrace 1290:1291
Newline 1291:1292
Ident 1296:1297 text="v"
Newline 1297:1298
RBrace 1298:1299
Newline 1299:1300
Newline 1300:1301
Async 1301:1306
Fn 1307:1309
Ident 1310:1313 text="dot"
LParen 1313:1314
Ident 1314:1315 text="a"
Colon 1315:1316
Ident 1317:1320 text="int"
Comma 1320:1321
Ident 1322:1323 text="b"
Colon 1323:1324
Ident 1325:1328 text="int"
RParen 1328:1329
Arrow 1330:1332
Ident 1333:1336 text="int"
LBrace 1337:1338
Newline 1338:1339
Ident 1343:1344 text="a"
Star 1345:1346
Ident 1347:1348 text="b"
Newline 1348:1349
RBrace 1349:1350
Newline 1350:1351
Newline 1351:1352
Fn 1352:1354
Ident 1355:1359 text="main"
LParen 1359:1360
RParen 1360:1361
LBrace 1362:1363
Newline 1363:1364
Let 1368:1371
Ident 1372:1373 text="t"
Assign 1374:1375
Ident 1376:1387 text="Thermometer"
LParen 1387:1388
Number 1388:1389 text="3" suf="" isf=0 int=3
RParen 1389:1390
Newline 1390:1391
Newline 1391:1392
Newline 1464:1465
Newline 1508:1509
Let 1513:1516
Ident 1517:1520 text="off"
Assign 1521:1522
Ident 1523:1524 text="t"
Dot 1524:1525
Ident 1525:1536 text="read_offset"
LParen 1536:1537
RParen 1537:1538
Newline 1538:1539
Ident 1543:1549 text="expect"
LParen 1549:1550
Await 1550:1555
Ident 1556:1559 text="off"
RParen 1559:1560
Dot 1560:1561
Ident 1561:1565 text="toBe"
LParen 1565:1566
Number 1566:1568 text="30" suf="" isf=0 int=30
RParen 1568:1569
Newline 1569:1570
Newline 1570:1571
Ident 1575:1581 text="expect"
LParen 1581:1582
Await 1582:1587
Ident 1588:1589 text="t"
Dot 1589:1590
Ident 1590:1598 text="scale_by"
LParen 1598:1599
Number 1599:1600 text="4" suf="" isf=0 int=4
RParen 1600:1601
RParen 1601:1602
Dot 1602:1603
Ident 1603:1607 text="toBe"
LParen 1607:1608
Number 1608:1610 text="12" suf="" isf=0 int=12
RParen 1610:1611
Newline 1611:1612
Newline 1612:1613
Newline 1639:1640
Ident 1644:1650 text="expect"
LParen 1650:1651
Await 1651:1656
Ident 1657:1668 text="Thermometer"
Dot 1668:1669
Ident 1669:1678 text="calibrate"
LParen 1678:1679
Number 1679:1680 text="2" suf="" isf=0 int=2
RParen 1680:1681
RParen 1681:1682
Dot 1682:1683
Ident 1683:1687 text="toBe"
LParen 1687:1688
Number 1688:1689 text="7" suf="" isf=0 int=7
RParen 1689:1690
Newline 1690:1691
Newline 1691:1692
Newline 1744:1745
Let 1749:1752
Ident 1753:1754 text="r"
Assign 1755:1756
Ident 1757:1761 text="Ramp"
LParen 1761:1762
Number 1762:1763 text="2" suf="" isf=0 int=2
RParen 1763:1764
Newline 1764:1765
Let 1769:1772
Ident 1773:1774 text="s"
Assign 1775:1776
Ident 1777:1784 text="Stepper"
LParen 1784:1785
Number 1785:1786 text="2" suf="" isf=0 int=2
RParen 1786:1787
Newline 1787:1788
Ident 1792:1798 text="expect"
LParen 1798:1799
Await 1799:1804
Ident 1805:1806 text="r"
Dot 1806:1807
Ident 1807:1814 text="current"
LParen 1814:1815
RParen 1815:1816
RParen 1816:1817
Dot 1817:1818
Ident 1818:1822 text="toBe"
LParen 1822:1823
Number 1823:1824 text="2" suf="" isf=0 int=2
RParen 1824:1825
Newline 1825:1826
Ident 1830:1836 text="expect"
LParen 1836:1837
Await 1837:1842
Ident 1843:1844 text="s"
Dot 1844:1845
Ident 1845:1852 text="current"
LParen 1852:1853
RParen 1853:1854
RParen 1854:1855
Dot 1855:1856
Ident 1856:1860 text="toBe"
LParen 1860:1861
Number 1861:1864 text="200" suf="" isf=0 int=200
RParen 1864:1865
Newline 1865:1866
Ident 1870:1876 text="expect"
LParen 1876:1877
Await 1877:1882
Ident 1883:1884 text="s"
Dot 1884:1885
Ident 1885:1889 text="tick"
LParen 1889:1890
Number 1890:1891 text="5" suf="" isf=0 int=5
RParen 1891:1892
RParen 1892:1893
Dot 1893:1894
Ident 1894:1898 text="toBe"
LParen 1898:1899
Number 1899:1903 text="1007" suf="" isf=0 int=1007
RParen 1903:1904
Newline 1904:1905
Newline 1905:1906
Newline 1982:1983
Let 1987:1990
Ident 1991:1992 text="v"
Assign 1993:1994
Ident 1995:2000 text="Vault"
Lt 2000:2001
Ident 2001:2007 text="string"
Gt 2007:2008
LParen 2008:2009
Str 2009:2018 T("pickles")
RParen 2018:2019
Newline 2019:2020
Ident 2024:2030 text="expect"
LParen 2030:2031
Await 2031:2036
Ident 2037:2038 text="v"
Dot 2038:2039
Ident 2039:2043 text="pick"
LParen 2043:2044
RParen 2044:2045
RParen 2045:2046
Dot 2046:2047
Ident 2047:2051 text="toBe"
LParen 2051:2052
Str 2052:2061 T("pickles")
RParen 2061:2062
Newline 2062:2063
Newline 2063:2064
Newline 2123:2124
Ident 2128:2134 text="expect"
LParen 2134:2135
Await 2135:2140
Ident 2141:2149 text="passthru"
Lt 2149:2150
Ident 2150:2153 text="int"
Gt 2153:2154
LParen 2154:2155
Number 2155:2157 text="42" suf="" isf=0 int=42
RParen 2157:2158
RParen 2158:2159
Dot 2159:2160
Ident 2160:2164 text="toBe"
LParen 2164:2165
Number 2165:2167 text="42" suf="" isf=0 int=42
RParen 2167:2168
Newline 2168:2169
Ident 2173:2179 text="expect"
LParen 2179:2180
Await 2180:2185
Ident 2186:2194 text="passthru"
Lt 2194:2195
Ident 2195:2201 text="string"
Gt 2201:2202
LParen 2202:2203
Str 2203:2207 T("ok")
RParen 2207:2208
RParen 2208:2209
Dot 2209:2210
Ident 2210:2214 text="toBe"
LParen 2214:2215
Str 2215:2219 T("ok")
RParen 2219:2220
Newline 2220:2221
Newline 2221:2222
Newline 2296:2297
Let 2301:2304
Ident 2305:2309 text="lazy"
Assign 2310:2311
Async 2312:2317
Fn 2318:2320
LParen 2320:2321
Ident 2321:2322 text="x"
Colon 2322:2323
Ident 2324:2327 text="int"
RParen 2327:2328
Arrow 2329:2331
Ident 2332:2335 text="int"
LBrace 2336:2337
Ident 2338:2339 text="x"
Star 2340:2341
Number 2342:2343 text="2" suf="" isf=0 int=2
RBrace 2344:2345
Newline 2345:2346
Ident 2350:2356 text="expect"
LParen 2356:2357
Await 2357:2362
Ident 2363:2367 text="lazy"
LParen 2367:2368
Number 2368:2370 text="21" suf="" isf=0 int=21
RParen 2370:2371
RParen 2371:2372
Dot 2372:2373
Ident 2373:2377 text="toBe"
LParen 2377:2378
Number 2378:2380 text="42" suf="" isf=0 int=42
RParen 2380:2381
Newline 2381:2382
Newline 2382:2383
Let 2387:2390
Ident 2391:2396 text="outer"
Assign 2397:2398
Number 2399:2400 text="5" suf="" isf=0 int=5
Newline 2400:2401
Let 2405:2408
Ident 2409:2414 text="lazy2"
Assign 2415:2416
Async 2417:2422
Fn 2423:2425
LParen 2425:2426
Ident 2426:2427 text="y"
Colon 2427:2428
Ident 2429:2432 text="int"
RParen 2432:2433
Arrow 2434:2436
Ident 2437:2440 text="int"
LBrace 2441:2442
Ident 2443:2448 text="outer"
Plus 2449:2450
Ident 2451:2452 text="y"
RBrace 2453:2454
Newline 2454:2455
Ident 2459:2465 text="expect"
LParen 2465:2466
Await 2466:2471
Ident 2472:2477 text="lazy2"
LParen 2477:2478
Number 2478:2481 text="100" suf="" isf=0 int=100
RParen 2481:2482
RParen 2482:2483
Dot 2483:2484
Ident 2484:2488 text="toBe"
LParen 2488:2489
Number 2489:2492 text="105" suf="" isf=0 int=105
RParen 2492:2493
Newline 2493:2494
Newline 2494:2495
Newline 2528:2529
Let 2533:2536
Ident 2537:2538 text="z"
Assign 2539:2540
Number 2541:2542 text="9" suf="" isf=0 int=9
Newline 2542:2543
Let 2547:2550
Ident 2551:2552 text="k"
Assign 2553:2554
Async 2555:2560
Fn 2561:2563
LParen 2563:2564
RParen 2564:2565
Arrow 2566:2568
Ident 2569:2572 text="int"
LBrace 2573:2574
Ident 2575:2576 text="z"
Star 2577:2578
Ident 2579:2580 text="z"
RBrace 2581:2582
Newline 2582:2583
Ident 2587:2593 text="expect"
LParen 2593:2594
Await 2594:2599
Ident 2600:2601 text="k"
LParen 2601:2602
RParen 2602:2603
RParen 2603:2604
Dot 2604:2605
Ident 2605:2609 text="toBe"
LParen 2609:2610
Number 2610:2612 text="81" suf="" isf=0 int=81
RParen 2612:2613
Newline 2613:2614
Newline 2614:2615
Newline 2653:2654
Let 2658:2661
Ident 2662:2667 text="greet"
Assign 2668:2669
Async 2670:2675
Fn 2676:2678
LParen 2678:2679
RParen 2679:2680
Arrow 2681:2683
Ident 2684:2690 text="string"
LBrace 2691:2692
Str 2693:2697 T("hi")
RBrace 2698:2699
Newline 2699:2700
Ident 2704:2710 text="expect"
LParen 2710:2711
Await 2711:2716
Ident 2717:2722 text="greet"
LParen 2722:2723
RParen 2723:2724
RParen 2724:2725
Dot 2725:2726
Ident 2726:2730 text="toBe"
LParen 2730:2731
Str 2731:2735 T("hi")
RParen 2735:2736
Newline 2736:2737
Newline 2737:2738
Newline 2768:2769
Let 2773:2776
Ident 2777:2781 text="prod"
Assign 2782:2783
Async 2784:2789
Fn 2790:2792
LParen 2792:2793
Ident 2793:2794 text="a"
Colon 2794:2795
Ident 2796:2799 text="int"
Comma 2799:2800
Ident 2801:2802 text="b"
Colon 2802:2803
Ident 2804:2807 text="int"
RParen 2807:2808
Arrow 2809:2811
Ident 2812:2815 text="int"
FatArrow 2816:2818
Ident 2819:2820 text="a"
Star 2821:2822
Ident 2823:2824 text="b"
Newline 2824:2825
Ident 2829:2835 text="expect"
LParen 2835:2836
Await 2836:2841
Ident 2842:2846 text="prod"
LParen 2846:2847
Number 2847:2848 text="6" suf="" isf=0 int=6
Comma 2848:2849
Number 2850:2851 text="7" suf="" isf=0 int=7
RParen 2851:2852
RParen 2852:2853
Dot 2853:2854
Ident 2854:2858 text="toBe"
LParen 2858:2859
Number 2859:2861 text="42" suf="" isf=0 int=42
RParen 2861:2862
Newline 2862:2863
Newline 2863:2864
Newline 2937:2938
Let 2942:2945
Ident 2946:2950 text="wrap"
Assign 2951:2952
Async 2953:2958
Fn 2959:2961
LParen 2961:2962
Ident 2962:2963 text="a"
Colon 2963:2964
Ident 2965:2968 text="int"
Comma 2968:2969
Ident 2970:2971 text="b"
Colon 2971:2972
Ident 2973:2976 text="int"
RParen 2976:2977
Arrow 2978:2980
Ident 2981:2984 text="int"
LBrace 2985:2986
Await 2987:2992
Ident 2993:2996 text="dot"
LParen 2996:2997
Ident 2997:2998 text="a"
Comma 2998:2999
Ident 3000:3001 text="b"
RParen 3001:3002
Plus 3003:3004
Number 3005:3006 text="1" suf="" isf=0 int=1
RBrace 3007:3008
Newline 3008:3009
Ident 3013:3019 text="expect"
LParen 3019:3020
Await 3020:3025
Ident 3026:3030 text="wrap"
LParen 3030:3031
Number 3031:3032 text="2" suf="" isf=0 int=2
Comma 3032:3033
Number 3034:3035 text="3" suf="" isf=0 int=3
RParen 3035:3036
RParen 3036:3037
Dot 3037:3038
Ident 3038:3042 text="toBe"
LParen 3042:3043
Number 3043:3044 text="7" suf="" isf=0 int=7
RParen 3044:3045
Newline 3045:3046
RBrace 3046:3047
Eof 3047:3047
