Newline 40:41
Newline 43:44
Newline 120:121
Newline 200:201
Newline 281:282
Newline 361:362
Newline 440:441
Newline 480:481
Newline 483:484
Newline 559:560
Newline 636:637
Newline 715:716
Newline 767:768
Newline 768:769
Ident 769:773 text="test"
Fn 774:776
Ident 777:808 text="channels_buffer_values_in_order"
LParen 808:809
RParen 809:810
LBrace 811:812
Newline 812:813
Newline 890:891
Newline 939:940
Let 944:947
Ident 948:950 text="ch"
Assign 951:952
Ident 953:964 text="channel_new"
LParen 964:965
Number 965:966 text="8" suf="" isf=0 int=8
RParen 966:967
Newline 967:968
Ident 972:978 text="expect"
LParen 978:979
Ident 979:990 text="channel_cap"
LParen 990:991
Ident 991:993 text="ch"
RParen 993:994
RParen 994:995
Dot 995:996
Ident 996:1000 text="toBe"
LParen 1000:1001
Number 1001:1002 text="8" suf="" isf=0 int=8
RParen 1002:1003
Newline 1003:1004
Ident 1008:1014 text="expect"
LParen 1014:1015
Ident 1015:1026 text="channel_len"
LParen 1026:1027
Ident 1027:1029 text="ch"
RParen 1029:1030
RParen 1030:1031
Dot 1031:1032
Ident 1032:1036 text="toBe"
LParen 1036:1037
Number 1037:1038 text="0" suf="" isf=0 int=0
RParen 1038:1039
Newline 1039:1040
Ident 1044:1056 text="channel_send"
LParen 1056:1057
Ident 1057:1059 text="ch"
Comma 1059:1060
Number 1061:1063 text="10" suf="" isf=0 int=10
RParen 1063:1064
Newline 1064:1065
Ident 1069:1081 text="channel_send"
LParen 1081:1082
Ident 1082:1084 text="ch"
Comma 1084:1085
Number 1086:1088 text="20" suf="" isf=0 int=20
RParen 1088:1089
Newline 1089:1090
Ident 1094:1106 text="channel_send"
LParen 1106:1107
Ident 1107:1109 text="ch"
Comma 1109:1110
Number 1111:1113 text="30" suf="" isf=0 int=30
RParen 1113:1114
Newline 1114:1115
Ident 1119:1125 text="expect"
LParen 1125:1126
Ident 1126:1137 text="channel_len"
LParen 1137:1138
Ident 1138:1140 text="ch"
RParen 1140:1141
RParen 1141:1142
Dot 1142:1143
Ident 1143:1147 text="toBe"
LParen 1147:1148
Number 1148:1149 text="3" suf="" isf=0 int=3
RParen 1149:1150
Newline 1150:1151
Ident 1155:1161 text="expect"
LParen 1161:1162
Ident 1162:1174 text="channel_recv"
LParen 1174:1175
Ident 1175:1177 text="ch"
RParen 1177:1178
RParen 1178:1179
Dot 1179:1180
Ident 1180:1184 text="toBe"
LParen 1184:1185
Number 1185:1187 text="10" suf="" isf=0 int=10
RParen 1187:1188
Newline 1188:1189
Ident 1193:1199 text="expect"
LParen 1199:1200
Ident 1200:1212 text="channel_recv"
LParen 1212:1213
Ident 1213:1215 text="ch"
RParen 1215:1216
RParen 1216:1217
Dot 1217:1218
Ident 1218:1222 text="toBe"
LParen 1222:1223
Number 1223:1225 text="20" suf="" isf=0 int=20
RParen 1225:1226
Newline 1226:1227
Ident 1231:1237 text="expect"
LParen 1237:1238
Ident 1238:1250 text="channel_recv"
LParen 1250:1251
Ident 1251:1253 text="ch"
RParen 1253:1254
RParen 1254:1255
Dot 1255:1256
Ident 1256:1260 text="toBe"
LParen 1260:1261
Number 1261:1263 text="30" suf="" isf=0 int=30
RParen 1263:1264
Newline 1264:1265
Ident 1269:1275 text="expect"
LParen 1275:1276
Ident 1276:1287 text="channel_len"
LParen 1287:1288
Ident 1288:1290 text="ch"
RParen 1290:1291
RParen 1291:1292
Dot 1292:1293
Ident 1293:1297 text="toBe"
LParen 1297:1298
Number 1298:1299 text="0" suf="" isf=0 int=0
RParen 1299:1300
Newline 1300:1301
RBrace 1301:1302
Newline 1302:1303
Newline 1303:1304
Ident 1304:1308 text="test"
Fn 1309:1311
Ident 1312:1331 text="try_ops_never_block"
LParen 1331:1332
RParen 1332:1333
LBrace 1334:1335
Newline 1335:1336
Newline 1409:1410
Newline 1481:1482
Let 1486:1489
Ident 1490:1492 text="ch"
Assign 1493:1494
Ident 1495:1506 text="channel_new"
LParen 1506:1507
Number 1507:1508 text="1" suf="" isf=0 int=1
RParen 1508:1509
Newline 1509:1510
Ident 1514:1520 text="expect"
LParen 1520:1521
Ident 1521:1537 text="channel_try_send"
LParen 1537:1538
Ident 1538:1540 text="ch"
Comma 1540:1541
Number 1542:1543 text="1" suf="" isf=0 int=1
RParen 1543:1544
RParen 1544:1545
Dot 1545:1546
Ident 1546:1550 text="toBe"
LParen 1550:1551
True 1551:1555
RParen 1555:1556
Newline 1556:1557
Ident 1561:1567 text="expect"
LParen 1567:1568
Ident 1568:1579 text="channel_len"
LParen 1579:1580
Ident 1580:1582 text="ch"
RParen 1582:1583
RParen 1583:1584
Dot 1584:1585
Ident 1585:1589 text="toBe"
LParen 1589:1590
Number 1590:1591 text="1" suf="" isf=0 int=1
RParen 1591:1592
Newline 1592:1593
Ident 1597:1603 text="expect"
LParen 1603:1604
Ident 1604:1620 text="channel_try_send"
LParen 1620:1621
Ident 1621:1623 text="ch"
Comma 1623:1624
Number 1625:1626 text="2" suf="" isf=0 int=2
RParen 1626:1627
RParen 1627:1628
Dot 1628:1629
Ident 1629:1633 text="toBe"
LParen 1633:1634
False 1634:1639
RParen 1639:1640
Newline 1640:1641
If 1645:1647
LParen 1648:1649
Let 1649:1652
Ident 1653:1657 text="some"
LParen 1657:1658
Ident 1658:1659 text="v"
RParen 1659:1660
Assign 1661:1662
Ident 1663:1679 text="channel_try_recv"
LParen 1679:1680
Ident 1680:1682 text="ch"
RParen 1682:1683
RParen 1683:1684
LBrace 1685:1686
Newline 1686:1687
Ident 1695:1701 text="expect"
LParen 1701:1702
Ident 1702:1703 text="v"
RParen 1703:1704
Dot 1704:1705
Ident 1705:1709 text="toBe"
LParen 1709:1710
Number 1710:1711 text="1" suf="" isf=0 int=1
RParen 1711:1712
Newline 1712:1713
RBrace 1717:1718
Else 1719:1723
LBrace 1724:1725
Newline 1725:1726
Ident 1734:1740 text="assert"
LParen 1740:1741
False 1741:1746
Comma 1746:1747
Str 1748:1777 T("expected the buffered value")
RParen 1777:1778
Newline 1778:1779
RBrace 1783:1784
Newline 1784:1785
If 1789:1791
LParen 1792:1793
Let 1793:1796
Ident 1797:1801 text="some"
LParen 1801:1802
Ident 1802:1803 text="v"
RParen 1803:1804
Assign 1805:1806
Ident 1807:1823 text="channel_try_recv"
LParen 1823:1824
Ident 1824:1826 text="ch"
RParen 1826:1827
RParen 1827:1828
LBrace 1829:1830
Newline 1830:1831
Ident 1839:1845 text="assert"
LParen 1845:1846
False 1846:1851
Comma 1851:1852
Str 1853:1888 T("expected none on an empty channel")
RParen 1888:1889
Newline 1889:1890
RBrace 1894:1895
Newline 1895:1896
Ident 1900:1906 text="expect"
LParen 1906:1907
Ident 1907:1918 text="channel_len"
LParen 1918:1919
Ident 1919:1921 text="ch"
RParen 1921:1922
RParen 1922:1923
Dot 1923:1924
Ident 1924:1928 text="toBe"
LParen 1928:1929
Number 1929:1930 text="0" suf="" isf=0 int=0
RParen 1930:1931
Newline 1931:1932
RBrace 1932:1933
Newline 1933:1934
Newline 1934:1935
Ident 1935:1939 text="test"
Fn 1940:1942
Ident 1943:1992 text="a_blocked_receive_hands_the_lock_back_to_a_sender"
LParen 1992:1993
RParen 1993:1994
LBrace 1995:1996
Newline 1996:1997
Newline 2072:2073
Newline 2148:2149
Newline 2215:2216
Let 2220:2223
Ident 2224:2226 text="ch"
Assign 2227:2228
Ident 2229:2240 text="channel_new"
LParen 2240:2241
Number 2241:2242 text="1" suf="" isf=0 int=1
RParen 2242:2243
Newline 2243:2244
Let 2248:2251
Ident 2252:2256 text="seen"
Assign 2257:2258
Ident 2259:2269 text="atomic_new"
LParen 2269:2270
Number 2270:2271 text="0" suf="" isf=0 int=0
RParen 2271:2272
Newline 2272:2273
Let 2277:2280
Ident 2281:2282 text="t"
Assign 2283:2284
Ident 2285:2297 text="thread_spawn"
LParen 2297:2298
Fn 2298:2300
LParen 2300:2301
RParen 2301:2302
LBrace 2303:2304
Newline 2304:2305
Let 2313:2316
Ident 2317:2318 text="v"
Assign 2319:2320
Ident 2321:2333 text="channel_recv"
LParen 2333:2334
Ident 2334:2336 text="ch"
RParen 2336:2337
Newline 2337:2338
Ident 2346:2358 text="atomic_store"
LParen 2358:2359
Ident 2359:2363 text="seen"
Comma 2363:2364
Ident 2365:2366 text="v"
RParen 2366:2367
Newline 2367:2368
RBrace 2372:2373
RParen 2373:2374
Newline 2374:2375
Ident 2379:2387 text="sleep_ms"
LParen 2387:2388
Number 2388:2389 text="5" suf="" isf=0 int=5
RParen 2389:2390
Newline 2390:2391
Ident 2395:2407 text="channel_send"
LParen 2407:2408
Ident 2408:2410 text="ch"
Comma 2410:2411
Number 2412:2413 text="7" suf="" isf=0 int=7
RParen 2413:2414
Newline 2414:2415
Ident 2419:2425 text="expect"
LParen 2425:2426
Ident 2426:2437 text="thread_join"
LParen 2437:2438
Ident 2438:2439 text="t"
RParen 2439:2440
RParen 2440:2441
Dot 2441:2442
Ident 2442:2446 text="toBe"
LParen 2446:2447
True 2447:2451
RParen 2451:2452
Newline 2452:2453
Ident 2457:2463 text="expect"
LParen 2463:2464
Ident 2464:2475 text="atomic_load"
LParen 2475:2476
Ident 2476:2480 text="seen"
RParen 2480:2481
RParen 2481:2482
Dot 2482:2483
Ident 2483:2487 text="toBe"
LParen 2487:2488
Number 2488:2489 text="7" suf="" isf=0 int=7
RParen 2489:2490
Newline 2490:2491
RBrace 2491:2492
Newline 2492:2493
Newline 2493:2494
Ident 2494:2498 text="test"
Fn 2499:2501
Ident 2502:2548 text="a_blocked_send_hands_the_lock_back_to_a_reader"
LParen 2548:2549
RParen 2549:2550
LBrace 2551:2552
Newline 2552:2553
Newline 2630:2631
Newline 2696:2697
Let 2701:2704
Ident 2705:2707 text="ch"
Assign 2708:2709
Ident 2710:2721 text="channel_new"
LParen 2721:2722
Number 2722:2723 text="2" suf="" isf=0 int=2
RParen 2723:2724
Newline 2724:2725
Ident 2729:2741 text="channel_send"
LParen 2741:2742
Ident 2742:2744 text="ch"
Comma 2744:2745
Number 2746:2747 text="1" suf="" isf=0 int=1
RParen 2747:2748
Newline 2748:2749
Ident 2753:2765 text="channel_send"
LParen 2765:2766
Ident 2766:2768 text="ch"
Comma 2768:2769
Number 2770:2771 text="2" suf="" isf=0 int=2
RParen 2771:2772
Newline 2772:2773
Let 2777:2780
Ident 2781:2782 text="t"
Assign 2783:2784
Ident 2785:2797 text="thread_spawn"
LParen 2797:2798
Fn 2798:2800
LParen 2800:2801
RParen 2801:2802
LBrace 2803:2804
Ident 2805:2817 text="channel_send"
LParen 2817:2818
Ident 2818:2820 text="ch"
Comma 2820:2821
Number 2822:2823 text="3" suf="" isf=0 int=3
RParen 2823:2824
RBrace 2825:2826
RParen 2826:2827
Newline 2827:2828
Ident 2832:2838 text="expect"
LParen 2838:2839
Ident 2839:2851 text="channel_recv"
LParen 2851:2852
Ident 2852:2854 text="ch"
RParen 2854:2855
RParen 2855:2856
Dot 2856:2857
Ident 2857:2861 text="toBe"
LParen 2861:2862
Number 2862:2863 text="1" suf="" isf=0 int=1
RParen 2863:2864
Newline 2864:2865
Ident 2869:2875 text="expect"
LParen 2875:2876
Ident 2876:2887 text="thread_join"
LParen 2887:2888
Ident 2888:2889 text="t"
RParen 2889:2890
RParen 2890:2891
Dot 2891:2892
Ident 2892:2896 text="toBe"
LParen 2896:2897
True 2897:2901
RParen 2901:2902
Newline 2902:2903
Ident 2907:2913 text="expect"
LParen 2913:2914
Ident 2914:2926 text="channel_recv"
LParen 2926:2927
Ident 2927:2929 text="ch"
RParen 2929:2930
RParen 2930:2931
Dot 2931:2932
Ident 2932:2936 text="toBe"
LParen 2936:2937
Number 2937:2938 text="2" suf="" isf=0 int=2
RParen 2938:2939
Newline 2939:2940
Ident 2944:2950 text="expect"
LParen 2950:2951
Ident 2951:2963 text="channel_recv"
LParen 2963:2964
Ident 2964:2966 text="ch"
RParen 2966:2967
RParen 2967:2968
Dot 2968:2969
Ident 2969:2973 text="toBe"
LParen 2973:2974
Number 2974:2975 text="3" suf="" isf=0 int=3
RParen 2975:2976
Newline 2976:2977
RBrace 2977:2978
Newline 2978:2979
Newline 2979:2980
Ident 2980:2984 text="test"
Fn 2985:2987
Ident 2988:3038 text="close_marks_the_channel_but_keeps_what_is_buffered"
LParen 3038:3039
RParen 3039:3040
LBrace 3041:3042
Newline 3042:3043
Newline 3116:3117
Newline 3195:3196
Newline 3276:3277
Let 3281:3284
Ident 3285:3287 text="ch"
Assign 3288:3289
Ident 3290:3301 text="channel_new"
LParen 3301:3302
Number 3302:3303 text="4" suf="" isf=0 int=4
RParen 3303:3304
Newline 3304:3305
Ident 3309:3321 text="channel_send"
LParen 3321:3322
Ident 3322:3324 text="ch"
Comma 3324:3325
Number 3326:3327 text="1" suf="" isf=0 int=1
RParen 3327:3328
Newline 3328:3329
Ident 3333:3345 text="channel_send"
LParen 3345:3346
Ident 3346:3348 text="ch"
Comma 3348:3349
Number 3350:3351 text="2" suf="" isf=0 int=2
RParen 3351:3352
Newline 3352:3353
Ident 3357:3363 text="expect"
LParen 3363:3364
Ident 3364:3378 text="channel_closed"
LParen 3378:3379
Ident 3379:3381 text="ch"
RParen 3381:3382
RParen 3382:3383
Dot 3383:3384
Ident 3384:3388 text="toBe"
LParen 3388:3389
False 3389:3394
RParen 3394:3395
Newline 3395:3396
Ident 3400:3413 text="channel_close"
LParen 3413:3414
Ident 3414:3416 text="ch"
RParen 3416:3417
Newline 3417:3418
Ident 3422:3428 text="expect"
LParen 3428:3429
Ident 3429:3443 text="channel_closed"
LParen 3443:3444
Ident 3444:3446 text="ch"
RParen 3446:3447
RParen 3447:3448
Dot 3448:3449
Ident 3449:3453 text="toBe"
LParen 3453:3454
True 3454:3458
RParen 3458:3459
Newline 3459:3460
Ident 3464:3470 text="expect"
LParen 3470:3471
Ident 3471:3483 text="channel_recv"
LParen 3483:3484
Ident 3484:3486 text="ch"
RParen 3486:3487
RParen 3487:3488
Dot 3488:3489
Ident 3489:3493 text="toBe"
LParen 3493:3494
Number 3494:3495 text="1" suf="" isf=0 int=1
RParen 3495:3496
Newline 3496:3497
Ident 3501:3507 text="expect"
LParen 3507:3508
Ident 3508:3520 text="channel_recv"
LParen 3520:3521
Ident 3521:3523 text="ch"
RParen 3523:3524
RParen 3524:3525
Dot 3525:3526
Ident 3526:3530 text="toBe"
LParen 3530:3531
Number 3531:3532 text="2" suf="" isf=0 int=2
RParen 3532:3533
Newline 3533:3534
Ident 3538:3544 text="expect"
LParen 3544:3545
Ident 3545:3556 text="channel_len"
LParen 3556:3557
Ident 3557:3559 text="ch"
RParen 3559:3560
RParen 3560:3561
Dot 3561:3562
Ident 3562:3566 text="toBe"
LParen 3566:3567
Number 3567:3568 text="0" suf="" isf=0 int=0
RParen 3568:3569
Newline 3569:3570
If 3574:3576
LParen 3577:3578
Let 3578:3581
Ident 3582:3586 text="some"
LParen 3586:3587
Ident 3587:3588 text="_"
RParen 3588:3589
Assign 3590:3591
Ident 3592:3608 text="channel_try_recv"
LParen 3608:3609
Ident 3609:3611 text="ch"
RParen 3611:3612
RParen 3612:3613
LBrace 3614:3615
Newline 3615:3616
Ident 3624:3630 text="assert"
LParen 3630:3631
False 3631:3636
Comma 3636:3637
Str 3638:3685 T("expected a closed, empty channel to read none")
RParen 3685:3686
Newline 3686:3687
RBrace 3691:3692
Newline 3692:3693
Ident 3697:3703 text="expect"
LParen 3703:3704
Ident 3704:3718 text="channel_closed"
LParen 3718:3719
Ident 3719:3721 text="ch"
RParen 3721:3722
RParen 3722:3723
Dot 3723:3724
Ident 3724:3728 text="toBe"
LParen 3728:3729
True 3729:3733
RParen 3733:3734
Newline 3734:3735
RBrace 3735:3736
Eof 3736:3736
