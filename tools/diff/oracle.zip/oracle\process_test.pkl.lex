Ident 0:4 text="test"
Fn 5:7
Ident 8:25 text="proc_capture_echo"
LParen 25:26
RParen 26:27
LBrace 28:29
Newline 29:30
Let 34:37
Ident 38:39 text="r"
Assign 40:41
Ident 42:49 text="run_cmd"
LParen 49:50
LBracket 50:51
Str 51:60 T("cmd.exe")
Comma 60:61
Str 62:66 T("/c")
Comma 66:67
Str 68:74 T("echo")
Comma 74:75
Str 76:89 T("hello world")
RBracket 89:90
Comma 90:91
None 92:96
Comma 96:97
None 98:102
Comma 102:103
None 104:108
Comma 108:109
None 110:114
Comma 114:115
None 116:120
Comma 120:121
None 122:126
Comma 126:127
False 128:133
RParen 133:134
Newline 134:135
Match 139:144
LParen 145:146
Ident 146:147 text="r"
RParen 147:148
LBrace 149:150
Newline 150:151
Case 159:163
Ident 164:168 text="some"
LParen 168:169
LParen 169:170
Ident 170:174 text="code"
Comma 174:175
Ident 176:179 text="out"
Comma 179:180
Ident 181:184 text="err"
Comma 184:185
Ident 186:191 text="timed"
RParen 191:192
RParen 192:193
Arrow 194:196
LBrace 197:198
Newline 198:199
If 211:213
LParen 214:215
Let 215:218
Ident 219:223 text="some"
LParen 223:224
Ident 224:225 text="c"
RParen 225:226
Assign 227:228
Ident 229:233 text="code"
RParen 233:234
LBrace 235:236
Newline 236:237
Ident 253:259 text="expect"
LParen 259:260
Ident 260:261 text="c"
RParen 261:262
Dot 262:263
Ident 263:267 text="toBe"
LParen 267:268
Number 268:269 text="0" suf="" isf=0 int=0
RParen 269:270
Newline 270:271
RBrace 283:284
Else 285:289
LBrace 290:291
Newline 291:292
Ident 308:314 text="expect"
LParen 314:315
Str 315:327 T("unexpected")
RParen 327:328
Dot 328:329
Ident 329:333 text="toBe"
LParen 333:334
Str 334:372 T("echo exited without a code (signal?)")
RParen 372:373
Newline 373:374
RBrace 386:387
Newline 387:388
Ident 400:406 text="expect"
LParen 406:407
Ident 407:412 text="timed"
RParen 412:413
Dot 413:414
Ident 414:418 text="toBe"
LParen 418:419
False 419:424
RParen 424:425
Newline 425:426
Ident 438:444 text="expect"
LParen 444:445
Ident 445:457 text="str_contains"
LParen 457:458
Ident 458:461 text="out"
Comma 461:462
Str 463:476 T("hello world")
RParen 476:477
RParen 477:478
Dot 478:479
Ident 479:483 text="toBe"
LParen 483:484
True 484:488
RParen 488:489
Newline 489:490
RBrace 498:499
Newline 499:500
Case 508:512
None 513:517
Arrow 518:520
Ident 521:527 text="expect"
LParen 527:528
Str 528:540 T("unexpected")
RParen 540:541
Dot 541:542
Ident 542:546 text="toBe"
LParen 546:547
Str 547:574 T("echo could not be spawned")
RParen 574:575
Newline 575:576
RBrace 580:581
Newline 581:582
RBrace 582:583
Newline 583:584
Newline 584:585
Ident 585:589 text="test"
Fn 590:592
Ident 593:618 text="proc_capture_nonzero_exit"
LParen 618:619
RParen 619:620
LBrace 621:622
Newline 622:623
Let 627:630
Ident 631:632 text="r"
Assign 633:634
Ident 635:642 text="run_cmd"
LParen 642:643
LBracket 643:644
Str 644:653 T("cmd.exe")
Comma 653:654
Str 655:659 T("/c")
Comma 659:660
Str 661:667 T("exit")
Comma 667:668
Str 669:672 T("7")
RBracket 672:673
Comma 673:674
None 675:679
Comma 679:680
None 681:685
Comma 685:686
None 687:691
Comma 691:692
None 693:697
Comma 697:698
None 699:703
Comma 703:704
None 705:709
Comma 709:710
False 711:716
RParen 716:717
Newline 717:718
Match 722:727
LParen 728:729
Ident 729:730 text="r"
RParen 730:731
LBrace 732:733
Newline 733:734
Case 742:746
Ident 747:751 text="some"
LParen 751:752
LParen 752:753
Ident 753:757 text="code"
Comma 757:758
Ident 759:762 text="out"
Comma 762:763
Ident 764:767 text="err"
Comma 767:768
Ident 769:774 text="timed"
RParen 774:775
RParen 775:776
Arrow 777:779
LBrace 780:781
Newline 781:782
If 794:796
LParen 797:798
Let 798:801
Ident 802:806 text="some"
LParen 806:807
Ident 807:808 text="c"
RParen 808:809
Assign 810:811
Ident 812:816 text="code"
RParen 816:817
LBrace 818:819
Newline 819:820
Ident 836:842 text="expect"
LParen 842:843
Ident 843:844 text="c"
RParen 844:845
Dot 845:846
Ident 846:850 text="toBe"
LParen 850:851
Number 851:852 text="7" suf="" isf=0 int=7
RParen 852:853
Newline 853:854
RBrace 866:867
Else 868:872
LBrace 873:874
Newline 874:875
Ident 891:897 text="expect"
LParen 897:898
Str 898:910 T("unexpected")
RParen 910:911
Dot 911:912
Ident 912:916 text="toBe"
LParen 916:917
Str 917:942 T("exit 7 reported no code")
RParen 942:943
Newline 943:944
RBrace 956:957
Newline 957:958
Ident 970:976 text="expect"
LParen 976:977
Ident 977:982 text="timed"
RParen 982:983
Dot 983:984
Ident 984:988 text="toBe"
LParen 988:989
False 989:994
RParen 994:995
Newline 995:996
RBrace 1004:1005
Newline 1005:1006
Case 1014:1018
None 1019:1023
Arrow 1024:1026
Ident 1027:1033 text="expect"
LParen 1033:1034
Str 1034:1046 T("unexpected")
RParen 1046:1047
Dot 1047:1048
Ident 1048:1052 text="toBe"
LParen 1052:1053
Str 1053:1080 T("exit could not be spawned")
RParen 1080:1081
Newline 1081:1082
RBrace 1086:1087
Newline 1087:1088
RBrace 1088:1089
Newline 1089:1090
Newline 1090:1091
Ident 1091:1095 text="test"
Fn 1096:1098
Ident 1099:1115 text="proc_capture_env"
LParen 1115:1116
RParen 1116:1117
LBrace 1118:1119
Newline 1119:1120
Let 1124:1127
Ident 1128:1132 text="envs"
Assign 1133:1134
LBrace 1135:1136
Str 1136:1148 T("PICKLE_TST")
Colon 1148:1149
Str 1150:1154 T("42")
RBrace 1154:1155
Newline 1155:1156
Let 1160:1163
Ident 1164:1165 text="r"
Assign 1166:1167
Ident 1168:1175 text="run_cmd"
LParen 1175:1176
LBracket 1176:1177
Str 1177:1186 T("cmd.exe")
Comma 1186:1187
Str 1188:1192 T("/c")
Comma 1192:1193
Str 1194:1200 T("echo")
Comma 1200:1201
Str 1202:1216 T("%PICKLE_TST%")
RBracket 1216:1217
Comma 1217:1218
None 1219:1223
Comma 1223:1224
Ident 1225:1229 text="envs"
Comma 1229:1230
None 1231:1235
Comma 1235:1236
None 1237:1241
Comma 1241:1242
None 1243:1247
Comma 1247:1248
None 1249:1253
Comma 1253:1254
False 1255:1260
RParen 1260:1261
Newline 1261:1262
Match 1266:1271
LParen 1272:1273
Ident 1273:1274 text="r"
RParen 1274:1275
LBrace 1276:1277
Newline 1277:1278
Case 1286:1290
Ident 1291:1295 text="some"
LParen 1295:1296
LParen 1296:1297
Ident 1297:1302 text="_code"
Comma 1302:1303
Ident 1304:1307 text="out"
Comma 1307:1308
Ident 1309:1313 text="_err"
Comma 1313:1314
Ident 1315:1321 text="_timed"
RParen 1321:1322
RParen 1322:1323
Arrow 1324:1326
Ident 1327:1333 text="expect"
LParen 1333:1334
Ident 1334:1346 text="str_contains"
LParen 1346:1347
Ident 1347:1350 text="out"
Comma 1350:1351
Str 1352:1356 T("42")
RParen 1356:1357
RParen 1357:1358
Dot 1358:1359
Ident 1359:1363 text="toBe"
LParen 1363:1364
True 1364:1368
RParen 1368:1369
Newline 1369:1370
Case 1378:1382
None 1383:1387
Arrow 1388:1390
Ident 1391:1397 text="expect"
LParen 1397:1398
Str 1398:1410 T("unexpected")
RParen 1410:1411
Dot 1411:1412
Ident 1412:1416 text="toBe"
LParen 1416:1417
Str 1417:1448 T("env echo could not be spawned")
RParen 1448:1449
Newline 1449:1450
RBrace 1454:1455
Newline 1455:1456
RBrace 1456:1457
Newline 1457:1458
Newline 1458:1459
Ident 1459:1463 text="test"
Fn 1464:1466
Ident 1467:1483 text="proc_capture_cwd"
LParen 1483:1484
RParen 1484:1485
LBrace 1486:1487
Newline 1487:1488
Let 1492:1495
Ident 1496:1497 text="r"
Assign 1498:1499
Ident 1500:1507 text="run_cmd"
LParen 1507:1508
LBracket 1508:1509
Str 1509:1518 T("cmd.exe")
Comma 1518:1519
Str 1520:1524 T("/c")
Comma 1524:1525
Str 1526:1530 T("cd")
RBracket 1530:1531
Comma 1531:1532
Str 1533:1547 T("tests/pickle")
Comma 1547:1548
None 1549:1553
Comma 1553:1554
None 1555:1559
Comma 1559:1560
None 1561:1565
Comma 1565:1566
None 1567:1571
Comma 1571:1572
None 1573:1577
Comma 1577:1578
False 1579:1584
RParen 1584:1585
Newline 1585:1586
Match 1590:1595
LParen 1596:1597
Ident 1597:1598 text="r"
RParen 1598:1599
LBrace 1600:1601
Newline 1601:1602
Case 1610:1614
Ident 1615:1619 text="some"
LParen 1619:1620
LParen 1620:1621
Ident 1621:1626 text="_code"
Comma 1626:1627
Ident 1628:1631 text="out"
Comma 1631:1632
Ident 1633:1637 text="_err"
Comma 1637:1638
Ident 1639:1645 text="_timed"
RParen 1645:1646
RParen 1646:1647
Arrow 1648:1650
Ident 1651:1657 text="expect"
LParen 1657:1658
Ident 1658:1670 text="str_contains"
LParen 1670:1671
Ident 1671:1674 text="out"
Comma 1674:1675
Str 1676:1684 T("pickle")
RParen 1684:1685
RParen 1685:1686
Dot 1686:1687
Ident 1687:1691 text="toBe"
LParen 1691:1692
True 1692:1696
RParen 1696:1697
Newline 1697:1698
Case 1706:1710
None 1711:1715
Arrow 1716:1718
Ident 1719:1725 text="expect"
LParen 1725:1726
Str 1726:1738 T("unexpected")
RParen 1738:1739
Dot 1739:1740
Ident 1740:1744 text="toBe"
LParen 1744:1745
Str 1745:1770 T("cd could not be spawned")
RParen 1770:1771
Newline 1771:1772
RBrace 1776:1777
Newline 1777:1778
RBrace 1778:1779
Newline 1779:1780
Newline 1780:1781
Ident 1781:1785 text="test"
Fn 1786:1788
Ident 1789:1807 text="proc_capture_stdin"
LParen 1807:1808
RParen 1808:1809
LBrace 1810:1811
Newline 1811:1812
Let 1816:1819
Ident 1820:1821 text="r"
Assign 1822:1823
Ident 1824:1831 text="run_cmd"
LParen 1831:1832
LBracket 1832:1833
Str 1833:1842 T("cmd.exe")
Comma 1842:1843
Str 1844:1848 T("/c")
Comma 1848:1849
Str 1850:1859 T("findstr")
Comma 1859:1860
Str 1861:1865 T(".*")
RBracket 1865:1866
Comma 1866:1867
None 1868:1872
Comma 1872:1873
None 1874:1878
Comma 1878:1879
None 1880:1884
Comma 1884:1885
Ident 1886:1891 text="bytes"
LParen 1891:1892
Str 1892:1905 T("hello stdin")
RParen 1905:1906
Comma 1906:1907
None 1908:1912
Comma 1912:1913
None 1914:1918
Comma 1918:1919
False 1920:1925
RParen 1925:1926
Newline 1926:1927
Match 1931:1936
LParen 1937:1938
Ident 1938:1939 text="r"
RParen 1939:1940
LBrace 1941:1942
Newline 1942:1943
Case 1951:1955
Ident 1956:1960 text="some"
LParen 1960:1961
LParen 1961:1962
Ident 1962:1966 text="code"
Comma 1966:1967
Ident 1968:1971 text="out"
Comma 1971:1972
Ident 1973:1977 text="_err"
Comma 1977:1978
Ident 1979:1985 text="_timed"
RParen 1985:1986
RParen 1986:1987
Arrow 1988:1990
LBrace 1991:1992
Newline 1992:1993
If 2005:2007
LParen 2008:2009
Let 2009:2012
Ident 2013:2017 text="some"
LParen 2017:2018
Ident 2018:2019 text="c"
RParen 2019:2020
Assign 2021:2022
Ident 2023:2027 text="code"
RParen 2027:2028
LBrace 2029:2030
Newline 2030:2031
Ident 2047:2053 text="expect"
LParen 2053:2054
Ident 2054:2055 text="c"
RParen 2055:2056
Dot 2056:2057
Ident 2057:2061 text="toBe"
LParen 2061:2062
Number 2062:2063 text="0" suf="" isf=0 int=0
RParen 2063:2064
Newline 2064:2065
RBrace 2077:2078
Else 2079:2083
LBrace 2084:2085
Newline 2085:2086
Ident 2102:2108 text="expect"
LParen 2108:2109
Str 2109:2121 T("unexpected")
RParen 2121:2122
Dot 2122:2123
Ident 2123:2127 text="toBe"
LParen 2127:2128
Str 2128:2159 T("findstr exited without a code")
RParen 2159:2160
Newline 2160:2161
RBrace 2173:2174
Newline 2174:2175
Ident 2187:2193 text="expect"
LParen 2193:2194
Ident 2194:2206 text="str_contains"
LParen 2206:2207
Ident 2207:2210 text="out"
Comma 2210:2211
Str 2212:2225 T("hello stdin")
RParen 2225:2226
RParen 2226:2227
Dot 2227:2228
Ident 2228:2232 text="toBe"
LParen 2232:2233
True 2233:2237
RParen 2237:2238
Newline 2238:2239
RBrace 2247:2248
Newline 2248:2249
Case 2257:2261
None 2262:2266
Arrow 2267:2269
Ident 2270:2276 text="expect"
LParen 2276:2277
Str 2277:2289 T("unexpected")
RParen 2289:2290
Dot 2290:2291
Ident 2291:2295 text="toBe"
LParen 2295:2296
Str 2296:2326 T("findstr could not be spawned")
RParen 2326:2327
Newline 2327:2328
RBrace 2332:2333
Newline 2333:2334
RBrace 2334:2335
Newline 2335:2336
Newline 2336:2337
Ident 2337:2341 text="test"
Fn 2342:2344
Ident 2345:2365 text="proc_capture_timeout"
LParen 2365:2366
RParen 2366:2367
LBrace 2368:2369
Newline 2369:2370
Let 2374:2377
Ident 2378:2379 text="r"
Assign 2380:2381
Ident 2382:2389 text="run_cmd"
LParen 2389:2390
LBracket 2390:2391
Str 2391:2400 T("cmd.exe")
Comma 2400:2401
Str 2402:2406 T("/c")
Comma 2406:2407
Str 2408:2414 T("ping")
Comma 2414:2415
Str 2416:2420 T("-n")
Comma 2420:2421
Str 2422:2426 T("20")
Comma 2426:2427
Str 2428:2439 T("127.0.0.1")
RBracket 2439:2440
Comma 2440:2441
None 2442:2446
Comma 2446:2447
None 2448:2452
Comma 2452:2453
None 2454:2458
Comma 2458:2459
None 2460:2464
Comma 2464:2465
None 2466:2470
Comma 2470:2471
Number 2472:2475 text="300" suf="" isf=0 int=300
Comma 2475:2476
False 2477:2482
RParen 2482:2483
Newline 2483:2484
Match 2488:2493
LParen 2494:2495
Ident 2495:2496 text="r"
RParen 2496:2497
LBrace 2498:2499
Newline 2499:2500
Case 2508:2512
Ident 2513:2517 text="some"
LParen 2517:2518
LParen 2518:2519
Ident 2519:2524 text="_code"
Comma 2524:2525
Ident 2526:2530 text="_out"
Comma 2530:2531
Ident 2532:2536 text="_err"
Comma 2536:2537
Ident 2538:2543 text="timed"
RParen 2543:2544
RParen 2544:2545
Arrow 2546:2548
Ident 2549:2555 text="expect"
LParen 2555:2556
Ident 2556:2561 text="timed"
RParen 2561:2562
Dot 2562:2563
Ident 2563:2567 text="toBe"
LParen 2567:2568
True 2568:2572
RParen 2572:2573
Newline 2573:2574
Case 2582:2586
None 2587:2591
Arrow 2592:2594
Ident 2595:2601 text="expect"
LParen 2601:2602
Str 2602:2614 T("unexpected")
RParen 2614:2615
Dot 2615:2616
Ident 2616:2620 text="toBe"
LParen 2620:2621
Str 2621:2648 T("ping could not be spawned")
RParen 2648:2649
Newline 2649:2650
RBrace 2654:2655
Newline 2655:2656
RBrace 2656:2657
Newline 2657:2658
Newline 2658:2659
Ident 2659:2663 text="test"
Fn 2664:2666
Ident 2667:2701 text="proc_capture_spawn_failure_is_none"
LParen 2701:2702
RParen 2702:2703
LBrace 2704:2705
Newline 2705:2706
Let 2710:2713
Ident 2714:2715 text="r"
Assign 2716:2717
Ident 2718:2725 text="run_cmd"
LParen 2725:2726
LBracket 2726:2727
Str 2727:2754 T("_no_such_program_xyz_123_")
RBracket 2754:2755
Comma 2755:2756
None 2757:2761
Comma 2761:2762
None 2763:2767
Comma 2767:2768
None 2769:2773
Comma 2773:2774
None 2775:2779
Comma 2779:2780
None 2781:2785
Comma 2785:2786
None 2787:2791
Comma 2791:2792
False 2793:2798
RParen 2798:2799
Newline 2799:2800
If 2804:2806
LParen 2807:2808
Let 2808:2811
Ident 2812:2816 text="some"
LParen 2816:2817
Ident 2817:2819 text="_t"
RParen 2819:2820
Assign 2821:2822
Ident 2823:2824 text="r"
RParen 2824:2825
LBrace 2826:2827
Newline 2827:2828
Ident 2836:2842 text="expect"
LParen 2842:2843
Str 2843:2855 T("unexpected")
RParen 2855:2856
Dot 2856:2857
Ident 2857:2861 text="toBe"
LParen 2861:2862
Str 2862:2897 T("missing program reported a result")
RParen 2897:2898
Newline 2898:2899
RBrace 2903:2904
Else 2905:2909
LBrace 2910:2911
Newline 2911:2912
Ident 2920:2926 text="expect"
LParen 2926:2927
True 2927:2931
RParen 2931:2932
Dot 2932:2933
Ident 2933:2937 text="toBe"
LParen 2937:2938
True 2938:2942
RParen 2942:2943
Newline 2943:2944
RBrace 2948:2949
Newline 2949:2950
RBrace 2950:2951
Newline 2951:2952
Newline 2952:2953
Ident 2953:2957 text="test"
Fn 2958:2960
Ident 2961:2997 text="proc_inherit_io_reports_empty_output"
LParen 2997:2998
RParen 2998:2999
LBrace 3000:3001
Newline 3001:3002
Let 3006:3009
Ident 3010:3011 text="r"
Assign 3012:3013
Ident 3014:3021 text="run_cmd"
LParen 3021:3022
LBracket 3022:3023
Str 3023:3032 T("cmd.exe")
Comma 3032:3033
Str 3034:3038 T("/c")
Comma 3038:3039
Str 3040:3046 T("echo")
Comma 3046:3047
Str 3048:3059 T("inherited")
RBracket 3059:3060
Comma 3060:3061
None 3062:3066
Comma 3066:3067
None 3068:3072
Comma 3072:3073
None 3074:3078
Comma 3078:3079
None 3080:3084
Comma 3084:3085
None 3086:3090
Comma 3090:3091
None 3092:3096
Comma 3096:3097
True 3098:3102
RParen 3102:3103
Newline 3103:3104
Match 3108:3113
LParen 3114:3115
Ident 3115:3116 text="r"
RParen 3116:3117
LBrace 3118:3119
Newline 3119:3120
Case 3128:3132
Ident 3133:3137 text="some"
LParen 3137:3138
LParen 3138:3139
Ident 3139:3143 text="code"
Comma 3143:3144
Ident 3145:3148 text="out"
Comma 3148:3149
Ident 3150:3153 text="err"
Comma 3153:3154
Ident 3155:3160 text="timed"
RParen 3160:3161
RParen 3161:3162
Arrow 3163:3165
LBrace 3166:3167
Newline 3167:3168
If 3180:3182
LParen 3183:3184
Let 3184:3187
Ident 3188:3192 text="some"
LParen 3192:3193
Ident 3193:3194 text="c"
RParen 3194:3195
Assign 3196:3197
Ident 3198:3202 text="code"
RParen 3202:3203
LBrace 3204:3205
Newline 3205:3206
Ident 3222:3228 text="expect"
LParen 3228:3229
Ident 3229:3230 text="c"
RParen 3230:3231
Dot 3231:3232
Ident 3232:3236 text="toBe"
LParen 3236:3237
Number 3237:3238 text="0" suf="" isf=0 int=0
RParen 3238:3239
Newline 3239:3240
RBrace 3252:3253
Else 3254:3258
LBrace 3259:3260
Newline 3260:3261
Ident 3277:3283 text="expect"
LParen 3283:3284
Str 3284:3296 T("unexpected")
RParen 3296:3297
Dot 3297:3298
Ident 3298:3302 text="toBe"
LParen 3302:3303
Str 3303:3336 T("inherited echo reported no code")
RParen 3336:3337
Newline 3337:3338
RBrace 3350:3351
Newline 3351:3352
Ident 3364:3370 text="expect"
LParen 3370:3371
Ident 3371:3374 text="len"
LParen 3374:3375
Ident 3375:3380 text="bytes"
LParen 3380:3381
Ident 3381:3384 text="out"
RParen 3384:3385
RParen 3385:3386
RParen 3386:3387
Dot 3387:3388
Ident 3388:3392 text="toBe"
LParen 3392:3393
Number 3393:3394 text="0" suf="" isf=0 int=0
RParen 3394:3395
Newline 3395:3396
Ident 3408:3414 text="expect"
LParen 3414:3415
Ident 3415:3418 text="len"
LParen 3418:3419
Ident 3419:3424 text="bytes"
LParen 3424:3425
Ident 3425:3428 text="err"
RParen 3428:3429
RParen 3429:3430
RParen 3430:3431
Dot 3431:3432
Ident 3432:3436 text="toBe"
LParen 3436:3437
Number 3437:3438 text="0" suf="" isf=0 int=0
RParen 3438:3439
Newline 3439:3440
Ident 3452:3458 text="expect"
LParen 3458:3459
Ident 3459:3464 text="timed"
RParen 3464:3465
Dot 3465:3466
Ident 3466:3470 text="toBe"
LParen 3470:3471
False 3471:3476
RParen 3476:3477
Newline 3477:3478
RBrace 3486:3487
Newline 3487:3488
Case 3496:3500
None 3501:3505
Arrow 3506:3508
Ident 3509:3515 text="expect"
LParen 3515:3516
Str 3516:3528 T("unexpected")
RParen 3528:3529
Dot 3529:3530
Ident 3530:3534 text="toBe"
LParen 3534:3535
Str 3535:3572 T("inherited echo could not be spawned")
RParen 3572:3573
Newline 3573:3574
RBrace 3578:3579
Newline 3579:3580
RBrace 3580:3581
Newline 3581:3582
Newline 3582:3583
Ident 3583:3587 text="test"
Fn 3588:3590
Ident 3591:3615 text="proc_current_dir_is_some"
LParen 3615:3616
RParen 3616:3617
LBrace 3618:3619
Newline 3619:3620
Let 3624:3627
Ident 3628:3629 text="c"
Assign 3630:3631
Ident 3632:3643 text="current_dir"
LParen 3643:3644
RParen 3644:3645
Newline 3645:3646
If 3650:3652
LParen 3653:3654
Let 3654:3657
Ident 3658:3662 text="some"
LParen 3662:3663
Ident 3663:3666 text="dir"
RParen 3666:3667
Assign 3668:3669
Ident 3670:3671 text="c"
RParen 3671:3672
LBrace 3673:3674
Newline 3674:3675
Ident 3683:3689 text="expect"
LParen 3689:3690
Ident 3690:3693 text="len"
LParen 3693:3694
Ident 3694:3699 text="bytes"
LParen 3699:3700
Ident 3700:3703 text="dir"
RParen 3703:3704
RParen 3704:3705
Gt 3706:3707
Number 3708:3709 text="0" suf="" isf=0 int=0
RParen 3709:3710
Dot 3710:3711
Ident 3711:3715 text="toBe"
LParen 3715:3716
True 3716:3720
RParen 3720:3721
Newline 3721:3722
RBrace 3726:3727
Else 3728:3732
LBrace 3733:3734
Newline 3734:3735
Ident 3743:3749 text="expect"
LParen 3749:3750
Str 3750:3762 T("unexpected")
RParen 3762:3763
Dot 3763:3764
Ident 3764:3768 text="toBe"
LParen 3768:3769
Str 3769:3796 T("current_dir returned none")
RParen 3796:3797
Newline 3797:3798
RBrace 3802:3803
Newline 3803:3804
RBrace 3804:3805
Newline 3805:3806
Newline 3806:3807
Ident 3807:3811 text="test"
Fn 3812:3814
Ident 3815:3839 text="proc_spawn_async_capture"
LParen 3839:3840
RParen 3840:3841
LBrace 3842:3843
Newline 3843:3844
Let 3848:3851
Ident 3852:3853 text="h"
Assign 3854:3855
Ident 3856:3865 text="run_spawn"
LParen 3865:3866
LBracket 3866:3867
Str 3867:3876 T("cmd.exe")
Comma 3876:3877
Str 3878:3882 T("/c")
Comma 3882:3883
Str 3884:3890 T("ping")
Comma 3890:3891
Str 3892:3896 T("-n")
Comma 3896:3897
Str 3898:3901 T("4")
Comma 3901:3902
Str 3903:3914 T("127.0.0.1")
RBracket 3914:3915
Comma 3915:3916
None 3917:3921
Comma 3921:3922
None 3923:3927
Comma 3927:3928
None 3929:3933
Comma 3933:3934
None 3935:3939
RParen 3939:3940
Newline 3940:3941
If 3945:3947
LParen 3948:3949
Let 3949:3952
Ident 3953:3957 text="some"
LParen 3957:3958
Ident 3958:3964 text="stream"
RParen 3964:3965
Assign 3966:3967
Ident 3968:3969 text="h"
RParen 3969:3970
LBrace 3971:3972
Newline 3972:3973
Ident 3981:3987 text="expect"
LParen 3987:3988
Ident 3988:3997 text="proc_wait"
LParen 3997:3998
Ident 3998:4004 text="stream"
RParen 4004:4005
RParen 4005:4006
Dot 4006:4007
Ident 4007:4011 text="toBe"
LParen 4011:4012
True 4012:4016
RParen 4016:4017
Newline 4017:4018
Let 4026:4029
Ident 4030:4034 text="code"
Assign 4035:4036
Ident 4037:4046 text="proc_code"
LParen 4046:4047
Ident 4047:4053 text="stream"
RParen 4053:4054
Newline 4054:4055
If 4063:4065
LParen 4066:4067
Let 4067:4070
Ident 4071:4075 text="some"
LParen 4075:4076
Ident 4076:4077 text="c"
RParen 4077:4078
Assign 4079:4080
Ident 4081:4085 text="code"
RParen 4085:4086
LBrace 4087:4088
Newline 4088:4089
Ident 4101:4107 text="expect"
LParen 4107:4108
Ident 4108:4109 text="c"
RParen 4109:4110
Dot 4110:4111
Ident 4111:4115 text="toBe"
LParen 4115:4116
Number 4116:4117 text="0" suf="" isf=0 int=0
RParen 4117:4118
Newline 4118:4119
RBrace 4127:4128
Else 4129:4133
LBrace 4134:4135
Newline 4135:4136
Ident 4148:4154 text="expect"
LParen 4154:4155
Str 4155:4167 T("unexpected")
RParen 4167:4168
Dot 4168:4169
Ident 4169:4173 text="toBe"
LParen 4173:4174
Str 4174:4216 T("spawned ping reported no code after wait")
RParen 4216:4217
Newline 4217:4218
RBrace 4226:4227
Newline 4227:4228
Ident 4236:4242 text="expect"
LParen 4242:4243
Ident 4243:4255 text="proc_running"
LParen 4255:4256
Ident 4256:4262 text="stream"
RParen 4262:4263
RParen 4263:4264
Dot 4264:4265
Ident 4265:4269 text="toBe"
LParen 4269:4270
False 4270:4275
RParen 4275:4276
Newline 4276:4277
Newline 4347:4348
Ident 4356:4362 text="expect"
LParen 4362:4363
Ident 4363:4376 text="proc_in_close"
LParen 4376:4377
Ident 4377:4383 text="stream"
RParen 4383:4384
RParen 4384:4385
Dot 4385:4386
Ident 4386:4390 text="toBe"
LParen 4390:4391
True 4391:4395
RParen 4395:4396
Newline 4396:4397
RBrace 4401:4402
Else 4403:4407
LBrace 4408:4409
Newline 4409:4410
Ident 4418:4424 text="expect"
LParen 4424:4425
Str 4425:4437 T("unexpected")
RParen 4437:4438
Dot 4438:4439
Ident 4439:4443 text="toBe"
LParen 4443:4444
Str 4444:4486 T("ping could not be spawned with run_spawn")
RParen 4486:4487
Newline 4487:4488
RBrace 4492:4493
Newline 4493:4494
RBrace 4494:4495
Newline 4495:4496
Newline 4496:4497
Ident 4497:4501 text="test"
Fn 4502:4504
Ident 4505:4532 text="proc_spawn_interleaved_read"
LParen 4532:4533
RParen 4533:4534
LBrace 4535:4536
Newline 4536:4537
Newline 4608:4609
Newline 4685:4686
Let 4690:4693
Ident 4694:4695 text="h"
Assign 4696:4697
Ident 4698:4707 text="run_spawn"
LParen 4707:4708
LBracket 4708:4709
Str 4709:4718 T("cmd.exe")
Comma 4718:4719
Str 4720:4724 T("/c")
Comma 4724:4725
Str 4726:4732 T("echo")
Comma 4732:4733
Str 4734:4741 T("alpha")
Comma 4741:4742
Str 4743:4746 T("&")
Comma 4746:4747
Str 4748:4754 T("ping")
Comma 4754:4755
Str 4756:4760 T("-n")
Comma 4760:4761
Str 4762:4765 T("3")
Comma 4765:4766
Str 4767:4778 T("127.0.0.1")
Comma 4778:4779
Str 4780:4783 T("&")
Comma 4783:4784
Str 4785:4791 T("echo")
Comma 4791:4792
Str 4793:4799 T("beta")
RBracket 4799:4800
Comma 4800:4801
None 4802:4806
Comma 4806:4807
None 4808:4812
Comma 4812:4813
None 4814:4818
Comma 4818:4819
Number 4820:4824 text="4096" suf="" isf=0 int=4096
RParen 4824:4825
Newline 4825:4826
If 4830:4832
LParen 4833:4834
Let 4834:4837
Ident 4838:4842 text="some"
LParen 4842:4843
Ident 4843:4849 text="stream"
RParen 4849:4850
Assign 4851:4852
Ident 4853:4854 text="h"
RParen 4854:4855
LBrace 4856:4857
Newline 4857:4858
Ident 4866:4872 text="expect"
LParen 4872:4873
Ident 4873:4885 text="proc_running"
LParen 4885:4886
Ident 4886:4892 text="stream"
RParen 4892:4893
RParen 4893:4894
Dot 4894:4895
Ident 4895:4899 text="toBe"
LParen 4899:4900
True 4900:4904
RParen 4904:4905
Newline 4905:4906
Var 4914:4917
Ident 4918:4921 text="out"
Assign 4922:4923
Str 4924:4926
Newline 4926:4927
Var 4935:4938
Ident 4939:4944 text="guard"
Assign 4945:4946
Number 4947:4948 text="0" suf="" isf=0 int=0
Newline 4948:4949
Newline 5021:5022
Newline 5095:5096
Newline 5166:5167
While 5175:5180
LParen 5181:5182
Ident 5182:5187 text="guard"
Lt 5188:5189
Number 5190:5197 text="1000000" suf="" isf=0 int=1000000
AndAnd 5198:5200
Ident 5201:5213 text="proc_running"
LParen 5213:5214
Ident 5214:5220 text="stream"
RParen 5220:5221
RParen 5221:5222
LBrace 5223:5224
Newline 5224:5225
Let 5237:5240
Ident 5241:5246 text="chunk"
Assign 5247:5248
Ident 5249:5262 text="proc_out_read"
LParen 5262:5263
Ident 5263:5269 text="stream"
Comma 5269:5270
Number 5271:5274 text="512" suf="" isf=0 int=512
RParen 5274:5275
Newline 5275:5276
If 5288:5290
LParen 5291:5292
Let 5292:5295
Ident 5296:5300 text="some"
LParen 5300:5301
Ident 5301:5303 text="bs"
RParen 5303:5304
Assign 5305:5306
Ident 5307:5312 text="chunk"
RParen 5312:5313
LBrace 5314:5315
Newline 5315:5316
If 5332:5334
LParen 5335:5336
Ident 5336:5339 text="len"
LParen 5339:5340
Ident 5340:5342 text="bs"
RParen 5342:5343
Gt 5344:5345
Number 5346:5347 text="0" suf="" isf=0 int=0
RParen 5347:5348
LBrace 5349:5350
Newline 5350:5351
Ident 5371:5374 text="out"
Assign 5375:5376
Str 5377:5393 E[Ident 5379:5382 text="out"; Eof 5383:5383] E[Ident 5384:5387 text="str"; LParen 5387:5388; Ident 5388:5390 text="bs"; RParen 5390:5391; Eof 5392:5392]
Newline 5393:5394
RBrace 5410:5411
Newline 5411:5412
RBrace 5424:5425
Newline 5425:5426
Ident 5438:5443 text="guard"
PlusEq 5444:5446
Number 5447:5448 text="1" suf="" isf=0 int=1
Newline 5448:5449
RBrace 5457:5458
Newline 5458:5459
Ident 5467:5473 text="expect"
LParen 5473:5474
Ident 5474:5483 text="proc_wait"
LParen 5483:5484
Ident 5484:5490 text="stream"
RParen 5490:5491
RParen 5491:5492
Dot 5492:5493
Ident 5493:5497 text="toBe"
LParen 5497:5498
True 5498:5502
RParen 5502:5503
Newline 5503:5504
Let 5512:5515
Ident 5516:5520 text="code"
Assign 5521:5522
Ident 5523:5532 text="proc_code"
LParen 5532:5533
Ident 5533:5539 text="stream"
RParen 5539:5540
Newline 5540:5541
If 5549:5551
LParen 5552:5553
Let 5553:5556
Ident 5557:5561 text="some"
LParen 5561:5562
Ident 5562:5563 text="c"
RParen 5563:5564
Assign 5565:5566
Ident 5567:5571 text="code"
RParen 5571:5572
LBrace 5573:5574
Newline 5574:5575
Ident 5587:5593 text="expect"
LParen 5593:5594
Ident 5594:5595 text="c"
RParen 5595:5596
Dot 5596:5597
Ident 5597:5601 text="toBe"
LParen 5601:5602
Number 5602:5603 text="0" suf="" isf=0 int=0
RParen 5603:5604
Newline 5604:5605
RBrace 5613:5614
Else 5615:5619
LBrace 5620:5621
Newline 5621:5622
Ident 5634:5640 text="expect"
LParen 5640:5641
Str 5641:5653 T("unexpected")
RParen 5653:5654
Dot 5654:5655
Ident 5655:5659 text="toBe"
LParen 5659:5660
Str 5660:5695 T("interleaved ping reported no code")
RParen 5695:5696
Newline 5696:5697
RBrace 5705:5706
Newline 5706:5707
Newline 5784:5785
Newline 5829:5830
Var 5838:5841
Ident 5842:5849 text="saw_eof"
Assign 5850:5851
False 5852:5857
Newline 5857:5858
Var 5866:5869
Ident 5870:5876 text="guard2"
Assign 5877:5878
Number 5879:5880 text="0" suf="" isf=0 int=0
Newline 5880:5881
While 5889:5894
LParen 5895:5896
Ident 5896:5902 text="guard2"
Lt 5903:5904
Number 5905:5910 text="20000" suf="" isf=0 int=20000
RParen 5910:5911
LBrace 5912:5913
Newline 5913:5914
Let 5926:5929
Ident 5930:5935 text="chunk"
Assign 5936:5937
Ident 5938:5951 text="proc_out_read"
LParen 5951:5952
Ident 5952:5958 text="stream"
Comma 5958:5959
Number 5960:5963 text="512" suf="" isf=0 int=512
RParen 5963:5964
Newline 5964:5965
If 5977:5979
LParen 5980:5981
Let 5981:5984
Ident 5985:5989 text="some"
LParen 5989:5990
Ident 5990:5992 text="bs"
RParen 5992:5993
Assign 5994:5995
Ident 5996:6001 text="chunk"
RParen 6001:6002
LBrace 6003:6004
Newline 6004:6005
If 6021:6023
LParen 6024:6025
Ident 6025:6028 text="len"
LParen 6028:6029
Ident 6029:6031 text="bs"
RParen 6031:6032
Gt 6033:6034
Number 6035:6036 text="0" suf="" isf=0 int=0
RParen 6036:6037
LBrace 6038:6039
Newline 6039:6040
Ident 6060:6063 text="out"
Assign 6064:6065
Str 6066:6082 E[Ident 6068:6071 text="out"; Eof 6072:6072] E[Ident 6073:6076 text="str"; LParen 6076:6077; Ident 6077:6079 text="bs"; RParen 6079:6080; Eof 6081:6081]
Newline 6082:6083
RBrace 6099:6100
Newline 6100:6101
RBrace 6113:6114
Else 6115:6119
LBrace 6120:6121
Newline 6121:6122
Ident 6138:6145 text="saw_eof"
Assign 6146:6147
True 6148:6152
Newline 6152:6153
Ident 6169:6175 text="guard2"
Assign 6176:6177
Number 6178:6183 text="20000" suf="" isf=0 int=20000
Newline 6183:6184
RBrace 6196:6197
Newline 6197:6198
Ident 6210:6216 text="guard2"
PlusEq 6217:6219
Number 6220:6221 text="1" suf="" isf=0 int=1
Newline 6221:6222
RBrace 6230:6231
Newline 6231:6232
Ident 6240:6246 text="expect"
LParen 6246:6247
Ident 6247:6254 text="saw_eof"
RParen 6254:6255
Dot 6255:6256
Ident 6256:6260 text="toBe"
LParen 6260:6261
True 6261:6265
RParen 6265:6266
Newline 6266:6267
Ident 6275:6281 text="expect"
LParen 6281:6282
Ident 6282:6294 text="str_contains"
LParen 6294:6295
Ident 6295:6298 text="out"
Comma 6298:6299
Str 6300:6307 T("alpha")
RParen 6307:6308
RParen 6308:6309
Dot 6309:6310
Ident 6310:6314 text="toBe"
LParen 6314:6315
True 6315:6319
RParen 6319:6320
Newline 6320:6321
Ident 6329:6335 text="expect"
LParen 6335:6336
Ident 6336:6348 text="str_contains"
LParen 6348:6349
Ident 6349:6352 text="out"
Comma 6352:6353
Str 6354:6360 T("beta")
RParen 6360:6361
RParen 6361:6362
Dot 6362:6363
Ident 6363:6367 text="toBe"
LParen 6367:6368
True 6368:6372
RParen 6372:6373
Newline 6373:6374
RBrace 6378:6379
Else 6380:6384
LBrace 6385:6386
Newline 6386:6387
Ident 6395:6401 text="expect"
LParen 6401:6402
Str 6402:6414 T("unexpected")
RParen 6414:6415
Dot 6415:6416
Ident 6416:6420 text="toBe"
LParen 6420:6421
Str 6421:6460 T("interleaved ping could not be spawned")
RParen 6460:6461
Newline 6461:6462
RBrace 6466:6467
Newline 6467:6468
RBrace 6468:6469
Newline 6469:6470
Newline 6470:6471
Ident 6471:6475 text="test"
Fn 6476:6478
Ident 6479:6505 text="proc_spawn_stdin_roundtrip"
LParen 6505:6506
RParen 6506:6507
LBrace 6508:6509
Newline 6509:6510
Let 6514:6517
Ident 6518:6519 text="h"
Assign 6520:6521
Ident 6522:6531 text="run_spawn"
LParen 6531:6532
LBracket 6532:6533
Str 6533:6542 T("cmd.exe")
Comma 6542:6543
Str 6544:6548 T("/c")
Comma 6548:6549
Str 6550:6559 T("findstr")
Comma 6559:6560
Str 6561:6565 T(".*")
RBracket 6565:6566
Comma 6566:6567
None 6568:6572
Comma 6572:6573
None 6574:6578
Comma 6578:6579
None 6580:6584
Comma 6584:6585
Number 6586:6590 text="4096" suf="" isf=0 int=4096
RParen 6590:6591
Newline 6591:6592
If 6596:6598
LParen 6599:6600
Let 6600:6603
Ident 6604:6608 text="some"
LParen 6608:6609
Ident 6609:6615 text="stream"
RParen 6615:6616
Assign 6617:6618
Ident 6619:6620 text="h"
RParen 6620:6621
LBrace 6622:6623
Newline 6623:6624
Ident 6632:6638 text="expect"
LParen 6638:6639
Ident 6639:6652 text="proc_in_write"
LParen 6652:6653
Ident 6653:6659 text="stream"
Comma 6659:6660
Ident 6661:6666 text="bytes"
LParen 6666:6667
Str 6667:6679 T("async pipe")
RParen 6679:6680
RParen 6680:6681
RParen 6681:6682
Dot 6682:6683
Ident 6683:6687 text="toBe"
LParen 6687:6688
Number 6688:6690 text="10" suf="" isf=0 int=10
RParen 6690:6691
Newline 6691:6692
Ident 6700:6706 text="expect"
LParen 6706:6707
Ident 6707:6720 text="proc_in_close"
LParen 6720:6721
Ident 6721:6727 text="stream"
RParen 6727:6728
RParen 6728:6729
Dot 6729:6730
Ident 6730:6734 text="toBe"
LParen 6734:6735
True 6735:6739
RParen 6739:6740
Newline 6740:6741
Ident 6749:6755 text="expect"
LParen 6755:6756
Ident 6756:6765 text="proc_wait"
LParen 6765:6766
Ident 6766:6772 text="stream"
RParen 6772:6773
RParen 6773:6774
Dot 6774:6775
Ident 6775:6779 text="toBe"
LParen 6779:6780
True 6780:6784
RParen 6784:6785
Newline 6785:6786
Let 6794:6797
Ident 6798:6802 text="code"
Assign 6803:6804
Ident 6805:6814 text="proc_code"
LParen 6814:6815
Ident 6815:6821 text="stream"
RParen 6821:6822
Newline 6822:6823
If 6831:6833
LParen 6834:6835
Let 6835:6838
Ident 6839:6843 text="some"
LParen 6843:6844
Ident 6844:6845 text="c"
RParen 6845:6846
Assign 6847:6848
Ident 6849:6853 text="code"
RParen 6853:6854
LBrace 6855:6856
Newline 6856:6857
Ident 6869:6875 text="expect"
LParen 6875:6876
Ident 6876:6877 text="c"
RParen 6877:6878
Dot 6878:6879
Ident 6879:6883 text="toBe"
LParen 6883:6884
Number 6884:6885 text="0" suf="" isf=0 int=0
RParen 6885:6886
Newline 6886:6887
RBrace 6895:6896
Else 6897:6901
LBrace 6902:6903
Newline 6903:6904
Ident 6916:6922 text="expect"
LParen 6922:6923
Str 6923:6935 T("unexpected")
RParen 6935:6936
Dot 6936:6937
Ident 6937:6941 text="toBe"
LParen 6941:6942
Str 6942:6974 T("async findstr reported no code")
RParen 6974:6975
Newline 6975:6976
RBrace 6984:6985
Newline 6985:6986
Newline 7060:7061
Var 7069:7072
Ident 7073:7076 text="out"
Assign 7077:7078
Str 7079:7081
Newline 7081:7082
Var 7090:7093
Ident 7094:7099 text="found"
Assign 7100:7101
False 7102:7107
Newline 7107:7108
Var 7116:7119
Ident 7120:7125 text="guard"
Assign 7126:7127
Number 7128:7129 text="0" suf="" isf=0 int=0
Newline 7129:7130
While 7138:7143
LParen 7144:7145
Ident 7145:7150 text="guard"
Lt 7151:7152
Number 7153:7158 text="10000" suf="" isf=0 int=10000
RParen 7158:7159
LBrace 7160:7161
Newline 7161:7162
Let 7174:7177
Ident 7178:7183 text="chunk"
Assign 7184:7185
Ident 7186:7199 text="proc_out_read"
LParen 7199:7200
Ident 7200:7206 text="stream"
Comma 7206:7207
Number 7208:7211 text="128" suf="" isf=0 int=128
RParen 7211:7212
Newline 7212:7213
If 7225:7227
LParen 7228:7229
Let 7229:7232
Ident 7233:7237 text="some"
LParen 7237:7238
Ident 7238:7240 text="bs"
RParen 7240:7241
Assign 7242:7243
Ident 7244:7249 text="chunk"
RParen 7249:7250
LBrace 7251:7252
Newline 7252:7253
If 7269:7271
LParen 7272:7273
Ident 7273:7276 text="len"
LParen 7276:7277
Ident 7277:7279 text="bs"
RParen 7279:7280
Gt 7281:7282
Number 7283:7284 text="0" suf="" isf=0 int=0
RParen 7284:7285
LBrace 7286:7287
Newline 7287:7288
Ident 7308:7311 text="out"
Assign 7312:7313
Str 7314:7330 E[Ident 7316:7319 text="out"; Eof 7320:7320] E[Ident 7321:7324 text="str"; LParen 7324:7325; Ident 7325:7327 text="bs"; RParen 7327:7328; Eof 7329:7329]
Newline 7330:7331
If 7351:7353
LParen 7354:7355
Ident 7355:7367 text="str_contains"
LParen 7367:7368
Ident 7368:7371 text="out"
Comma 7371:7372
Str 7373:7385 T("async pipe")
RParen 7385:7386
RParen 7386:7387
LBrace 7388:7389
Newline 7389:7390
Ident 7414:7419 text="found"
Assign 7420:7421
True 7422:7426
Newline 7426:7427
RBrace 7447:7448
Newline 7448:7449
RBrace 7465:7466
Newline 7466:7467
RBrace 7479:7480
Newline 7480:7481
Ident 7493:7498 text="guard"
PlusEq 7499:7501
Number 7502:7503 text="1" suf="" isf=0 int=1
Newline 7503:7504
RBrace 7512:7513
Newline 7513:7514
Ident 7522:7528 text="expect"
LParen 7528:7529
Ident 7529:7534 text="found"
RParen 7534:7535
Dot 7535:7536
Ident 7536:7540 text="toBe"
LParen 7540:7541
True 7541:7545
RParen 7545:7546
Newline 7546:7547
RBrace 7551:7552
Else 7553:7557
LBrace 7558:7559
Newline 7559:7560
Ident 7568:7574 text="expect"
LParen 7574:7575
Str 7575:7587 T("unexpected")
RParen 7587:7588
Dot 7588:7589
Ident 7589:7593 text="toBe"
LParen 7593:7594
Str 7594:7630 T("async findstr could not be spawned")
RParen 7630:7631
Newline 7631:7632
RBrace 7636:7637
Newline 7637:7638
RBrace 7638:7639
Newline 7639:7640
Newline 7640:7641
Ident 7641:7645 text="test"
Fn 7646:7648
Ident 7649:7670 text="proc_spawn_kill_later"
LParen 7670:7671
RParen 7671:7672
LBrace 7673:7674
Newline 7674:7675
Let 7679:7682
Ident 7683:7684 text="h"
Assign 7685:7686
Ident 7687:7696 text="run_spawn"
LParen 7696:7697
LBracket 7697:7698
Str 7698:7707 T("cmd.exe")
Comma 7707:7708
Str 7709:7713 T("/c")
Comma 7713:7714
Str 7715:7721 T("ping")
Comma 7721:7722
Str 7723:7727 T("-n")
Comma 7727:7728
Str 7729:7733 T("60")
Comma 7733:7734
Str 7735:7746 T("127.0.0.1")
RBracket 7746:7747
Comma 7747:7748
None 7749:7753
Comma 7753:7754
None 7755:7759
Comma 7759:7760
None 7761:7765
Comma 7765:7766
None 7767:7771
RParen 7771:7772
Newline 7772:7773
If 7777:7779
LParen 7780:7781
Let 7781:7784
Ident 7785:7789 text="some"
LParen 7789:7790
Ident 7790:7796 text="stream"
RParen 7796:7797
Assign 7798:7799
Ident 7800:7801 text="h"
RParen 7801:7802
LBrace 7803:7804
Newline 7804:7805
Ident 7813:7819 text="expect"
LParen 7819:7820
Ident 7820:7832 text="proc_running"
LParen 7832:7833
Ident 7833:7839 text="stream"
RParen 7839:7840
RParen 7840:7841
Dot 7841:7842
Ident 7842:7846 text="toBe"
LParen 7846:7847
True 7847:7851
RParen 7851:7852
Newline 7852:7853
Ident 7861:7867 text="expect"
LParen 7867:7868
Ident 7868:7877 text="proc_kill"
LParen 7877:7878
Ident 7878:7884 text="stream"
RParen 7884:7885
RParen 7885:7886
Dot 7886:7887
Ident 7887:7891 text="toBe"
LParen 7891:7892
True 7892:7896
RParen 7896:7897
Newline 7897:7898
Ident 7906:7912 text="expect"
LParen 7912:7913
Ident 7913:7922 text="proc_wait"
LParen 7922:7923
Ident 7923:7929 text="stream"
RParen 7929:7930
RParen 7930:7931
Dot 7931:7932
Ident 7932:7936 text="toBe"
LParen 7936:7937
True 7937:7941
RParen 7941:7942
Newline 7942:7943
Ident 7951:7957 text="expect"
LParen 7957:7958
Ident 7958:7970 text="proc_running"
LParen 7970:7971
Ident 7971:7977 text="stream"
RParen 7977:7978
RParen 7978:7979
Dot 7979:7980
Ident 7980:7984 text="toBe"
LParen 7984:7985
False 7985:7990
RParen 7990:7991
Newline 7991:7992
RBrace 7996:7997
Else 7998:8002
LBrace 8003:8004
Newline 8004:8005
Ident 8013:8019 text="expect"
LParen 8019:8020
Str 8020:8032 T("unexpected")
RParen 8032:8033
Dot 8033:8034
Ident 8034:8038 text="toBe"
LParen 8038:8039
Str 8039:8073 T("kill target could not be spawned")
RParen 8073:8074
Newline 8074:8075
RBrace 8079:8080
Newline 8080:8081
RBrace 8081:8082
Newline 8082:8083
Newline 8083:8084
Fn 8084:8086
Ident 8087:8099 text="str_contains"
LParen 8099:8100
Ident 8100:8101 text="s"
Colon 8101:8102
Ident 8103:8109 text="string"
Comma 8109:8110
Ident 8111:8114 text="sub"
Colon 8114:8115
Ident 8116:8122 text="string"
RParen 8122:8123
Colon 8123:8124
Ident 8125:8129 text="bool"
LBrace 8130:8131
Newline 8131:8132
Let 8136:8139
Ident 8140:8142 text="sb"
Assign 8143:8144
Ident 8145:8150 text="bytes"
LParen 8150:8151
Ident 8151:8154 text="sub"
RParen 8154:8155
Newline 8155:8156
Let 8160:8163
Ident 8164:8167 text="sbl"
Assign 8168:8169
Ident 8170:8173 text="len"
LParen 8173:8174
Ident 8174:8176 text="sb"
RParen 8176:8177
Newline 8177:8178
If 8182:8184
LParen 8185:8186
Ident 8186:8189 text="sbl"
EqEq 8190:8192
Number 8193:8194 text="0" suf="" isf=0 int=0
RParen 8194:8195
LBrace 8196:8197
Newline 8197:8198
Return 8206:8212
True 8213:8217
Newline 8217:8218
RBrace 8222:8223
Newline 8223:8224
Let 8228:8231
Ident 8232:8233 text="b"
Assign 8234:8235
Ident 8236:8241 text="bytes"
LParen 8241:8242
Ident 8242:8243 text="s"
RParen 8243:8244
Newline 8244:8245
Var 8249:8252
Ident 8253:8254 text="i"
Assign 8255:8256
Number 8257:8258 text="0" suf="" isf=0 int=0
Newline 8258:8259
While 8263:8268
LParen 8269:8270
Ident 8270:8271 text="i"
Plus 8272:8273
Ident 8274:8277 text="sbl"
Le 8278:8280
Ident 8281:8284 text="len"
LParen 8284:8285
Ident 8285:8286 text="b"
RParen 8286:8287
RParen 8287:8288
LBrace 8289:8290
Newline 8290:8291
Var 8299:8302
Ident 8303:8304 text="j"
Assign 8305:8306
Number 8307:8308 text="0" suf="" isf=0 int=0
Newline 8308:8309
Var 8317:8320
Ident 8321:8323 text="ok"
Assign 8324:8325
True 8326:8330
Newline 8330:8331
While 8339:8344
LParen 8345:8346
Ident 8346:8347 text="j"
Lt 8348:8349
Ident 8350:8353 text="sbl"
RParen 8353:8354
LBrace 8355:8356
Newline 8356:8357
If 8369:8371
LParen 8372:8373
Ident 8373:8374 text="b"
LBracket 8374:8375
Ident 8375:8376 text="i"
Plus 8377:8378
Ident 8379:8380 text="j"
RBracket 8380:8381
NotEq 8382:8384
Ident 8385:8387 text="sb"
LBracket 8387:8388
Ident 8388:8389 text="j"
RBracket 8389:8390
RParen 8390:8391
LBrace 8392:8393
Newline 8393:8394
Ident 8410:8412 text="ok"
Assign 8413:8414
False 8415:8420
Newline 8420:8421
RBrace 8433:8434
Newline 8434:8435
Ident 8447:8448 text="j"
PlusEq 8449:8451
Number 8452:8453 text="1" suf="" isf=0 int=1
Newline 8453:8454
RBrace 8462:8463
Newline 8463:8464
If 8472:8474
LParen 8475:8476
Ident 8476:8478 text="ok"
RParen 8478:8479
LBrace 8480:8481
Newline 8481:8482
Return 8494:8500
True 8501:8505
Newline 8505:8506
RBrace 8514:8515
Newline 8515:8516
Ident 8524:8525 text="i"
PlusEq 8526:8528
Number 8529:8530 text="1" suf="" isf=0 int=1
Newline 8530:8531
RBrace 8535:8536
Newline 8536:8537
Return 8541:8547
False 8548:8553
Newline 8553:8554
RBrace 8554:8555
Eof 8555:8555
