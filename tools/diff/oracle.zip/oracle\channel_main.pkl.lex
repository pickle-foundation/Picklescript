Newline 59:60
Newline 62:63
Newline 143:144
Newline 221:222
Newline 298:299
Newline 374:375
Newline 454:455
Newline 535:536
Newline 569:570
Newline 572:573
Newline 649:650
Newline 717:718
Newline 790:791
Newline 793:794
Newline 873:874
Newline 899:900
Newline 900:901
Fn 901:903
Ident 904:908 text="main"
LParen 908:909
RParen 909:910
LBrace 911:912
Newline 912:913
Newline 991:992
Let 996:999
Ident 1000:1002 text="ch"
Assign 1003:1004
Ident 1005:1016 text="channel_new"
LParen 1016:1017
Number 1017:1018 text="3" suf="" isf=0 int=3
RParen 1018:1019
Newline 1019:1020
Ident 1024:1030 text="expect"
LParen 1030:1031
Ident 1031:1042 text="channel_cap"
LParen 1042:1043
Ident 1043:1045 text="ch"
RParen 1045:1046
RParen 1046:1047
Dot 1047:1048
Ident 1048:1052 text="toBe"
LParen 1052:1053
Number 1053:1054 text="3" suf="" isf=0 int=3
RParen 1054:1055
Newline 1055:1056
Ident 1060:1066 text="expect"
LParen 1066:1067
Ident 1067:1078 text="channel_len"
LParen 1078:1079
Ident 1079:1081 text="ch"
RParen 1081:1082
RParen 1082:1083
Dot 1083:1084
Ident 1084:1088 text="toBe"
LParen 1088:1089
Number 1089:1090 text="0" suf="" isf=0 int=0
RParen 1090:1091
Newline 1091:1092
Ident 1096:1102 text="expect"
LParen 1102:1103
Ident 1103:1117 text="channel_closed"
LParen 1117:1118
Ident 1118:1120 text="ch"
RParen 1120:1121
RParen 1121:1122
Dot 1122:1123
Ident 1123:1127 text="toBe"
LParen 1127:1128
False 1128:1133
RParen 1133:1134
Newline 1134:1135
Newline 1135:1136
Ident 1140:1152 text="channel_send"
LParen 1152:1153
Ident 1153:1155 text="ch"
Comma 1155:1156
Number 1157:1159 text="10" suf="" isf=0 int=10
RParen 1159:1160
Newline 1160:1161
Ident 1165:1177 text="channel_send"
LParen 1177:1178
Ident 1178:1180 text="ch"
Comma 1180:1181
Number 1182:1184 text="20" suf="" isf=0 int=20
RParen 1184:1185
Newline 1185:1186
Ident 1190:1202 text="channel_send"
LParen 1202:1203
Ident 1203:1205 text="ch"
Comma 1205:1206
Number 1207:1209 text="30" suf="" isf=0 int=30
RParen 1209:1210
Newline 1210:1211
Ident 1215:1221 text="expect"
LParen 1221:1222
Ident 1222:1233 text="channel_len"
LParen 1233:1234
Ident 1234:1236 text="ch"
RParen 1236:1237
RParen 1237:1238
Dot 1238:1239
Ident 1239:1243 text="toBe"
LParen 1243:1244
Number 1244:1245 text="3" suf="" isf=0 int=3
RParen 1245:1246
Newline 1246:1247
Newline 1247:1248
Newline 1322:1323
Newline 1359:1360
Ident 1364:1370 text="expect"
LParen 1370:1371
Ident 1371:1383 text="channel_recv"
LParen 1383:1384
Ident 1384:1386 text="ch"
RParen 1386:1387
RParen 1387:1388
Dot 1388:1389
Ident 1389:1393 text="toBe"
LParen 1393:1394
Number 1394:1396 text="10" suf="" isf=0 int=10
RParen 1396:1397
Newline 1397:1398
Ident 1402:1408 text="expect"
LParen 1408:1409
Ident 1409:1421 text="channel_recv"
LParen 1421:1422
Ident 1422:1424 text="ch"
RParen 1424:1425
RParen 1425:1426
Dot 1426:1427
Ident 1427:1431 text="toBe"
LParen 1431:1432
Number 1432:1434 text="20" suf="" isf=0 int=20
RParen 1434:1435
Newline 1435:1436
Ident 1440:1446 text="expect"
LParen 1446:1447
Ident 1447:1459 text="channel_recv"
LParen 1459:1460
Ident 1460:1462 text="ch"
RParen 1462:1463
RParen 1463:1464
Dot 1464:1465
Ident 1465:1469 text="toBe"
LParen 1469:1470
Number 1470:1472 text="30" suf="" isf=0 int=30
RParen 1472:1473
Newline 1473:1474
Ident 1478:1484 text="expect"
LParen 1484:1485
Ident 1485:1496 text="channel_len"
LParen 1496:1497
Ident 1497:1499 text="ch"
RParen 1499:1500
RParen 1500:1501
Dot 1501:1502
Ident 1502:1506 text="toBe"
LParen 1506:1507
Number 1507:1508 text="0" suf="" isf=0 int=0
RParen 1508:1509
Newline 1509:1510
Newline 1510:1511
Newline 1589:1590
Newline 1668:1669
Newline 1726:1727
Ident 1731:1737 text="expect"
LParen 1737:1738
Ident 1738:1754 text="channel_try_recv"
LParen 1754:1755
Ident 1755:1757 text="ch"
RParen 1757:1758
RParen 1758:1759
Dot 1759:1760
Ident 1760:1764 text="toBe"
LParen 1764:1765
None 1765:1769
RParen 1769:1770
Newline 1770:1771
Ident 1775:1781 text="expect"
LParen 1781:1782
Ident 1782:1798 text="channel_try_send"
LParen 1798:1799
Ident 1799:1801 text="ch"
Comma 1801:1802
Number 1803:1804 text="1" suf="" isf=0 int=1
RParen 1804:1805
RParen 1805:1806
Dot 1806:1807
Ident 1807:1811 text="toBe"
LParen 1811:1812
True 1812:1816
RParen 1816:1817
Newline 1817:1818
Ident 1822:1828 text="expect"
LParen 1828:1829
Ident 1829:1845 text="channel_try_send"
LParen 1845:1846
Ident 1846:1848 text="ch"
Comma 1848:1849
Number 1850:1851 text="2" suf="" isf=0 int=2
RParen 1851:1852
RParen 1852:1853
Dot 1853:1854
Ident 1854:1858 text="toBe"
LParen 1858:1859
True 1859:1863
RParen 1863:1864
Newline 1864:1865
Ident 1869:1875 text="expect"
LParen 1875:1876
Ident 1876:1892 text="channel_try_send"
LParen 1892:1893
Ident 1893:1895 text="ch"
Comma 1895:1896
Number 1897:1898 text="3" suf="" isf=0 int=3
RParen 1898:1899
RParen 1899:1900
Dot 1900:1901
Ident 1901:1905 text="toBe"
LParen 1905:1906
True 1906:1910
RParen 1910:1911
Newline 1911:1912
Ident 1916:1922 text="expect"
LParen 1922:1923
Ident 1923:1939 text="channel_try_send"
LParen 1939:1940
Ident 1940:1942 text="ch"
Comma 1942:1943
Number 1944:1945 text="4" suf="" isf=0 int=4
RParen 1945:1946
RParen 1946:1947
Dot 1947:1948
Ident 1948:1952 text="toBe"
LParen 1952:1953
False 1953:1958
RParen 1958:1959
Newline 1959:1960
Ident 1964:1970 text="expect"
LParen 1970:1971
Ident 1971:1982 text="channel_len"
LParen 1982:1983
Ident 1983:1985 text="ch"
RParen 1985:1986
RParen 1986:1987
Dot 1987:1988
Ident 1988:1992 text="toBe"
LParen 1992:1993
Number 1993:1994 text="3" suf="" isf=0 int=3
RParen 1994:1995
Newline 1995:1996
Newline 1996:1997
Newline 2070:2071
Newline 2115:2116
Ident 2120:2126 text="expect"
LParen 2126:2127
Ident 2127:2139 text="channel_recv"
LParen 2139:2140
Ident 2140:2142 text="ch"
RParen 2142:2143
RParen 2143:2144
Dot 2144:2145
Ident 2145:2149 text="toBe"
LParen 2149:2150
Number 2150:2151 text="1" suf="" isf=0 int=1
RParen 2151:2152
Newline 2152:2153
Ident 2157:2163 text="expect"
LParen 2163:2164
Ident 2164:2180 text="channel_try_send"
LParen 2180:2181
Ident 2181:2183 text="ch"
Comma 2183:2184
Number 2185:2186 text="4" suf="" isf=0 int=4
RParen 2186:2187
RParen 2187:2188
Dot 2188:2189
Ident 2189:2193 text="toBe"
LParen 2193:2194
True 2194:2198
RParen 2198:2199
Newline 2199:2200
Ident 2204:2210 text="expect"
LParen 2210:2211
Ident 2211:2223 text="channel_recv"
LParen 2223:2224
Ident 2224:2226 text="ch"
RParen 2226:2227
RParen 2227:2228
Dot 2228:2229
Ident 2229:2233 text="toBe"
LParen 2233:2234
Number 2234:2235 text="2" suf="" isf=0 int=2
RParen 2235:2236
Newline 2236:2237
Ident 2241:2247 text="expect"
LParen 2247:2248
Ident 2248:2260 text="channel_recv"
LParen 2260:2261
Ident 2261:2263 text="ch"
RParen 2263:2264
RParen 2264:2265
Dot 2265:2266
Ident 2266:2270 text="toBe"
LParen 2270:2271
Number 2271:2272 text="3" suf="" isf=0 int=3
RParen 2272:2273
Newline 2273:2274
Ident 2278:2284 text="expect"
LParen 2284:2285
Ident 2285:2297 text="channel_recv"
LParen 2297:2298
Ident 2298:2300 text="ch"
RParen 2300:2301
RParen 2301:2302
Dot 2302:2303
Ident 2303:2307 text="toBe"
LParen 2307:2308
Number 2308:2309 text="4" suf="" isf=0 int=4
RParen 2309:2310
Newline 2310:2311
Ident 2315:2321 text="expect"
LParen 2321:2322
Ident 2322:2333 text="channel_len"
LParen 2333:2334
Ident 2334:2336 text="ch"
RParen 2336:2337
RParen 2337:2338
Dot 2338:2339
Ident 2339:2343 text="toBe"
LParen 2343:2344
Number 2344:2345 text="0" suf="" isf=0 int=0
RParen 2345:2346
Newline 2346:2347
Newline 2347:2348
Newline 2427:2428
Newline 2506:2507
Newline 2585:2586
Newline 2621:2622
For 2626:2629
LParen 2630:2631
Ident 2631:2636 text="round"
In 2637:2639
Number 2640:2641 text="0" suf="" isf=0 int=0
Range 2641:2643
Number 2643:2644 text="2" suf="" isf=0 int=2
RParen 2644:2645
LBrace 2646:2647
Newline 2647:2648
Ident 2656:2668 text="channel_send"
LParen 2668:2669
Ident 2669:2671 text="ch"
Comma 2671:2672
Number 2673:2674 text="5" suf="" isf=0 int=5
RParen 2674:2675
Newline 2675:2676
Ident 2684:2696 text="channel_send"
LParen 2696:2697
Ident 2697:2699 text="ch"
Comma 2699:2700
Number 2701:2702 text="6" suf="" isf=0 int=6
RParen 2702:2703
Newline 2703:2704
Ident 2712:2724 text="channel_send"
LParen 2724:2725
Ident 2725:2727 text="ch"
Comma 2727:2728
Number 2729:2730 text="7" suf="" isf=0 int=7
RParen 2730:2731
Newline 2731:2732
Ident 2740:2746 text="expect"
LParen 2746:2747
Ident 2747:2759 text="channel_recv"
LParen 2759:2760
Ident 2760:2762 text="ch"
RParen 2762:2763
RParen 2763:2764
Dot 2764:2765
Ident 2765:2769 text="toBe"
LParen 2769:2770
Number 2770:2771 text="5" suf="" isf=0 int=5
RParen 2771:2772
Newline 2772:2773
Ident 2781:2793 text="channel_send"
LParen 2793:2794
Ident 2794:2796 text="ch"
Comma 2796:2797
Number 2798:2799 text="8" suf="" isf=0 int=8
RParen 2799:2800
Newline 2800:2801
Ident 2809:2815 text="expect"
LParen 2815:2816
Ident 2816:2828 text="channel_recv"
LParen 2828:2829
Ident 2829:2831 text="ch"
RParen 2831:2832
RParen 2832:2833
Dot 2833:2834
Ident 2834:2838 text="toBe"
LParen 2838:2839
Number 2839:2840 text="6" suf="" isf=0 int=6
RParen 2840:2841
Newline 2841:2842
Ident 2850:2856 text="expect"
LParen 2856:2857
Ident 2857:2869 text="channel_recv"
LParen 2869:2870
Ident 2870:2872 text="ch"
RParen 2872:2873
RParen 2873:2874
Dot 2874:2875
Ident 2875:2879 text="toBe"
LParen 2879:2880
Number 2880:2881 text="7" suf="" isf=0 int=7
RParen 2881:2882
Newline 2882:2883
Ident 2891:2897 text="expect"
LParen 2897:2898
Ident 2898:2910 text="channel_recv"
LParen 2910:2911
Ident 2911:2913 text="ch"
RParen 2913:2914
RParen 2914:2915
Dot 2915:2916
Ident 2916:2920 text="toBe"
LParen 2920:2921
Number 2921:2922 text="8" suf="" isf=0 int=8
RParen 2922:2923
Newline 2923:2924
Ident 2932:2938 text="expect"
LParen 2938:2939
Ident 2939:2950 text="channel_len"
LParen 2950:2951
Ident 2951:2953 text="ch"
RParen 2953:2954
RParen 2954:2955
Dot 2955:2956
Ident 2956:2960 text="toBe"
LParen 2960:2961
Number 2961:2962 text="0" suf="" isf=0 int=0
RParen 2962:2963
Newline 2963:2964
RBrace 2968:2969
Newline 2969:2970
Newline 2970:2971
Newline 3050:3051
Newline 3129:3130
Newline 3204:3205
Newline 3282:3283
Newline 3308:3309
Let 3313:3316
Ident 3317:3319 text="c2"
Assign 3320:3321
Ident 3322:3333 text="channel_new"
LParen 3333:3334
Number 3334:3335 text="4" suf="" isf=0 int=4
RParen 3335:3336
Newline 3336:3337
Ident 3341:3353 text="channel_send"
LParen 3353:3354
Ident 3354:3356 text="c2"
Comma 3356:3357
Number 3358:3361 text="100" suf="" isf=0 int=100
RParen 3361:3362
Newline 3362:3363
Ident 3367:3379 text="channel_send"
LParen 3379:3380
Ident 3380:3382 text="c2"
Comma 3382:3383
Number 3384:3387 text="200" suf="" isf=0 int=200
RParen 3387:3388
Newline 3388:3389
Ident 3393:3399 text="expect"
LParen 3399:3400
Ident 3400:3414 text="channel_closed"
LParen 3414:3415
Ident 3415:3417 text="c2"
RParen 3417:3418
RParen 3418:3419
Dot 3419:3420
Ident 3420:3424 text="toBe"
LParen 3424:3425
False 3425:3430
RParen 3430:3431
Newline 3431:3432
Ident 3436:3449 text="channel_close"
LParen 3449:3450
Ident 3450:3452 text="c2"
RParen 3452:3453
Newline 3453:3454
Ident 3458:3464 text="expect"
LParen 3464:3465
Ident 3465:3479 text="channel_closed"
LParen 3479:3480
Ident 3480:3482 text="c2"
RParen 3482:3483
RParen 3483:3484
Dot 3484:3485
Ident 3485:3489 text="toBe"
LParen 3489:3490
True 3490:3494
RParen 3494:3495
Newline 3495:3496
Ident 3500:3506 text="expect"
LParen 3506:3507
Ident 3507:3518 text="channel_len"
LParen 3518:3519
Ident 3519:3521 text="c2"
RParen 3521:3522
RParen 3522:3523
Dot 3523:3524
Ident 3524:3528 text="toBe"
LParen 3528:3529
Number 3529:3530 text="2" suf="" isf=0 int=2
RParen 3530:3531
Newline 3531:3532
Ident 3536:3542 text="expect"
LParen 3542:3543
Ident 3543:3555 text="channel_recv"
LParen 3555:3556
Ident 3556:3558 text="c2"
RParen 3558:3559
RParen 3559:3560
Dot 3560:3561
Ident 3561:3565 text="toBe"
LParen 3565:3566
Number 3566:3569 text="100" suf="" isf=0 int=100
RParen 3569:3570
Newline 3570:3571
Ident 3575:3581 text="expect"
LParen 3581:3582
Ident 3582:3594 text="channel_recv"
LParen 3594:3595
Ident 3595:3597 text="c2"
RParen 3597:3598
RParen 3598:3599
Dot 3599:3600
Ident 3600:3604 text="toBe"
LParen 3604:3605
Number 3605:3608 text="200" suf="" isf=0 int=200
RParen 3608:3609
Newline 3609:3610
Ident 3614:3620 text="expect"
LParen 3620:3621
Ident 3621:3632 text="channel_len"
LParen 3632:3633
Ident 3633:3635 text="c2"
RParen 3635:3636
RParen 3636:3637
Dot 3637:3638
Ident 3638:3642 text="toBe"
LParen 3642:3643
Number 3643:3644 text="0" suf="" isf=0 int=0
RParen 3644:3645
Newline 3645:3646
Ident 3650:3656 text="expect"
LParen 3656:3657
Ident 3657:3673 text="channel_try_recv"
LParen 3673:3674
Ident 3674:3676 text="c2"
RParen 3676:3677
RParen 3677:3678
Dot 3678:3679
Ident 3679:3683 text="toBe"
LParen 3683:3684
None 3684:3688
RParen 3688:3689
Newline 3689:3690
Ident 3694:3700 text="expect"
LParen 3700:3701
Ident 3701:3715 text="channel_closed"
LParen 3715:3716
Ident 3716:3718 text="c2"
RParen 3718:3719
RParen 3719:3720
Dot 3720:3721
Ident 3721:3725 text="toBe"
LParen 3725:3726
True 3726:3730
RParen 3730:3731
Newline 3731:3732
Newline 3732:3733
Newline 3812:3813
Newline 3889:3890
Newline 3968:3969
Newline 3998:3999
Let 4003:4006
Ident 4007:4008 text="a"
Assign 4009:4010
Ident 4011:4022 text="channel_new"
LParen 4022:4023
Number 4023:4024 text="1" suf="" isf=0 int=1
RParen 4024:4025
Newline 4025:4026
Let 4030:4033
Ident 4034:4035 text="b"
Assign 4036:4037
Ident 4038:4049 text="channel_new"
LParen 4049:4050
Number 4050:4051 text="1" suf="" isf=0 int=1
RParen 4051:4052
Newline 4052:4053
Ident 4057:4069 text="channel_send"
LParen 4069:4070
Ident 4070:4071 text="a"
Comma 4071:4072
Number 4073:4074 text="1" suf="" isf=0 int=1
RParen 4074:4075
Newline 4075:4076
Ident 4080:4086 text="expect"
LParen 4086:4087
Ident 4087:4098 text="channel_len"
LParen 4098:4099
Ident 4099:4100 text="a"
RParen 4100:4101
RParen 4101:4102
Dot 4102:4103
Ident 4103:4107 text="toBe"
LParen 4107:4108
Number 4108:4109 text="1" suf="" isf=0 int=1
RParen 4109:4110
Newline 4110:4111
Ident 4115:4121 text="expect"
LParen 4121:4122
Ident 4122:4133 text="channel_len"
LParen 4133:4134
Ident 4134:4135 text="b"
RParen 4135:4136
RParen 4136:4137
Dot 4137:4138
Ident 4138:4142 text="toBe"
LParen 4142:4143
Number 4143:4144 text="0" suf="" isf=0 int=0
RParen 4144:4145
Newline 4145:4146
Ident 4150:4156 text="expect"
LParen 4156:4157
Ident 4157:4173 text="channel_try_recv"
LParen 4173:4174
Ident 4174:4175 text="b"
RParen 4175:4176
RParen 4176:4177
Dot 4177:4178
Ident 4178:4182 text="toBe"
LParen 4182:4183
None 4183:4187
RParen 4187:4188
Newline 4188:4189
Ident 4193:4206 text="channel_close"
LParen 4206:4207
Ident 4207:4208 text="b"
RParen 4208:4209
Newline 4209:4210
Ident 4214:4220 text="expect"
LParen 4220:4221
Ident 4221:4235 text="channel_closed"
LParen 4235:4236
Ident 4236:4237 text="b"
RParen 4237:4238
RParen 4238:4239
Dot 4239:4240
Ident 4240:4244 text="toBe"
LParen 4244:4245
True 4245:4249
RParen 4249:4250
Newline 4250:4251
Ident 4255:4261 text="expect"
LParen 4261:4262
Ident 4262:4276 text="channel_closed"
LParen 4276:4277
Ident 4277:4278 text="a"
RParen 4278:4279
RParen 4279:4280
Dot 4280:4281
Ident 4281:4285 text="toBe"
LParen 4285:4286
False 4286:4291
RParen 4291:4292
Newline 4292:4293
Newline 4373:4374
Newline 4427:4428
Ident 4432:4438 text="expect"
LParen 4438:4439
Ident 4439:4455 text="channel_try_send"
LParen 4455:4456
Ident 4456:4457 text="a"
Comma 4457:4458
Number 4459:4460 text="2" suf="" isf=0 int=2
RParen 4460:4461
RParen 4461:4462
Dot 4462:4463
Ident 4463:4467 text="toBe"
LParen 4467:4468
False 4468:4473
RParen 4473:4474
Newline 4474:4475
Ident 4479:4485 text="expect"
LParen 4485:4486
Ident 4486:4498 text="channel_recv"
LParen 4498:4499
Ident 4499:4500 text="a"
RParen 4500:4501
RParen 4501:4502
Dot 4502:4503
Ident 4503:4507 text="toBe"
LParen 4507:4508
Number 4508:4509 text="1" suf="" isf=0 int=1
RParen 4509:4510
Newline 4510:4511
Ident 4515:4521 text="expect"
LParen 4521:4522
Ident 4522:4538 text="channel_try_send"
LParen 4538:4539
Ident 4539:4540 text="a"
Comma 4540:4541
Number 4542:4543 text="2" suf="" isf=0 int=2
RParen 4543:4544
RParen 4544:4545
Dot 4545:4546
Ident 4546:4550 text="toBe"
LParen 4550:4551
True 4551:4555
RParen 4555:4556
Newline 4556:4557
Ident 4561:4567 text="expect"
LParen 4567:4568
Ident 4568:4580 text="channel_recv"
LParen 4580:4581
Ident 4581:4582 text="a"
RParen 4582:4583
RParen 4583:4584
Dot 4584:4585
Ident 4585:4589 text="toBe"
LParen 4589:4590
Number 4590:4591 text="2" suf="" isf=0 int=2
RParen 4591:4592
Newline 4592:4593
Newline 4593:4594
Ident 4598:4605 text="println"
LParen 4605:4606
Str 4606:4618 T("channel ok")
RParen 4618:4619
Newline 4619:4620
RBrace 4620:4621
Newline 4621:4622
Eof 4622:4622
