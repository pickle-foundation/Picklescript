Module 0:6
Ident 7:24 text="continuation_test"
Newline 24:25
Newline 25:26
Class 26:31
Ident 32:36 text="Vec2"
LBrace 37:38
Newline 38:39
Var 43:46
Ident 47:48 text="x"
Colon 48:49
Ident 50:53 text="int"
Newline 53:54
Var 58:61
Ident 62:63 text="y"
Colon 63:64
Ident 65:68 text="int"
Newline 68:69
Constructor 73:84
LParen 84:85
Ident 85:86 text="x"
Colon 86:87
Ident 88:91 text="int"
Comma 91:92
Ident 93:94 text="y"
Colon 94:95
Ident 96:99 text="int"
RParen 99:100
LBrace 101:102
Newline 102:103
This 111:115
Dot 115:116
Ident 116:117 text="x"
Assign 118:119
Ident 120:121 text="x"
Newline 121:122
This 130:134
Dot 134:135
Ident 135:136 text="y"
Assign 137:138
Ident 139:140 text="y"
Newline 140:141
RBrace 145:146
Newline 146:147
Fn 151:153
Ident 154:157 text="sum"
LParen 157:158
RParen 158:159
Arrow 160:162
Ident 163:166 text="int"
LBrace 167:168
Newline 168:169
This 177:181
Dot 181:182
Ident 182:183 text="x"
Plus 184:185
This 186:190
Dot 190:191
Ident 191:192 text="y"
Newline 192:193
RBrace 197:198
Newline 198:199
RBrace 199:200
Newline 200:201
Newline 201:202
Fn 202:204
Ident 205:214 text="multiLine"
LParen 214:215
Ident 215:216 text="x"
Colon 216:217
Ident 218:221 text="int"
RParen 221:222
Arrow 223:225
Ident 226:229 text="int"
LBrace 230:231
Newline 231:232
Let 236:239
Ident 240:245 text="total"
Assign 246:247
Ident 248:249 text="x"
Newline 249:250
Plus 259:260
Number 261:262 text="2" suf="" isf=0 int=2
Newline 262:263
Star 272:273
Number 274:275 text="3" suf="" isf=0 int=3
Newline 275:276
Ident 280:285 text="total"
Newline 285:286
RBrace 286:287
Newline 287:288
Newline 288:289
Fn 289:291
Ident 292:299 text="chained"
LParen 299:300
Ident 300:301 text="v"
Colon 301:302
Ident 303:307 text="Vec2"
RParen 307:308
Arrow 309:311
Ident 312:315 text="int"
LBrace 316:317
Newline 317:318
Ident 322:323 text="v"
Newline 323:324
Dot 332:333
Ident 333:336 text="sum"
LParen 336:337
RParen 337:338
Newline 338:339
RBrace 339:340
Newline 340:341
Newline 341:342
Fn 342:344
Ident 345:351 text="ifTail"
LParen 351:352
Ident 352:353 text="c"
Colon 353:354
Ident 355:359 text="bool"
RParen 359:360
Arrow 361:363
Ident 364:367 text="int"
LBrace 368:369
Newline 369:370
If 374:376
LParen 377:378
Ident 378:379 text="c"
RParen 379:380
LBrace 381:382
Newline 382:383
Return 391:397
Number 398:399 text="1" suf="" isf=0 int=1
Newline 399:400
RBrace 404:405
Newline 405:406
Minus 410:411
Number 411:412 text="1" suf="" isf=0 int=1
Newline 412:413
RBrace 413:414
Newline 414:415
Newline 415:416
Fn 416:418
Ident 419:428 text="matchTail"
LParen 428:429
Ident 429:430 text="v"
Colon 430:431
Ident 432:435 text="int"
RParen 435:436
Arrow 437:439
Ident 440:443 text="int"
LBrace 444:445
Newline 445:446
Match 450:455
LParen 456:457
Ident 457:458 text="v"
RParen 458:459
LBrace 460:461
Newline 461:462
Case 470:474
Number 475:476 text="0" suf="" isf=0 int=0
Arrow 477:479
Number 480:482 text="10" suf="" isf=0 int=10
Newline 482:483
Case 491:495
Ident 496:497 text="_"
Arrow 498:500
Number 501:503 text="20" suf="" isf=0 int=20
Newline 503:504
RBrace 508:509
Newline 509:510
Minus 514:515
Number 515:516 text="1" suf="" isf=0 int=1
Newline 516:517
RBrace 517:518
Newline 518:519
Newline 519:520
Fn 520:522
Ident 523:533 text="negateTail"
LParen 533:534
Ident 534:535 text="x"
Colon 535:536
Ident 537:540 text="int"
RParen 540:541
Arrow 542:544
Ident 545:548 text="int"
LBrace 549:550
Newline 550:551
Minus 555:556
Ident 556:557 text="x"
Newline 557:558
RBrace 558:559
Newline 559:560
Newline 560:561
Fn 561:563
Ident 564:569 text="id_fn"
Lt 569:570
Ident 570:571 text="T"
Gt 571:572
LParen 572:573
Ident 573:574 text="x"
Colon 574:575
Ident 576:577 text="T"
RParen 577:578
Arrow 579:581
Ident 582:583 text="T"
LBrace 584:585
Newline 585:586
Return 590:596
Ident 597:598 text="x"
Newline 598:599
RBrace 599:600
Newline 600:601
Newline 601:602
Ident 602:606 text="test"
Fn 607:609
Ident 610:629 text="continuation_checks"
LParen 629:630
RParen 630:631
LBrace 632:633
Newline 633:634
Ident 638:644 text="expect"
LParen 644:645
Ident 645:650 text="id_fn"
Lt 650:651
Ident 651:654 text="int"
Gt 654:655
LParen 655:656
Ident 656:665 text="multiLine"
LParen 665:666
Number 666:667 text="4" suf="" isf=0 int=4
RParen 667:668
RParen 668:669
RParen 669:670
Dot 670:671
Ident 671:675 text="toBe"
LParen 675:676
Number 676:678 text="10" suf="" isf=0 int=10
RParen 678:679
Newline 679:680
Ident 684:690 text="expect"
LParen 690:691
Ident 691:696 text="id_fn"
Lt 696:697
Ident 697:700 text="int"
Gt 700:701
LParen 701:702
Ident 702:709 text="chained"
LParen 709:710
Ident 710:714 text="Vec2"
LParen 714:715
Number 715:716 text="3" suf="" isf=0 int=3
Comma 716:717
Number 718:719 text="4" suf="" isf=0 int=4
RParen 719:720
RParen 720:721
RParen 721:722
RParen 722:723
Dot 723:724
Ident 724:728 text="toBe"
LParen 728:729
Number 729:730 text="7" suf="" isf=0 int=7
RParen 730:731
Newline 731:732
Ident 736:742 text="expect"
LParen 742:743
Ident 743:748 text="id_fn"
Lt 748:749
Ident 749:752 text="int"
Gt 752:753
LParen 753:754
Ident 754:760 text="ifTail"
LParen 760:761
True 761:765
RParen 765:766
RParen 766:767
RParen 767:768
Dot 768:769
Ident 769:773 text="toBe"
LParen 773:774
Number 774:775 text="1" suf="" isf=0 int=1
RParen 775:776
Newline 776:777
Ident 781:787 text="expect"
LParen 787:788
Ident 788:793 text="id_fn"
Lt 793:794
Ident 794:797 text="int"
Gt 797:798
LParen 798:799
Ident 799:805 text="ifTail"
LParen 805:806
False 806:811
RParen 811:812
RParen 812:813
RParen 813:814
Dot 814:815
Ident 815:819 text="toBe"
LParen 819:820
Minus 820:821
Number 821:822 text="1" suf="" isf=0 int=1
RParen 822:823
Newline 823:824
Ident 828:834 text="expect"
LParen 834:835
Ident 835:840 text="id_fn"
Lt 840:841
Ident 841:844 text="int"
Gt 844:845
LParen 845:846
Ident 846:855 text="matchTail"
LParen 855:856
Number 856:857 text="0" suf="" isf=0 int=0
RParen 857:858
RParen 858:859
RParen 859:860
Dot 860:861
Ident 861:865 text="toBe"
LParen 865:866
Minus 866:867
Number 867:868 text="1" suf="" isf=0 int=1
RParen 868:869
Newline 869:870
Ident 874:880 text="expect"
LParen 880:881
Ident 881:886 text="id_fn"
Lt 886:887
Ident 887:890 text="int"
Gt 890:891
LParen 891:892
Ident 892:902 text="negateTail"
LParen 902:903
Number 903:904 text="3" suf="" isf=0 int=3
RParen 904:905
RParen 905:906
RParen 906:907
Dot 907:908
Ident 908:912 text="toBe"
LParen 912:913
Minus 913:914
Number 914:915 text="3" suf="" isf=0 int=3
RParen 915:916
Newline 916:917
RBrace 917:918
Eof 918:918
