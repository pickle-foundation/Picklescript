Module 0:6
Ident 7:21 text="abi_float_main"
Newline 21:22
Newline 22:23
Import 23:29
LBrace 30:31
Ident 32:45 text="abiStrFromF64"
RBrace 46:47
From 48:52
Ident 53:60 text="runtime"
Dot 60:61
Ident 61:70 text="abi_float"
Newline 70:71
Import 71:77
LBrace 78:79
Ident 80:88 text="emitCstr"
RBrace 89:90
From 91:95
Ident 96:103 text="runtime"
Dot 103:104
Ident 104:115 text="abi_console"
Newline 115:116
Newline 116:117
Fn 117:119
Ident 120:124 text="show"
LParen 124:125
Ident 125:128 text="tag"
Colon 128:129
Ident 130:136 text="string"
Comma 136:137
Ident 138:139 text="v"
Colon 139:140
Ident 141:146 text="float"
RParen 146:147
LBrace 148:149
Newline 149:150
Ident 154:159 text="print"
LParen 159:160
Ident 160:163 text="tag"
RParen 163:164
Newline 164:165
Ident 169:174 text="print"
LParen 174:175
Str 175:178 T(" ")
RParen 178:179
Newline 179:180
Ident 184:189 text="print"
LParen 189:190
Ident 190:191 text="v"
RParen 191:192
Newline 192:193
Ident 197:202 text="print"
LParen 202:203
Str 203:206 T(" ")
RParen 206:207
Newline 207:208
Ident 212:217 text="print"
LParen 217:218
Str 218:223 E[Ident 220:221 text="v"; Eof 222:222]
RParen 223:224
Newline 224:225
Ident 229:234 text="print"
LParen 234:235
Str 235:239 T("\n")
RParen 239:240
Newline 240:241
RBrace 241:242
Newline 242:243
Newline 243:244
Fn 244:246
Ident 247:251 text="main"
LParen 251:252
RParen 252:253
LBrace 254:255
Newline 255:256
Ident 260:264 text="show"
LParen 264:265
Str 265:271 T("zero")
Comma 271:272
Number 273:276 text="0.0" suf="" isf=1 int=-
RParen 276:277
Newline 277:278
Ident 282:286 text="show"
LParen 286:287
Str 287:296 T("negzero")
Comma 296:297
Minus 298:299
Number 299:302 text="0.0" suf="" isf=1 int=-
RParen 302:303
Newline 303:304
Ident 308:312 text="show"
LParen 312:313
Str 313:318 T("one")
Comma 318:319
Number 320:323 text="1.0" suf="" isf=1 int=-
RParen 323:324
Newline 324:325
Ident 329:333 text="show"
LParen 333:334
Str 334:342 T("negone")
Comma 342:343
Minus 344:345
Number 345:348 text="1.0" suf="" isf=1 int=-
RParen 348:349
Newline 349:350
Ident 354:358 text="show"
LParen 358:359
Str 359:366 T("tenth")
Comma 366:367
Number 368:371 text="0.1" suf="" isf=1 int=-
RParen 371:372
Newline 372:373
Ident 377:381 text="show"
LParen 381:382
Str 382:392 T("twotenth")
Comma 392:393
Number 394:397 text="0.2" suf="" isf=1 int=-
RParen 397:398
Newline 398:399
Ident 403:407 text="show"
LParen 407:408
Str 408:420 T("threetenth")
Comma 420:421
Number 422:425 text="0.3" suf="" isf=1 int=-
RParen 425:426
Newline 426:427
Ident 431:435 text="show"
LParen 435:436
Str 436:446 T("onethird")
Comma 446:447
Number 448:451 text="1.0" suf="" isf=1 int=-
Slash 452:453
Number 454:457 text="3.0" suf="" isf=1 int=-
RParen 457:458
Newline 458:459
Ident 463:467 text="show"
LParen 467:468
Str 468:474 T("half")
Comma 474:475
Number 476:479 text="0.5" suf="" isf=1 int=-
RParen 479:480
Newline 480:481
Ident 485:489 text="show"
LParen 489:490
Str 490:495 T("two")
Comma 495:496
Number 497:500 text="2.0" suf="" isf=1 int=-
RParen 500:501
Newline 501:502
Ident 506:510 text="show"
LParen 510:511
Str 511:516 T("ten")
Comma 516:517
Number 518:522 text="10.0" suf="" isf=1 int=-
RParen 522:523
Newline 523:524
Ident 528:532 text="show"
LParen 532:533
Str 533:542 T("hundred")
Comma 542:543
Number 544:549 text="100.0" suf="" isf=1 int=-
RParen 549:550
Newline 550:551
Ident 555:559 text="show"
LParen 559:560
Str 560:564 T("pi")
Comma 564:565
Number 566:583 text="3.141592653589793" suf="" isf=1 int=-
RParen 583:584
Newline 584:585
Ident 589:593 text="show"
LParen 593:594
Str 594:597 T("e")
Comma 597:598
Number 599:616 text="2.718281828459045" suf="" isf=1 int=-
RParen 616:617
Newline 617:618
Ident 622:626 text="show"
LParen 626:627
Str 627:633 T("1e15")
Comma 633:634
Number 635:639 text="1e15" suf="" isf=1 int=-
RParen 639:640
Newline 640:641
Ident 645:649 text="show"
LParen 649:650
Str 650:656 T("1e16")
Comma 656:657
Number 658:662 text="1e16" suf="" isf=1 int=-
RParen 662:663
Newline 663:664
Ident 668:672 text="show"
LParen 672:673
Str 673:679 T("1e17")
Comma 679:680
Number 681:685 text="1e17" suf="" isf=1 int=-
RParen 685:686
Newline 686:687
Ident 691:695 text="show"
LParen 695:696
Str 696:702 T("1e20")
Comma 702:703
Number 704:708 text="1e20" suf="" isf=1 int=-
RParen 708:709
Newline 709:710
Ident 714:718 text="show"
LParen 718:719
Str 719:726 T("1e100")
Comma 726:727
Number 728:733 text="1e100" suf="" isf=1 int=-
RParen 733:734
Newline 734:735
Ident 739:743 text="show"
LParen 743:744
Str 744:751 T("1e300")
Comma 751:752
Number 753:758 text="1e300" suf="" isf=1 int=-
RParen 758:759
Newline 759:760
Ident 764:768 text="show"
LParen 768:769
Str 769:775 T("1em1")
Comma 775:776
Number 777:781 text="1e-1" suf="" isf=1 int=-
RParen 781:782
Newline 782:783
Ident 787:791 text="show"
LParen 791:792
Str 792:798 T("1em4")
Comma 798:799
Number 800:804 text="1e-4" suf="" isf=1 int=-
RParen 804:805
Newline 805:806
Ident 810:814 text="show"
LParen 814:815
Str 815:821 T("1em5")
Comma 821:822
Number 823:827 text="1e-5" suf="" isf=1 int=-
RParen 827:828
Newline 828:829
Ident 833:837 text="show"
LParen 837:838
Str 838:845 T("1em10")
Comma 845:846
Number 847:852 text="1e-10" suf="" isf=1 int=-
RParen 852:853
Newline 853:854
Ident 858:862 text="show"
LParen 862:863
Str 863:870 T("1em15")
Comma 870:871
Number 872:877 text="1e-15" suf="" isf=1 int=-
RParen 877:878
Newline 878:879
Ident 883:887 text="show"
LParen 887:888
Str 888:896 T("1em300")
Comma 896:897
Number 898:904 text="1e-300" suf="" isf=1 int=-
RParen 904:905
Newline 905:906
Ident 910:914 text="show"
LParen 914:915
Str 915:923 T("big123")
Comma 923:924
Number 925:945 text="123456789012345678.0" suf="" isf=1 int=-
RParen 945:946
Newline 946:947
Ident 951:955 text="show"
LParen 955:956
Str 956:964 T("pow253")
Comma 964:965
Number 966:984 text="9007199254740993.0" suf="" isf=1 int=-
RParen 984:985
Newline 985:986
Ident 990:994 text="show"
LParen 994:995
Str 995:1003 T("oddsum")
Comma 1003:1004
Number 1005:1008 text="0.1" suf="" isf=1 int=-
Plus 1009:1010
Number 1011:1014 text="0.2" suf="" isf=1 int=-
RParen 1014:1015
Newline 1015:1016
Ident 1020:1024 text="show"
LParen 1024:1025
Str 1025:1030 T("inf")
Comma 1030:1031
Ident 1032:1043 text="f64FromBits"
LParen 1043:1044
Number 1044:1062 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312
RParen 1062:1063
RParen 1063:1064
Newline 1064:1065
Ident 1069:1073 text="show"
LParen 1073:1074
Str 1074:1082 T("neginf")
Comma 1082:1083
Minus 1084:1085
Ident 1085:1096 text="f64FromBits"
LParen 1096:1097
Number 1097:1115 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312
RParen 1115:1116
RParen 1116:1117
Newline 1117:1118
Ident 1122:1126 text="show"
LParen 1126:1127
Str 1127:1132 T("nan")
Comma 1132:1133
Ident 1134:1145 text="f64FromBits"
LParen 1145:1146
Number 1146:1164 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560
RParen 1164:1165
RParen 1165:1166
Newline 1166:1167
Ident 1171:1175 text="show"
LParen 1175:1176
Str 1176:1184 T("minsub")
Comma 1184:1185
Ident 1186:1197 text="f64FromBits"
LParen 1197:1198
Number 1198:1216 text="0x0000000000000001" suf="" isf=0 int=1
RParen 1216:1217
RParen 1217:1218
Newline 1218:1219
Ident 1223:1227 text="show"
LParen 1227:1228
Str 1228:1233 T("max")
Comma 1233:1234
Ident 1235:1246 text="f64FromBits"
LParen 1246:1247
Number 1247:1265 text="0x7FEFFFFFFFFFFFFF" suf="" isf=0 int=9218868437227405311
RParen 1265:1266
RParen 1266:1267
Newline 1267:1268
Ident 1272:1276 text="show"
LParen 1276:1277
Str 1277:1286 T("minnorm")
Comma 1286:1287
Ident 1288:1299 text="f64FromBits"
LParen 1299:1300
Number 1300:1318 text="0x0010000000000000" suf="" isf=0 int=4503599627370496
RParen 1318:1319
RParen 1319:1320
Newline 1320:1321
Ident 1325:1329 text="show"
LParen 1329:1330
Str 1330:1335 T("1e6")
Comma 1335:1336
Number 1337:1340 text="1e6" suf="" isf=1 int=-
RParen 1340:1341
Newline 1341:1342
Ident 1346:1350 text="show"
LParen 1350:1351
Str 1351:1360 T("digits9")
Comma 1360:1361
Number 1362:1373 text="123456789.0" suf="" isf=1 int=-
RParen 1373:1374
Newline 1374:1375
Ident 1379:1383 text="show"
LParen 1383:1384
Str 1384:1394 T("longfrac")
Comma 1394:1395
Number 1396:1407 text="1234567.891" suf="" isf=1 int=-
RParen 1407:1408
Newline 1408:1409
Ident 1413:1417 text="show"
LParen 1417:1418
Str 1418:1430 T("thousandth")
Comma 1430:1431
Number 1432:1437 text="0.007" suf="" isf=1 int=-
RParen 1437:1438
Newline 1438:1439
Ident 1443:1447 text="show"
LParen 1447:1448
Str 1448:1453 T("neg")
Comma 1453:1454
Minus 1455:1456
Number 1456:1459 text="1.5" suf="" isf=1 int=-
RParen 1459:1460
Newline 1460:1461
Ident 1465:1469 text="show"
LParen 1469:1470
Str 1470:1480 T("negtenth")
Comma 1480:1481
Minus 1482:1483
Number 1483:1486 text="0.1" suf="" isf=1 int=-
RParen 1486:1487
Newline 1487:1488
Ident 1492:1496 text="show"
LParen 1496:1497
Str 1497:1503 T("1e18")
Comma 1503:1504
Number 1505:1509 text="1e18" suf="" isf=1 int=-
RParen 1509:1510
Newline 1510:1511
Ident 1515:1519 text="show"
LParen 1519:1520
Str 1520:1526 T("1e19")
Comma 1526:1527
Number 1528:1532 text="1e19" suf="" isf=1 int=-
RParen 1532:1533
Newline 1533:1534
Ident 1538:1542 text="show"
LParen 1542:1543
Str 1543:1548 T("2p5")
Comma 1548:1549
Number 1550:1553 text="2.5" suf="" isf=1 int=-
RParen 1553:1554
Newline 1554:1555
Ident 1559:1563 text="show"
LParen 1563:1564
Str 1564:1574 T("tiny1e32")
Comma 1574:1575
Number 1576:1581 text="1e-32" suf="" isf=1 int=-
RParen 1581:1582
Newline 1582:1583
RBrace 1583:1584
Newline 1584:1585
Eof 1585:1585
