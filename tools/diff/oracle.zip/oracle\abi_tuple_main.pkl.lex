Module 0:6
Ident 7:21 text="abi_tuple_main"
Newline 21:22
Newline 22:23
Newline 90:91
Newline 93:94
Newline 184:185
Newline 270:271
Newline 355:356
Newline 439:440
Newline 442:443
Newline 531:532
Newline 615:616
Newline 705:706
Newline 797:798
Newline 854:855
Newline 855:856
Import 856:862
LBrace 863:864
Ident 865:873 text="tupleNew"
Comma 873:874
Ident 875:886 text="abiTupleLen"
Comma 886:887
Ident 888:904 text="abiTupleSetField"
Comma 904:905
Ident 906:919 text="abiTupleField"
RBrace 920:921
From 922:926
Ident 927:934 text="runtime"
Dot 934:935
Ident 935:944 text="abi_tuple"
Newline 944:945
Import 945:951
LBrace 952:953
Ident 954:963 text="abiBoxI64"
Comma 963:964
Ident 965:976 text="abiUnboxI64"
RBrace 977:978
From 979:983
Ident 984:991 text="runtime"
Dot 991:992
Ident 992:999 text="abi_box"
Newline 999:1000
Newline 1000:1001
Newline 1083:1084
Fn 1084:1086 doc="Read field `i` back through the exported `pickle_tuple_field` ABI entry point."
Ident 1087:1089 text="at"
LParen 1089:1090
Ident 1090:1091 text="t"
Colon 1091:1092
Star 1093:1094
Ident 1094:1097 text="int"
Comma 1097:1098
Ident 1099:1100 text="i"
Colon 1100:1101
Ident 1102:1105 text="int"
RParen 1105:1106
Arrow 1107:1109
Ident 1110:1113 text="int"
LBrace 1114:1115
Newline 1115:1116
Return 1120:1126
Ident 1127:1138 text="abiUnboxI64"
LParen 1138:1139
Ident 1139:1152 text="abiTupleField"
LParen 1152:1153
Ident 1153:1154 text="t"
Comma 1154:1155
Ident 1156:1157 text="i"
RParen 1157:1158
RParen 1158:1159
Newline 1159:1160
RBrace 1160:1161
Newline 1161:1162
Newline 1162:1163
Fn 1163:1165
Ident 1166:1170 text="main"
LParen 1170:1171
RParen 1171:1172
LBrace 1173:1174
Newline 1174:1175
Newline 1209:1210
Var 1214:1217
Ident 1218:1219 text="t"
Assign 1220:1221
Ident 1222:1230 text="tupleNew"
LParen 1230:1231
Number 1231:1232 text="3" suf="" isf=0 int=3
RParen 1232:1233
Newline 1233:1234
Unsafe 1238:1244
LBrace 1245:1246
Newline 1246:1247
Ident 1255:1262 text="println"
LParen 1262:1263
Str 1263:1278 T("class: ") E[Ident 1272:1273 text="t"; LBracket 1273:1274; Number 1274:1275 text="1" suf="" isf=0 int=1; RBracket 1275:1276; Eof 1277:1277]
RParen 1278:1279
Newline 1279:1280
Ident 1288:1295 text="println"
LParen 1295:1296
Str 1296:1310 T("size: ") E[Ident 1304:1305 text="t"; LBracket 1305:1306; Number 1306:1307 text="2" suf="" isf=0 int=2; RBracket 1307:1308; Eof 1309:1309]
RParen 1310:1311
Newline 1311:1312
Ident 1320:1327 text="println"
LParen 1327:1328
Str 1328:1348 T("count word: ") E[Ident 1342:1343 text="t"; LBracket 1343:1344; Number 1344:1345 text="3" suf="" isf=0 int=3; RBracket 1345:1346; Eof 1347:1347]
RParen 1348:1349
Newline 1349:1350
Ident 1358:1365 text="println"
LParen 1365:1366
Str 1366:1387 T("field0 word: ") E[Ident 1381:1382 text="t"; LBracket 1382:1383; Number 1383:1384 text="4" suf="" isf=0 int=4; RBracket 1384:1385; Eof 1386:1386]
RParen 1387:1388
Newline 1388:1389
RBrace 1393:1394
Newline 1394:1395
Ident 1399:1406 text="println"
LParen 1406:1407
Str 1407:1430 T("len: ") E[Ident 1414:1425 text="abiTupleLen"; LParen 1425:1426; Ident 1426:1427 text="t"; RParen 1427:1428; Eof 1429:1429]
RParen 1430:1431
Newline 1431:1432
Newline 1432:1433
Newline 1490:1491
Ident 1495:1511 text="abiTupleSetField"
LParen 1511:1512
Ident 1512:1513 text="t"
Comma 1513:1514
Number 1515:1516 text="0" suf="" isf=0 int=0
Comma 1516:1517
Ident 1518:1527 text="abiBoxI64"
LParen 1527:1528
Number 1528:1530 text="11" suf="" isf=0 int=11
RParen 1530:1531
RParen 1531:1532
Newline 1532:1533
Ident 1537:1553 text="abiTupleSetField"
LParen 1553:1554
Ident 1554:1555 text="t"
Comma 1555:1556
Number 1557:1558 text="1" suf="" isf=0 int=1
Comma 1558:1559
Ident 1560:1569 text="abiBoxI64"
LParen 1569:1570
Number 1570:1572 text="22" suf="" isf=0 int=22
RParen 1572:1573
RParen 1573:1574
Newline 1574:1575
Ident 1579:1595 text="abiTupleSetField"
LParen 1595:1596
Ident 1596:1597 text="t"
Comma 1597:1598
Number 1599:1600 text="2" suf="" isf=0 int=2
Comma 1600:1601
Ident 1602:1611 text="abiBoxI64"
LParen 1611:1612
Number 1612:1614 text="33" suf="" isf=0 int=33
RParen 1614:1615
RParen 1615:1616
Newline 1616:1617
Ident 1621:1628 text="println"
LParen 1628:1629
Str 1629:1645 T("f0: ") E[Ident 1635:1637 text="at"; LParen 1637:1638; Ident 1638:1639 text="t"; Comma 1639:1640; Number 1641:1642 text="0" suf="" isf=0 int=0; RParen 1642:1643; Eof 1644:1644]
RParen 1645:1646
Newline 1646:1647
Ident 1651:1658 text="println"
LParen 1658:1659
Str 1659:1675 T("f1: ") E[Ident 1665:1667 text="at"; LParen 1667:1668; Ident 1668:1669 text="t"; Comma 1669:1670; Number 1671:1672 text="1" suf="" isf=0 int=1; RParen 1672:1673; Eof 1674:1674]
RParen 1675:1676
Newline 1676:1677
Ident 1681:1688 text="println"
LParen 1688:1689
Str 1689:1705 T("f2: ") E[Ident 1695:1697 text="at"; LParen 1697:1698; Ident 1698:1699 text="t"; Comma 1699:1700; Number 1701:1702 text="2" suf="" isf=0 int=2; RParen 1702:1703; Eof 1704:1704]
RParen 1705:1706
Newline 1706:1707
Newline 1707:1708
Newline 1763:1764
Ident 1768:1775 text="println"
LParen 1775:1776
Str 1776:1811 T("oob: ") E[Ident 1783:1796 text="abiTupleField"; LParen 1796:1797; Ident 1797:1798 text="t"; Comma 1798:1799; Number 1800:1801 text="3" suf="" isf=0 int=3; RParen 1801:1802; As 1803:1805; Ident 1806:1809 text="int"; Eof 1810:1810]
RParen 1811:1812
Newline 1812:1813
Ident 1817:1824 text="println"
LParen 1824:1825
Str 1825:1865 T("far oob: ") E[Ident 1836:1849 text="abiTupleField"; LParen 1849:1850; Ident 1850:1851 text="t"; Comma 1851:1852; Number 1853:1855 text="99" suf="" isf=0 int=99; RParen 1855:1856; As 1857:1859; Ident 1860:1863 text="int"; Eof 1864:1864]
RParen 1865:1866
Newline 1866:1867
Newline 1867:1868
Newline 1957:1958
Var 1962:1965
Ident 1966:1967 text="e"
Assign 1968:1969
Ident 1970:1978 text="tupleNew"
LParen 1978:1979
Number 1979:1980 text="0" suf="" isf=0 int=0
RParen 1980:1981
Newline 1981:1982
Ident 1986:1993 text="println"
LParen 1993:1994
Str 1994:2023 T("empty len: ") E[Ident 2007:2018 text="abiTupleLen"; LParen 2018:2019; Ident 2019:2020 text="e"; RParen 2020:2021; Eof 2022:2022]
RParen 2023:2024
Newline 2024:2025
Ident 2029:2036 text="println"
LParen 2036:2037
Str 2037:2078 T("empty oob: ") E[Ident 2050:2063 text="abiTupleField"; LParen 2063:2064; Ident 2064:2065 text="e"; Comma 2065:2066; Number 2067:2068 text="0" suf="" isf=0 int=0; RParen 2068:2069; As 2070:2072; Ident 2073:2076 text="int"; Eof 2077:2077]
RParen 2078:2079
Newline 2079:2080
Newline 2080:2081
Newline 2164:2165
Newline 2216:2217
Let 2221:2224
LParen 2225:2226
Ident 2226:2227 text="a"
Comma 2227:2228
Ident 2229:2230 text="b"
RParen 2230:2231
Assign 2232:2233
LParen 2234:2235
Number 2235:2236 text="7" suf="" isf=0 int=7
Comma 2236:2237
Number 2238:2239 text="9" suf="" isf=0 int=9
RParen 2239:2240
Newline 2240:2241
Ident 2245:2252 text="println"
LParen 2252:2253
Str 2253:2275 T("destructure: ") E[Ident 2268:2269 text="a"; Eof 2270:2270] T(" ") E[Ident 2272:2273 text="b"; Eof 2274:2274]
RParen 2275:2276
Newline 2276:2277
Let 2281:2284
LParen 2285:2286
Ident 2286:2287 text="p"
Comma 2287:2288
Ident 2289:2290 text="q"
Comma 2290:2291
Ident 2292:2293 text="r"
RParen 2293:2294
Assign 2295:2296
LParen 2297:2298
Number 2298:2299 text="1" suf="" isf=0 int=1
Comma 2299:2300
Number 2301:2302 text="2" suf="" isf=0 int=2
Comma 2302:2303
Number 2304:2305 text="3" suf="" isf=0 int=3
RParen 2305:2306
Newline 2306:2307
Ident 2311:2318 text="println"
LParen 2318:2319
Str 2319:2340 T("triple: ") E[Ident 2329:2330 text="p"; Eof 2331:2331] T(" ") E[Ident 2333:2334 text="q"; Eof 2335:2335] T(" ") E[Ident 2337:2338 text="r"; Eof 2339:2339]
RParen 2340:2341
Newline 2341:2342
RBrace 2342:2343
Newline 2343:2344
Eof 2344:2344
