Newline 77:78
Newline 155:156
Newline 232:233
Newline 278:279
Newline 279:280
Async 280:285
Fn 286:288
Ident 289:300 text="slow_square"
LParen 300:301
Ident 301:302 text="n"
Colon 302:303
Ident 304:307 text="int"
RParen 307:308
Arrow 309:311
Ident 312:315 text="int"
LBrace 316:317
Newline 317:318
Ident 322:323 text="n"
Star 324:325
Ident 326:327 text="n"
Newline 327:328
RBrace 328:329
Newline 329:330
Newline 330:331
Async 331:336
Fn 337:339
Ident 340:343 text="add"
LParen 343:344
Ident 344:345 text="a"
Colon 345:346
Ident 347:350 text="int"
Comma 350:351
Ident 352:353 text="b"
Colon 353:354
Ident 355:358 text="int"
RParen 358:359
Arrow 360:362
Ident 363:366 text="int"
LBrace 367:368
Newline 368:369
Ident 373:374 text="a"
Plus 375:376
Ident 377:378 text="b"
Newline 378:379
RBrace 379:380
Newline 380:381
Newline 381:382
Async 382:387
Fn 388:390
Ident 391:395 text="ness"
LParen 395:396
Ident 396:397 text="x"
Colon 397:398
Ident 399:402 text="int"
RParen 402:403
Arrow 404:406
Ident 407:410 text="int"
LBrace 411:412
Newline 412:413
Let 417:420
Ident 421:426 text="inner"
Assign 427:428
Ident 429:438 text="innermost"
LParen 438:439
Ident 439:440 text="x"
RParen 440:441
Newline 441:442
Await 446:451
Ident 452:457 text="inner"
Newline 457:458
RBrace 458:459
Newline 459:460
Newline 460:461
Async 461:466
Fn 467:469
Ident 470:479 text="innermost"
LParen 479:480
Ident 480:481 text="x"
Colon 481:482
Ident 483:486 text="int"
RParen 486:487
Arrow 488:490
Ident 491:494 text="int"
LBrace 495:496
Newline 496:497
Ident 501:502 text="x"
Plus 503:504
Number 505:508 text="100" suf="" isf=0 int=100
Newline 508:509
RBrace 509:510
Newline 510:511
Newline 511:512
Ident 512:516 text="test"
Fn 517:519
Ident 520:555 text="calling_an_async_fn_defers_the_body"
LParen 555:556
RParen 556:557
LBrace 558:559
Newline 559:560
Newline 623:624
Let 628:631
Ident 632:633 text="f"
Assign 634:635
Ident 636:647 text="slow_square"
LParen 647:648
Number 648:649 text="7" suf="" isf=0 int=7
RParen 649:650
Newline 650:651
Ident 655:661 text="expect"
LParen 661:662
Await 662:667
Ident 668:669 text="f"
RParen 669:670
Dot 670:671
Ident 671:675 text="toBe"
LParen 675:676
Number 676:678 text="49" suf="" isf=0 int=49
RParen 678:679
Newline 679:680
RBrace 680:681
Newline 681:682
Newline 682:683
Ident 683:687 text="test"
Fn 688:690
Ident 691:717 text="await_inline_and_reawaited"
LParen 717:718
RParen 718:719
LBrace 720:721
Newline 721:722
Ident 726:732 text="expect"
LParen 732:733
Await 733:738
Ident 739:750 text="slow_square"
LParen 750:751
Number 751:752 text="6" suf="" isf=0 int=6
RParen 752:753
RParen 753:754
Dot 754:755
Ident 755:759 text="toBe"
LParen 759:760
Number 760:762 text="36" suf="" isf=0 int=36
RParen 762:763
Newline 763:764
Let 768:771
Ident 772:774 text="f2"
Assign 775:776
Ident 777:788 text="slow_square"
LParen 788:789
Number 789:790 text="3" suf="" isf=0 int=3
RParen 790:791
Newline 791:792
Ident 796:802 text="expect"
LParen 802:803
Await 803:808
Ident 809:811 text="f2"
RParen 811:812
Dot 812:813
Ident 813:817 text="toBe"
LParen 817:818
Number 818:819 text="9" suf="" isf=0 int=9
RParen 819:820
Newline 820:821
Ident 825:831 text="expect"
LParen 831:832
Await 832:837
Ident 838:840 text="f2"
RParen 840:841
Dot 841:842
Ident 842:846 text="toBe"
LParen 846:847
Number 847:848 text="9" suf="" isf=0 int=9
RParen 848:849
Newline 849:850
RBrace 850:851
Newline 851:852
Newline 852:853
Ident 853:857 text="test"
Fn 858:860
Ident 861:882 text="captures_are_per_call"
LParen 882:883
RParen 883:884
LBrace 885:886
Newline 886:887
Let 891:894
Ident 895:897 text="hi"
Assign 898:899
Ident 900:903 text="add"
LParen 903:904
Number 904:906 text="10" suf="" isf=0 int=10
Comma 906:907
Number 908:909 text="1" suf="" isf=0 int=1
RParen 909:910
Newline 910:911
Let 915:918
Ident 919:921 text="lo"
Assign 922:923
Ident 924:927 text="add"
LParen 927:928
Number 928:929 text="2" suf="" isf=0 int=2
Comma 929:930
Number 931:932 text="3" suf="" isf=0 int=3
RParen 932:933
Newline 933:934
Ident 938:944 text="expect"
LParen 944:945
Await 945:950
Ident 951:953 text="hi"
RParen 953:954
Dot 954:955
Ident 955:959 text="toBe"
LParen 959:960
Number 960:962 text="11" suf="" isf=0 int=11
RParen 962:963
Newline 963:964
Ident 968:974 text="expect"
LParen 974:975
Await 975:980
Ident 981:983 text="lo"
RParen 983:984
Dot 984:985
Ident 985:989 text="toBe"
LParen 989:990
Number 990:991 text="5" suf="" isf=0 int=5
RParen 991:992
Newline 992:993
RBrace 993:994
Newline 994:995
Newline 995:996
Ident 996:1000 text="test"
Fn 1001:1003
Ident 1004:1045 text="future_returning_future_from_nested_async"
LParen 1045:1046
RParen 1046:1047
LBrace 1048:1049
Newline 1049:1050
Newline 1125:1126
Newline 1190:1191
Ident 1195:1201 text="expect"
LParen 1201:1202
Await 1202:1207
Ident 1208:1212 text="ness"
LParen 1212:1213
Number 1213:1214 text="1" suf="" isf=0 int=1
RParen 1214:1215
RParen 1215:1216
Dot 1216:1217
Ident 1217:1221 text="toBe"
LParen 1221:1222
Number 1222:1225 text="101" suf="" isf=0 int=101
RParen 1225:1226
Newline 1226:1227
RBrace 1227:1228
Eof 1228:1228
