Class 0:5
Ident 6:16 text="EdgeHolder"
LBrace 17:18
Newline 18:19
Var 23:26
Ident 27:36 text="callEdges"
Colon 36:37
Ident 38:41 text="Map"
Lt 41:42
Ident 42:45 text="int"
Comma 45:46
Ident 47:51 text="List"
Lt 51:52
Ident 52:55 text="int"
Shr 55:57
Newline 57:58
Var 62:65
Ident 66:77 text="directThrow"
Colon 77:78
Ident 79:82 text="Map"
Lt 82:83
Ident 83:86 text="int"
Comma 86:87
Ident 88:92 text="bool"
Gt 92:93
Newline 93:94
Var 98:101
Ident 102:112 text="currentFid"
Colon 112:113
Ident 114:117 text="int"
Newline 117:118
Var 122:125
Ident 126:135 text="analyzing"
Colon 135:136
Ident 137:141 text="bool"
Newline 141:142
Newline 142:143
Fn 147:149
Ident 150:155 text="guard"
LParen 155:156
Ident 156:162 text="caller"
Colon 162:163
Ident 164:167 text="int"
Comma 167:168
Ident 169:175 text="callee"
Colon 175:176
Ident 177:180 text="int"
RParen 180:181
LBrace 182:183
Newline 183:184
If 192:194
LParen 195:196
This 196:200
Dot 200:201
Ident 201:210 text="analyzing"
RParen 210:211
LBrace 212:213
Newline 213:214
If 226:228
LParen 229:230
Let 230:233
Ident 234:238 text="some"
LParen 238:239
Ident 239:247 text="existing"
RParen 247:248
Assign 249:250
This 251:255
Dot 255:256
Ident 256:265 text="callEdges"
Dot 265:266
Get 266:269
LParen 269:270
Ident 270:276 text="caller"
RParen 276:277
RParen 277:278
LBrace 279:280
Newline 280:281
Ident 297:305 text="existing"
Dot 305:306
Ident 306:310 text="push"
LParen 310:311
Ident 311:317 text="callee"
RParen 317:318
Newline 318:319
RBrace 331:332
Else 333:337
LBrace 338:339
Newline 339:340
This 356:360
Dot 360:361
Ident 361:370 text="callEdges"
LBracket 370:371
Ident 371:377 text="caller"
RBracket 377:378
Assign 379:380
LBracket 381:382
Ident 382:388 text="callee"
RBracket 388:389
Newline 389:390
RBrace 402:403
Newline 403:404
RBrace 412:413
Newline 413:414
RBrace 418:419
Newline 419:420
Newline 420:421
Fn 425:427
Ident 428:438 text="markThrows"
LParen 438:439
Ident 439:442 text="fid"
Colon 442:443
Ident 444:447 text="int"
RParen 447:448
LBrace 449:450
Newline 450:451
If 459:461
LParen 462:463
This 463:467
Dot 467:468
Ident 468:477 text="analyzing"
RParen 477:478
LBrace 479:480
Newline 480:481
This 493:497
Dot 497:498
Ident 498:509 text="directThrow"
LBracket 509:510
Ident 510:513 text="fid"
RBracket 513:514
Assign 515:516
True 517:521
Newline 521:522
RBrace 530:531
Newline 531:532
RBrace 536:537
Newline 537:538
Newline 538:539
Fn 543:545
Ident 546:555 text="keysCount"
LParen 555:556
RParen 556:557
Arrow 558:560
Ident 561:564 text="int"
LBrace 565:566
Newline 566:567
Var 575:578
Ident 579:580 text="n"
Assign 581:582
Number 583:584 text="0" suf="" isf=0 int=0
Newline 584:585
For 593:596
LParen 597:598
Ident 598:599 text="k"
In 600:602
This 603:607
Dot 607:608
Ident 608:617 text="callEdges"
Dot 617:618
Ident 618:622 text="keys"
LParen 622:623
RParen 623:624
RParen 624:625
LBrace 626:627
Newline 627:628
Ident 640:641 text="n"
Assign 642:643
Ident 644:645 text="n"
Plus 646:647
Number 648:649 text="1" suf="" isf=0 int=1
Newline 649:650
RBrace 658:659
Newline 659:660
Ident 668:669 text="n"
Newline 669:670
RBrace 674:675
Newline 675:676
RBrace 676:677
Newline 677:678
Newline 678:679
Fn 679:681
Ident 682:696 text="seedIntBoolMap"
LParen 696:697
RParen 697:698
Arrow 699:701
Ident 702:705 text="Map"
Lt 705:706
Ident 706:709 text="int"
Comma 709:710
Ident 711:715 text="bool"
Gt 715:716
LBrace 717:718
Newline 718:719
Let 723:726
Ident 727:728 text="m"
Assign 729:730
LBrace 731:732
Number 732:733 text="0" suf="" isf=0 int=0
Colon 733:734
False 735:740
RBrace 740:741
Newline 741:742
Ident 746:747 text="m"
Dot 747:748
Ident 748:754 text="remove"
LParen 754:755
Number 755:756 text="0" suf="" isf=0 int=0
RParen 756:757
Newline 757:758
Ident 762:763 text="m"
Newline 763:764
RBrace 764:765
Newline 765:766
Newline 766:767
Fn 767:769
Ident 770:787 text="seedIntIntListMap"
LParen 787:788
RParen 788:789
Arrow 790:792
Ident 793:796 text="Map"
Lt 796:797
Ident 797:800 text="int"
Comma 800:801
Ident 802:806 text="List"
Lt 806:807
Ident 807:810 text="int"
Shr 810:812
LBrace 813:814
Newline 814:815
Let 819:822
Ident 823:824 text="m"
Assign 825:826
LBrace 827:828
Number 828:829 text="0" suf="" isf=0 int=0
Colon 829:830
Ident 831:840 text="emptyInts"
LParen 840:841
RParen 841:842
RBrace 842:843
Newline 843:844
Ident 848:849 text="m"
Dot 849:850
Ident 850:856 text="remove"
LParen 856:857
Number 857:858 text="0" suf="" isf=0 int=0
RParen 858:859
Newline 859:860
Ident 864:865 text="m"
Newline 865:866
RBrace 866:867
Newline 867:868
Newline 868:869
Fn 869:871
Ident 872:881 text="emptyInts"
LParen 881:882
RParen 882:883
Arrow 884:886
Ident 887:891 text="List"
Lt 891:892
Ident 892:895 text="int"
Gt 895:896
LBrace 897:898
Newline 898:899
Let 903:906
Ident 907:908 text="l"
Assign 909:910
LBracket 911:912
Number 912:913 text="0" suf="" isf=0 int=0
RBracket 913:914
Newline 914:915
Ident 919:920 text="l"
Dot 920:921
Ident 921:927 text="remove"
LParen 927:928
Number 928:929 text="0" suf="" isf=0 int=0
RParen 929:930
Newline 930:931
Ident 935:936 text="l"
Newline 936:937
RBrace 937:938
Newline 938:939
Newline 939:940
Fn 940:942
Ident 943:952 text="emptyStrs"
LParen 952:953
RParen 953:954
Arrow 955:957
Ident 958:962 text="List"
Lt 962:963
Ident 963:969 text="string"
Gt 969:970
LBrace 971:972
Newline 972:973
Let 977:980
Ident 981:982 text="l"
Assign 983:984
LBracket 985:986
Str 986:988
RBracket 988:989
Newline 989:990
Ident 994:995 text="l"
Dot 995:996
Ident 996:1002 text="remove"
LParen 1002:1003
Number 1003:1004 text="0" suf="" isf=0 int=0
RParen 1004:1005
Newline 1005:1006
Ident 1010:1011 text="l"
Newline 1011:1012
RBrace 1012:1013
Newline 1013:1014
Newline 1014:1015
Fn 1015:1017
Ident 1018:1026 text="bigChurn"
LParen 1026:1027
RParen 1027:1028
LBrace 1029:1030
Newline 1030:1031
Var 1035:1038
Ident 1039:1044 text="blobs"
Assign 1045:1046
Ident 1047:1056 text="emptyStrs"
LParen 1056:1057
RParen 1057:1058
Newline 1058:1059
Var 1063:1066
Ident 1067:1069 text="gz"
Assign 1070:1071
Number 1072:1073 text="0" suf="" isf=0 int=0
Newline 1073:1074
While 1078:1083
LParen 1084:1085
Ident 1085:1087 text="gz"
Lt 1088:1089
Number 1090:1094 text="1200" suf="" isf=0 int=1200
RParen 1094:1095
LBrace 1096:1097
Newline 1097:1098
Ident 1106:1111 text="blobs"
Dot 1111:1112
Ident 1112:1116 text="push"
LParen 1116:1117
Str 1117:1124 T("blob-")
Plus 1125:1126
Ident 1127:1130 text="str"
LParen 1130:1131
Ident 1131:1133 text="gz"
RParen 1133:1134
Plus 1135:1136
Str 1137:1176 T("-abcdefghijklmnopqrstuvwxyz0123456789")
RParen 1176:1177
Newline 1177:1178
Ident 1186:1188 text="gz"
Assign 1189:1190
Ident 1191:1193 text="gz"
Plus 1194:1195
Number 1196:1197 text="1" suf="" isf=0 int=1
Newline 1197:1198
RBrace 1202:1203
Newline 1203:1204
Var 1208:1211
Ident 1212:1214 text="l2"
Assign 1215:1216
Ident 1217:1226 text="emptyInts"
LParen 1226:1227
RParen 1227:1228
Newline 1228:1229
Var 1233:1236
Ident 1237:1239 text="g2"
Assign 1240:1241
Number 1242:1243 text="0" suf="" isf=0 int=0
Newline 1243:1244
While 1248:1253
LParen 1254:1255
Ident 1255:1257 text="g2"
Lt 1258:1259
Number 1260:1265 text="20000" suf="" isf=0 int=20000
RParen 1265:1266
LBrace 1267:1268
Newline 1268:1269
Ident 1277:1279 text="l2"
Dot 1279:1280
Ident 1280:1284 text="push"
LParen 1284:1285
Ident 1285:1287 text="g2"
RParen 1287:1288
Newline 1288:1289
Ident 1297:1299 text="g2"
Assign 1300:1301
Ident 1302:1304 text="g2"
Plus 1305:1306
Number 1307:1308 text="1" suf="" isf=0 int=1
Newline 1308:1309
RBrace 1313:1314
Newline 1314:1315
Var 1319:1322
Ident 1323:1325 text="m2"
Assign 1326:1327
Ident 1328:1342 text="seedIntBoolMap"
LParen 1342:1343
RParen 1343:1344
Newline 1344:1345
Var 1349:1352
Ident 1353:1355 text="g3"
Assign 1356:1357
Number 1358:1359 text="0" suf="" isf=0 int=0
Newline 1359:1360
While 1364:1369
LParen 1370:1371
Ident 1371:1373 text="g3"
Lt 1374:1375
Number 1376:1380 text="1200" suf="" isf=0 int=1200
RParen 1380:1381
LBrace 1382:1383
Newline 1383:1384
Ident 1392:1394 text="m2"
LBracket 1394:1395
Ident 1395:1397 text="g3"
RBracket 1397:1398
Assign 1399:1400
Ident 1401:1403 text="g3"
Percent 1404:1405
Number 1406:1407 text="2" suf="" isf=0 int=2
EqEq 1408:1410
Number 1411:1412 text="0" suf="" isf=0 int=0
Newline 1412:1413
Ident 1421:1423 text="g3"
Assign 1424:1425
Ident 1426:1428 text="g3"
Plus 1429:1430
Number 1431:1432 text="1" suf="" isf=0 int=1
Newline 1432:1433
RBrace 1437:1438
Newline 1438:1439
Ident 1443:1452 text="gcCollect"
LParen 1452:1453
True 1453:1457
RParen 1457:1458
Newline 1458:1459
RBrace 1459:1460
Newline 1460:1461
Newline 1461:1462
Fn 1462:1464
Ident 1465:1469 text="fill"
LParen 1469:1470
Ident 1470:1471 text="h"
Colon 1471:1472
Ident 1473:1483 text="EdgeHolder"
RParen 1483:1484
LBrace 1485:1486
Newline 1486:1487
Var 1491:1494
Ident 1495:1496 text="i"
Assign 1497:1498
Number 1499:1500 text="0" suf="" isf=0 int=0
Newline 1500:1501
While 1505:1510
LParen 1511:1512
Ident 1512:1513 text="i"
Lt 1514:1515
Number 1516:1519 text="150" suf="" isf=0 int=150
RParen 1519:1520
LBrace 1521:1522
Newline 1522:1523
Ident 1531:1532 text="h"
Dot 1532:1533
Ident 1533:1543 text="currentFid"
Assign 1544:1545
Ident 1546:1547 text="i"
Newline 1547:1548
Ident 1556:1557 text="h"
Dot 1557:1558
Ident 1558:1563 text="guard"
LParen 1563:1564
Ident 1564:1565 text="i"
Comma 1565:1566
LParen 1567:1568
Ident 1568:1569 text="i"
Star 1570:1571
Number 1572:1573 text="7" suf="" isf=0 int=7
RParen 1573:1574
Percent 1575:1576
Number 1577:1580 text="200" suf="" isf=0 int=200
RParen 1580:1581
Newline 1581:1582
Ident 1590:1591 text="h"
Dot 1591:1592
Ident 1592:1597 text="guard"
LParen 1597:1598
Ident 1598:1599 text="i"
Comma 1599:1600
LParen 1601:1602
Ident 1602:1603 text="i"
Star 1604:1605
Number 1606:1608 text="13" suf="" isf=0 int=13
Plus 1609:1610
Number 1611:1612 text="5" suf="" isf=0 int=5
RParen 1612:1613
Percent 1614:1615
Number 1616:1619 text="200" suf="" isf=0 int=200
RParen 1619:1620
Newline 1620:1621
If 1629:1631
LParen 1632:1633
Ident 1633:1634 text="i"
Percent 1635:1636
Number 1637:1638 text="3" suf="" isf=0 int=3
EqEq 1639:1641
Number 1642:1643 text="0" suf="" isf=0 int=0
RParen 1643:1644
LBrace 1645:1646
Newline 1646:1647
Ident 1659:1660 text="h"
Dot 1660:1661
Ident 1661:1671 text="markThrows"
LParen 1671:1672
Ident 1672:1673 text="i"
RParen 1673:1674
Newline 1674:1675
RBrace 1683:1684
Newline 1684:1685
Ident 1693:1694 text="i"
Assign 1695:1696
Ident 1697:1698 text="i"
Plus 1699:1700
Number 1701:1702 text="1" suf="" isf=0 int=1
Newline 1702:1703
RBrace 1707:1708
Newline 1708:1709
RBrace 1709:1710
Newline 1710:1711
Newline 1711:1712
Fn 1712:1714
Ident 1715:1725 text="runCompile"
LParen 1725:1726
RParen 1726:1727
Arrow 1728:1730
Ident 1731:1737 text="string"
LBrace 1738:1739
Newline 1739:1740
Let 1744:1747
Ident 1748:1749 text="h"
Assign 1750:1751
Ident 1752:1762 text="EdgeHolder"
LParen 1762:1763
Ident 1763:1780 text="seedIntIntListMap"
LParen 1780:1781
RParen 1781:1782
Comma 1782:1783
Ident 1784:1798 text="seedIntBoolMap"
LParen 1798:1799
RParen 1799:1800
Comma 1800:1801
Number 1802:1803 text="0" suf="" isf=0 int=0
Comma 1803:1804
True 1805:1809
RParen 1809:1810
Newline 1810:1811
Ident 1815:1819 text="fill"
LParen 1819:1820
Ident 1820:1821 text="h"
RParen 1821:1822
Newline 1822:1823
Ident 1827:1835 text="bigChurn"
LParen 1835:1836
RParen 1836:1837
Newline 1837:1838
Var 1842:1845
Ident 1846:1848 text="h2"
Assign 1849:1850
Ident 1851:1861 text="EdgeHolder"
LParen 1861:1862
Ident 1862:1879 text="seedIntIntListMap"
LParen 1879:1880
RParen 1880:1881
Comma 1881:1882
Ident 1883:1897 text="seedIntBoolMap"
LParen 1897:1898
RParen 1898:1899
Comma 1899:1900
Number 1901:1902 text="0" suf="" isf=0 int=0
Comma 1902:1903
True 1904:1908
RParen 1908:1909
Newline 1909:1910
Ident 1914:1918 text="fill"
LParen 1918:1919
Ident 1919:1921 text="h2"
RParen 1921:1922
Newline 1922:1923
Ident 1927:1936 text="gcCollect"
LParen 1936:1937
True 1937:1941
RParen 1941:1942
Newline 1942:1943
Ident 1947:1949 text="h2"
Dot 1949:1950
Ident 1950:1960 text="currentFid"
Assign 1961:1962
Number 1963:1966 text="777" suf="" isf=0 int=777
Newline 1966:1967
Ident 1971:1973 text="h2"
Dot 1973:1974
Ident 1974:1979 text="guard"
LParen 1979:1980
Number 1980:1983 text="777" suf="" isf=0 int=777
Comma 1983:1984
Number 1985:1988 text="100" suf="" isf=0 int=100
RParen 1988:1989
Newline 1989:1990
Ident 1994:2002 text="bigChurn"
LParen 2002:2003
RParen 2003:2004
Newline 2004:2005
Var 2009:2012
Ident 2013:2020 text="ceCount"
Assign 2021:2022
Ident 2023:2024 text="h"
Dot 2024:2025
Ident 2025:2034 text="keysCount"
LParen 2034:2035
RParen 2035:2036
Newline 2036:2037
Var 2041:2044
Ident 2045:2052 text="dtCount"
Assign 2053:2054
Number 2055:2056 text="0" suf="" isf=0 int=0
Newline 2056:2057
For 2061:2064
LParen 2065:2066
Ident 2066:2067 text="t"
In 2068:2070
Ident 2071:2072 text="h"
Dot 2072:2073
Ident 2073:2084 text="directThrow"
Dot 2084:2085
Ident 2085:2089 text="keys"
LParen 2089:2090
RParen 2090:2091
RParen 2091:2092
LBrace 2093:2094
Newline 2094:2095
Ident 2103:2110 text="dtCount"
Assign 2111:2112
Ident 2113:2120 text="dtCount"
Plus 2121:2122
Number 2123:2124 text="1" suf="" isf=0 int=1
Newline 2124:2125
RBrace 2129:2130
Newline 2130:2131
Var 2135:2138
Ident 2139:2145 text="verity"
Assign 2146:2147
True 2148:2152
Newline 2152:2153
Var 2157:2160
Ident 2161:2163 text="i2"
Assign 2164:2165
Number 2166:2167 text="0" suf="" isf=0 int=0
Newline 2167:2168
While 2172:2177
LParen 2178:2179
Ident 2179:2181 text="i2"
Lt 2182:2183
Number 2184:2187 text="150" suf="" isf=0 int=150
RParen 2187:2188
LBrace 2189:2190
Newline 2190:2191
Var 2199:2202
Ident 2203:2210 text="expectT"
Assign 2211:2212
Ident 2213:2215 text="i2"
Percent 2216:2217
Number 2218:2219 text="3" suf="" isf=0 int=3
EqEq 2220:2222
Number 2223:2224 text="0" suf="" isf=0 int=0
Newline 2224:2225
If 2233:2235
LParen 2236:2237
Ident 2237:2238 text="h"
Dot 2238:2239
Ident 2239:2250 text="directThrow"
LBracket 2250:2251
Ident 2251:2253 text="i2"
RBracket 2253:2254
NotEq 2255:2257
Ident 2258:2265 text="expectT"
RParen 2265:2266
LBrace 2267:2268
Newline 2268:2269
Ident 2281:2287 text="verity"
Assign 2288:2289
False 2290:2295
Newline 2295:2296
RBrace 2304:2305
Newline 2305:2306
If 2314:2316
LParen 2317:2318
Let 2318:2321
Ident 2322:2326 text="some"
LParen 2326:2327
Ident 2327:2330 text="got"
RParen 2330:2331
Assign 2332:2333
Ident 2334:2335 text="h"
Dot 2335:2336
Ident 2336:2345 text="callEdges"
Dot 2345:2346
Get 2346:2349
LParen 2349:2350
Ident 2350:2352 text="i2"
RParen 2352:2353
RParen 2353:2354
LBrace 2355:2356
Newline 2356:2357
If 2369:2371
LParen 2372:2373
Ident 2373:2376 text="len"
LParen 2376:2377
Ident 2377:2380 text="got"
RParen 2380:2381
NotEq 2382:2384
Number 2385:2386 text="2" suf="" isf=0 int=2
RParen 2386:2387
LBrace 2388:2389
Newline 2389:2390
Ident 2406:2412 text="verity"
Assign 2413:2414
False 2415:2420
Newline 2420:2421
RBrace 2433:2434
Newline 2434:2435
RBrace 2443:2444
Else 2445:2449
LBrace 2450:2451
Newline 2451:2452
Ident 2464:2470 text="verity"
Assign 2471:2472
False 2473:2478
Newline 2478:2479
RBrace 2487:2488
Newline 2488:2489
Ident 2497:2499 text="i2"
Assign 2500:2501
Ident 2502:2504 text="i2"
Plus 2505:2506
Number 2507:2508 text="1" suf="" isf=0 int=1
Newline 2508:2509
RBrace 2513:2514
Newline 2514:2515
If 2519:2521
LParen 2522:2523
Ident 2523:2530 text="ceCount"
EqEq 2531:2533
Number 2534:2537 text="150" suf="" isf=0 int=150
AndAnd 2538:2540
Ident 2541:2548 text="dtCount"
EqEq 2549:2551
Number 2552:2554 text="50" suf="" isf=0 int=50
AndAnd 2555:2557
Ident 2558:2564 text="verity"
AndAnd 2565:2567
Ident 2568:2570 text="h2"
Dot 2570:2571
Ident 2571:2580 text="keysCount"
LParen 2580:2581
RParen 2581:2582
EqEq 2583:2585
Number 2586:2589 text="151" suf="" isf=0 int=151
RParen 2589:2590
LBrace 2591:2592
Newline 2592:2593
Return 2601:2607
Str 2608:2612 T("ST")
Newline 2612:2613
RBrace 2617:2618
Newline 2618:2619
Str 2623:2632 T("VAR ce=")
Plus 2633:2634
Ident 2635:2638 text="str"
LParen 2638:2639
Ident 2639:2646 text="ceCount"
RParen 2646:2647
Plus 2648:2649
Str 2650:2656 T(" dt=")
Plus 2657:2658
Ident 2659:2662 text="str"
LParen 2662:2663
Ident 2663:2670 text="dtCount"
RParen 2670:2671
Plus 2672:2673
Str 2674:2681 T(" ver=")
Plus 2682:2683
Ident 2684:2687 text="str"
LParen 2687:2688
Ident 2688:2694 text="verity"
RParen 2694:2695
Plus 2696:2697
Str 2698:2704 T(" h2=")
Plus 2705:2706
Ident 2707:2710 text="str"
LParen 2710:2711
Ident 2711:2713 text="h2"
Dot 2713:2714
Ident 2714:2723 text="keysCount"
LParen 2723:2724
RParen 2724:2725
RParen 2725:2726
Newline 2726:2727
RBrace 2727:2728
Newline 2728:2729
Newline 2729:2730
Fn 2730:2732
Ident 2733:2737 text="main"
LParen 2737:2738
RParen 2738:2739
LBrace 2740:2741
Newline 2741:2742
Var 2746:2749
Ident 2750:2753 text="out"
Assign 2754:2755
Str 2756:2758
Newline 2758:2759
Var 2763:2766
Ident 2767:2768 text="r"
Assign 2769:2770
Number 2771:2772 text="0" suf="" isf=0 int=0
Newline 2772:2773
While 2777:2782
LParen 2783:2784
Ident 2784:2785 text="r"
Lt 2786:2787
Number 2788:2789 text="5" suf="" isf=0 int=5
RParen 2789:2790
LBrace 2791:2792
Newline 2792:2793
Ident 2801:2804 text="out"
Assign 2805:2806
Ident 2807:2810 text="out"
Plus 2811:2812
Ident 2813:2823 text="runCompile"
LParen 2823:2824
RParen 2824:2825
Plus 2826:2827
Str 2828:2831 T(";")
Newline 2831:2832
Ident 2840:2841 text="r"
Assign 2842:2843
Ident 2844:2845 text="r"
Plus 2846:2847
Number 2848:2849 text="1" suf="" isf=0 int=1
Newline 2849:2850
RBrace 2854:2855
Newline 2855:2856
Ident 2860:2865 text="print"
LParen 2865:2866
Ident 2866:2869 text="out"
RParen 2869:2870
Newline 2870:2871
RBrace 2871:2872
Eof 2872:2872
