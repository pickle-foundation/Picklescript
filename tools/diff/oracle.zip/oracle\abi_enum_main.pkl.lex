Module 0:6
Ident 7:12 text="tests"
Dot 12:13
Ident 13:19 text="pickle"
Dot 19:20
Ident 20:33 text="abi_enum_main"
Newline 33:34
Newline 34:35
Newline 75:76
Newline 79:80
Newline 164:165
Newline 245:246
Newline 320:321
Newline 380:381
Newline 381:382
Import 382:388 doc="Parity main for the ported enum ABI.\nPrints only what the native runtime would print for the same program, so the JIT\nand AOT stdout can be compared byte for byte. Every value printed is one the\nnative side derives independently, which is what makes the equality in\n`pickle_enum_eq` checkable from outside the unit suite."
LBrace 389:390
Ident 391:398 text="enumNew"
Comma 398:399
Ident 400:414 text="enumFieldCount"
Comma 414:415
Ident 416:426 text="f64ValueEq"
RBrace 427:428
From 429:433
Ident 434:441 text="runtime"
Dot 441:442
Ident 442:450 text="abi_enum"
Newline 450:451
Import 451:457
LBrace 458:459
Ident 460:470 text="abiEnumNew"
Comma 470:471
Ident 472:482 text="abiEnumTag"
Comma 482:483
Ident 484:496 text="abiEnumField"
Comma 496:497
Ident 498:513 text="abiEnumSetField"
Comma 513:514
Ident 515:524 text="abiEnumEq"
RBrace 525:526
From 527:531
Ident 532:539 text="runtime"
Dot 539:540
Ident 540:548 text="abi_enum"
Newline 548:549
Import 549:555
LBrace 556:557
Ident 558:567 text="abiBoxI64"
Comma 567:568
Ident 569:579 text="abiBoxBool"
Comma 579:580
Ident 581:591 text="abiBoxChar"
Comma 591:592
Ident 593:604 text="abiUnboxI64"
RBrace 605:606
From 607:611
Ident 612:619 text="runtime"
Dot 619:620
Ident 620:627 text="abi_box"
Newline 627:628
Import 628:634
LBrace 635:636
Ident 637:652 text="abiStrFromBytes"
RBrace 653:654
From 655:659
Ident 660:667 text="runtime"
Dot 667:668
Ident 668:678 text="abi_string"
Newline 678:679
Import 679:685
LBrace 686:687
Ident 688:696 text="tupleNew"
RBrace 697:698
From 699:703
Ident 704:711 text="runtime"
Dot 711:712
Ident 712:721 text="abi_tuple"
Newline 721:722
Import 722:728
LBrace 729:730
Ident 731:737 text="HEADER"
Comma 737:738
Ident 739:751 text="ENUM_TAG_OFF"
Comma 751:752
Ident 753:768 text="ENUM_FIELDS_OFF"
RBrace 769:770
From 771:775
Ident 776:783 text="runtime"
Dot 783:784
Ident 784:790 text="layout"
Newline 790:791
Newline 791:792
Newline 826:827
Const 827:832 doc="Word index of the variant tag."
Ident 833:841 text="TAG_WORD"
Colon 841:842
Ident 843:846 text="int"
Assign 847:848
Ident 849:861 text="ENUM_TAG_OFF"
Slash 862:863
Number 864:865 text="8" suf="" isf=0 int=8
Newline 865:866
Newline 900:901
Const 901:906 doc="Word index of payload field 0."
Ident 907:918 text="FIELDS_WORD"
Colon 918:919
Ident 920:923 text="int"
Assign 924:925
Ident 926:941 text="ENUM_FIELDS_OFF"
Slash 942:943
Number 944:945 text="8" suf="" isf=0 int=8
Newline 945:946
Newline 946:947
Newline 1025:1026
Fn 1026:1028 doc="One raw byte in its own word; `abiStrFromBytes` reads through its pointer."
Ident 1029:1035 text="byteAt"
LParen 1035:1036
Ident 1036:1037 text="b"
Colon 1037:1038
Ident 1039:1042 text="int"
RParen 1042:1043
Arrow 1044:1046
Star 1047:1048
Ident 1048:1051 text="int"
LBrace 1052:1053
Newline 1053:1054
Unsafe 1058:1064
LBrace 1065:1066
Newline 1066:1067
Var 1075:1078
Ident 1079:1080 text="p"
Assign 1081:1082
Ident 1083:1088 text="alloc"
LParen 1088:1089
Ident 1089:1092 text="int"
Comma 1092:1093
Number 1094:1095 text="1" suf="" isf=0 int=1
RParen 1095:1096
Newline 1096:1097
Ident 1105:1106 text="p"
LBracket 1106:1107
Number 1107:1108 text="0" suf="" isf=0 int=0
RBracket 1108:1109
Assign 1110:1111
Ident 1112:1113 text="b"
Newline 1113:1114
Return 1122:1128
Ident 1129:1130 text="p"
Newline 1130:1131
RBrace 1135:1136
Newline 1136:1137
RBrace 1137:1138
Newline 1138:1139
Newline 1139:1140
Newline 1226:1227
Newline 1303:1304
Fn 1304:1306 doc="A float box built by hand: the float half of the box ABI is not ported, so the raw\npayload has to be written directly. Class 4 is `PICKLE_CLASS_BOX_FLOAT`."
Ident 1307:1315 text="floatBox"
LParen 1315:1316
Ident 1316:1320 text="bits"
Colon 1320:1321
Ident 1322:1325 text="int"
RParen 1325:1326
Arrow 1327:1329
Star 1330:1331
Ident 1331:1334 text="int"
LBrace 1335:1336
Newline 1336:1337
Unsafe 1341:1347
LBrace 1348:1349
Newline 1349:1350
Var 1358:1361
Ident 1362:1363 text="p"
Assign 1364:1365
Ident 1366:1371 text="alloc"
LParen 1371:1372
Ident 1372:1375 text="int"
Comma 1375:1376
Number 1377:1378 text="4" suf="" isf=0 int=4
RParen 1378:1379
Newline 1379:1380
Ident 1388:1389 text="p"
LBracket 1389:1390
Number 1390:1391 text="0" suf="" isf=0 int=0
RBracket 1391:1392
Assign 1393:1394
Number 1395:1396 text="0" suf="" isf=0 int=0
Newline 1396:1397
Ident 1405:1406 text="p"
LBracket 1406:1407
Number 1407:1408 text="1" suf="" isf=0 int=1
RBracket 1408:1409
Assign 1410:1411
Number 1412:1413 text="4" suf="" isf=0 int=4
Newline 1413:1414
Ident 1422:1423 text="p"
LBracket 1423:1424
Number 1424:1425 text="2" suf="" isf=0 int=2
RBracket 1425:1426
Assign 1427:1428
Number 1429:1431 text="32" suf="" isf=0 int=32
Newline 1431:1432
Ident 1440:1441 text="p"
LBracket 1441:1442
Number 1442:1443 text="3" suf="" isf=0 int=3
RBracket 1443:1444
Assign 1445:1446
Ident 1447:1451 text="bits"
Newline 1451:1452
Return 1460:1466
Ident 1467:1468 text="p"
Newline 1468:1469
RBrace 1473:1474
Newline 1474:1475
RBrace 1475:1476
Newline 1476:1477
Newline 1477:1478
Newline 1556:1557
Fn 1557:1559 doc="Print the shape of an enum: class id, byte size, derived field count, tag."
Ident 1560:1564 text="show"
LParen 1564:1565
Ident 1565:1570 text="label"
Colon 1570:1571
Ident 1572:1578 text="string"
Comma 1578:1579
Ident 1580:1581 text="e"
Colon 1581:1582
Star 1583:1584
Ident 1584:1587 text="int"
RParen 1587:1588
LBrace 1589:1590
Newline 1590:1591
Unsafe 1595:1601
LBrace 1602:1603
Newline 1603:1604
Ident 1612:1619 text="println"
LParen 1619:1620
Str 1620:1704 T("  ") E[Ident 1624:1629 text="label"; Eof 1630:1630] T(": class=") E[Ident 1639:1640 text="e"; LBracket 1640:1641; Number 1641:1642 text="1" suf="" isf=0 int=1; RBracket 1642:1643; Eof 1644:1644] T(" size=") E[Ident 1651:1652 text="e"; LBracket 1652:1653; Number 1653:1654 text="2" suf="" isf=0 int=2; RBracket 1654:1655; Eof 1656:1656] T(" fields=") E[Ident 1665:1679 text="enumFieldCount"; LParen 1679:1680; Ident 1680:1681 text="e"; RParen 1681:1682; Eof 1683:1683] T(" tag=") E[Ident 1689:1699 text="abiEnumTag"; LParen 1699:1700; Ident 1700:1701 text="e"; RParen 1701:1702; Eof 1703:1703]
RParen 1704:1705
Newline 1705:1706
RBrace 1710:1711
Newline 1711:1712
RBrace 1712:1713
Newline 1713:1714
Newline 1714:1715
Fn 1715:1717
Ident 1718:1722 text="main"
LParen 1722:1723
RParen 1723:1724
LBrace 1725:1726
Newline 1726:1727
Ident 1731:1738 text="println"
LParen 1738:1739
Str 1739:1759 T("== construction ==")
RParen 1759:1760
Newline 1760:1761
Ident 1765:1769 text="show"
LParen 1769:1770
Str 1770:1781 T("empty 0/0")
Comma 1781:1782
Ident 1783:1790 text="enumNew"
LParen 1790:1791
Number 1791:1792 text="0" suf="" isf=0 int=0
Comma 1792:1793
Number 1794:1795 text="0" suf="" isf=0 int=0
RParen 1795:1796
RParen 1796:1797
Newline 1797:1798
Ident 1802:1806 text="show"
LParen 1806:1807
Str 1807:1817 T("unit 5/0")
Comma 1817:1818
Ident 1819:1826 text="enumNew"
LParen 1826:1827
Number 1827:1828 text="5" suf="" isf=0 int=5
Comma 1828:1829
Number 1830:1831 text="0" suf="" isf=0 int=0
RParen 1831:1832
RParen 1832:1833
Newline 1833:1834
Ident 1838:1842 text="show"
LParen 1842:1843
Str 1843:1852 T("one 7/1")
Comma 1852:1853
Ident 1854:1861 text="enumNew"
LParen 1861:1862
Number 1862:1863 text="7" suf="" isf=0 int=7
Comma 1863:1864
Number 1865:1866 text="1" suf="" isf=0 int=1
RParen 1866:1867
RParen 1867:1868
Newline 1868:1869
Ident 1873:1877 text="show"
LParen 1877:1878
Str 1878:1890 T("three -2/3")
Comma 1890:1891
Ident 1892:1899 text="enumNew"
LParen 1899:1900
Minus 1900:1901
Number 1901:1902 text="2" suf="" isf=0 int=2
Comma 1902:1903
Number 1904:1905 text="3" suf="" isf=0 int=3
RParen 1905:1906
RParen 1906:1907
Newline 1907:1908
Newline 1908:1909
Ident 1913:1920 text="println"
LParen 1920:1921
Str 1921:1941 T("== header words ==")
RParen 1941:1942
Newline 1942:1943
Var 1947:1950
Ident 1951:1952 text="h"
Assign 1953:1954
Ident 1955:1962 text="enumNew"
LParen 1962:1963
Number 1963:1965 text="11" suf="" isf=0 int=11
Comma 1965:1966
Number 1967:1968 text="2" suf="" isf=0 int=2
RParen 1968:1969
Newline 1969:1970
Unsafe 1974:1980
LBrace 1981:1982
Newline 1982:1983
Var 1991:1994
Ident 1995:2002 text="tagWord"
Assign 2003:2004
Ident 2005:2006 text="h"
LBracket 2006:2007
Ident 2007:2015 text="TAG_WORD"
RBracket 2015:2016
Newline 2016:2017
Var 2025:2028
Ident 2029:2035 text="field0"
Assign 2036:2037
Ident 2038:2039 text="h"
LBracket 2039:2040
Ident 2040:2051 text="FIELDS_WORD"
RBracket 2051:2052
Newline 2052:2053
Var 2061:2064
Ident 2065:2071 text="field1"
Assign 2072:2073
Ident 2074:2075 text="h"
LBracket 2075:2076
Ident 2076:2087 text="FIELDS_WORD"
Plus 2088:2089
Number 2090:2091 text="1" suf="" isf=0 int=1
RBracket 2091:2092
Newline 2092:2093
Ident 2101:2108 text="println"
LParen 2108:2109
Str 2109:2199 T("  next=") E[Ident 2118:2119 text="h"; LBracket 2119:2120; Number 2120:2121 text="0" suf="" isf=0 int=0; RBracket 2121:2122; Eof 2123:2123] T(" class=") E[Ident 2131:2132 text="h"; LBracket 2132:2133; Number 2133:2134 text="1" suf="" isf=0 int=1; RBracket 2134:2135; Eof 2136:2136] T(" size=") E[Ident 2143:2144 text="h"; LBracket 2144:2145; Number 2145:2146 text="2" suf="" isf=0 int=2; RBracket 2146:2147; Eof 2148:2148] T(" tagWord=") E[Ident 2158:2165 text="tagWord"; Eof 2166:2166] T(" field0=") E[Ident 2175:2181 text="field0"; Eof 2182:2182] T(" field1=") E[Ident 2191:2197 text="field1"; Eof 2198:2198]
RParen 2199:2200
Newline 2200:2201
RBrace 2205:2206
Newline 2206:2207
Ident 2211:2218 text="println"
LParen 2218:2219
Str 2219:2300 T("  HEADER=") E[Ident 2230:2236 text="HEADER"; Eof 2237:2237] T(" ENUM_TAG_OFF=") E[Ident 2252:2264 text="ENUM_TAG_OFF"; Eof 2265:2265] T(" ENUM_FIELDS_OFF=") E[Ident 2283:2298 text="ENUM_FIELDS_OFF"; Eof 2299:2299]
RParen 2300:2301
Newline 2301:2302
Newline 2302:2303
Ident 2307:2314 text="println"
LParen 2314:2315
Str 2315:2335 T("== field access ==")
RParen 2335:2336
Newline 2336:2337
Var 2341:2344
Ident 2345:2346 text="f"
Assign 2347:2348
Ident 2349:2356 text="enumNew"
LParen 2356:2357
Number 2357:2358 text="3" suf="" isf=0 int=3
Comma 2358:2359
Number 2360:2361 text="3" suf="" isf=0 int=3
RParen 2361:2362
Newline 2362:2363
Ident 2367:2382 text="abiEnumSetField"
LParen 2382:2383
Ident 2383:2384 text="f"
Comma 2384:2385
Number 2386:2387 text="0" suf="" isf=0 int=0
Comma 2387:2388
Ident 2389:2398 text="abiBoxI64"
LParen 2398:2399
Number 2399:2401 text="10" suf="" isf=0 int=10
RParen 2401:2402
RParen 2402:2403
Newline 2403:2404
Ident 2408:2423 text="abiEnumSetField"
LParen 2423:2424
Ident 2424:2425 text="f"
Comma 2425:2426
Number 2427:2428 text="1" suf="" isf=0 int=1
Comma 2428:2429
Ident 2430:2439 text="abiBoxI64"
LParen 2439:2440
Number 2440:2442 text="20" suf="" isf=0 int=20
RParen 2442:2443
RParen 2443:2444
Newline 2444:2445
Ident 2449:2464 text="abiEnumSetField"
LParen 2464:2465
Ident 2465:2466 text="f"
Comma 2466:2467
Number 2468:2469 text="2" suf="" isf=0 int=2
Comma 2469:2470
Ident 2471:2480 text="abiBoxI64"
LParen 2480:2481
Number 2481:2483 text="30" suf="" isf=0 int=30
RParen 2483:2484
RParen 2484:2485
Newline 2485:2486
Ident 2490:2497 text="println"
LParen 2497:2498
Str 2498:2547 T("  tag=") E[Ident 2506:2516 text="abiEnumTag"; LParen 2516:2517; Ident 2517:2518 text="f"; RParen 2518:2519; Eof 2520:2520] T(" count=") E[Ident 2528:2542 text="enumFieldCount"; LParen 2542:2543; Ident 2543:2544 text="f"; RParen 2544:2545; Eof 2546:2546]
RParen 2547:2548
Newline 2548:2549
Var 2553:2556
Ident 2557:2558 text="i"
Assign 2559:2560
Number 2561:2562 text="0" suf="" isf=0 int=0
Newline 2562:2563
While 2567:2572
LParen 2573:2574
Ident 2574:2575 text="i"
Lt 2576:2577
Number 2578:2579 text="3" suf="" isf=0 int=3
RParen 2579:2580
LBrace 2581:2582
Newline 2582:2583
Ident 2591:2598 text="println"
LParen 2598:2599
Str 2599:2647 T("  field[") E[Ident 2609:2610 text="i"; Eof 2611:2611] T("]=") E[Ident 2614:2625 text="abiUnboxI64"; LParen 2625:2626; Ident 2626:2638 text="abiEnumField"; LParen 2638:2639; Ident 2639:2640 text="f"; Comma 2640:2641; Ident 2642:2643 text="i"; RParen 2643:2644; RParen 2644:2645; Eof 2646:2646]
RParen 2647:2648
Newline 2648:2649
Ident 2657:2658 text="i"
Assign 2659:2660
Ident 2661:2662 text="i"
Plus 2663:2664
Number 2665:2666 text="1" suf="" isf=0 int=1
Newline 2666:2667
RBrace 2671:2672
Newline 2672:2673
Ident 2677:2684 text="println"
LParen 2684:2685
Str 2685:2736 T("  out of range high=") E[LParen 2707:2708; Ident 2708:2720 text="abiEnumField"; LParen 2720:2721; Ident 2721:2722 text="f"; Comma 2722:2723; Number 2724:2725 text="3" suf="" isf=0 int=3; RParen 2725:2726; As 2727:2729; Ident 2730:2733 text="int"; RParen 2733:2734; Eof 2735:2735]
RParen 2736:2737
Newline 2737:2738
Ident 2742:2749 text="println"
LParen 2749:2750
Str 2750:2803 T("  out of range far=") E[LParen 2771:2772; Ident 2772:2784 text="abiEnumField"; LParen 2784:2785; Ident 2785:2786 text="f"; Comma 2786:2787; Number 2788:2792 text="1000" suf="" isf=0 int=1000; RParen 2792:2793; As 2794:2796; Ident 2797:2800 text="int"; RParen 2800:2801; Eof 2802:2802]
RParen 2803:2804
Newline 2804:2805
Newline 2805:2806
Ident 2810:2817 text="println"
LParen 2817:2818
Str 2818:2857 T("== out of range writes are ignored ==")
RParen 2857:2858
Newline 2858:2859
Var 2863:2866
Ident 2867:2868 text="g"
Assign 2869:2870
Ident 2871:2878 text="enumNew"
LParen 2878:2879
Number 2879:2880 text="1" suf="" isf=0 int=1
Comma 2880:2881
Number 2882:2883 text="2" suf="" isf=0 int=2
RParen 2883:2884
Newline 2884:2885
Ident 2889:2904 text="abiEnumSetField"
LParen 2904:2905
Ident 2905:2906 text="g"
Comma 2906:2907
Number 2908:2909 text="0" suf="" isf=0 int=0
Comma 2909:2910
Ident 2911:2920 text="abiBoxI64"
LParen 2920:2921
Number 2921:2922 text="5" suf="" isf=0 int=5
RParen 2922:2923
RParen 2923:2924
Newline 2924:2925
Ident 2929:2944 text="abiEnumSetField"
LParen 2944:2945
Ident 2945:2946 text="g"
Comma 2946:2947
Number 2948:2949 text="5" suf="" isf=0 int=5
Comma 2949:2950
Ident 2951:2960 text="abiBoxI64"
LParen 2960:2961
Number 2961:2964 text="555" suf="" isf=0 int=555
RParen 2964:2965
RParen 2965:2966
Newline 2966:2967
Ident 2971:2978 text="println"
LParen 2978:2979
Str 2979:3080 T("  field0=") E[Ident 2990:3001 text="abiUnboxI64"; LParen 3001:3002; Ident 3002:3014 text="abiEnumField"; LParen 3014:3015; Ident 3015:3016 text="g"; Comma 3016:3017; Number 3018:3019 text="0" suf="" isf=0 int=0; RParen 3019:3020; RParen 3020:3021; Eof 3022:3022] T(" field1=") E[LParen 3031:3032; Ident 3032:3044 text="abiEnumField"; LParen 3044:3045; Ident 3045:3046 text="g"; Comma 3046:3047; Number 3048:3049 text="1" suf="" isf=0 int=1; RParen 3049:3050; As 3051:3053; Ident 3054:3057 text="int"; RParen 3057:3058; Eof 3059:3059] T(" tag=") E[Ident 3065:3075 text="abiEnumTag"; LParen 3075:3076; Ident 3076:3077 text="g"; RParen 3077:3078; Eof 3079:3079]
RParen 3080:3081
Newline 3081:3082
Newline 3082:3083
Ident 3087:3094 text="println"
LParen 3094:3095
Str 3095:3131 T("== equality: identity and shape ==")
RParen 3131:3132
Newline 3132:3133
Var 3137:3140
Ident 3141:3143 text="e2"
Assign 3144:3145
Ident 3146:3153 text="enumNew"
LParen 3153:3154
Number 3154:3155 text="1" suf="" isf=0 int=1
Comma 3155:3156
Number 3157:3158 text="2" suf="" isf=0 int=2
RParen 3158:3159
Newline 3159:3160
Var 3164:3167
Ident 3168:3171 text="nul"
Assign 3172:3173
Number 3174:3175 text="0" suf="" isf=0 int=0
As 3176:3178
Star 3179:3180
Ident 3180:3183 text="int"
Newline 3183:3184
Ident 3188:3195 text="println"
LParen 3195:3196
Str 3196:3232 T("  same pointer=") E[Ident 3213:3222 text="abiEnumEq"; LParen 3222:3223; Ident 3223:3225 text="e2"; Comma 3225:3226; Ident 3227:3229 text="e2"; RParen 3229:3230; Eof 3231:3231]
RParen 3232:3233
Newline 3233:3234
Ident 3238:3245 text="println"
LParen 3245:3246
Str 3246:3311 T("  null-null=") E[Ident 3260:3269 text="abiEnumEq"; LParen 3269:3270; Ident 3270:3273 text="nul"; Comma 3273:3274; Ident 3275:3278 text="nul"; RParen 3278:3279; Eof 3280:3280] T(" obj-null=") E[Ident 3291:3300 text="abiEnumEq"; LParen 3300:3301; Ident 3301:3303 text="e2"; Comma 3303:3304; Ident 3305:3308 text="nul"; RParen 3308:3309; Eof 3310:3310]
RParen 3311:3312
Newline 3312:3313
Newline 3313:3314
Ident 3318:3325 text="println"
LParen 3325:3326
Str 3326:3359 T("== equality: tagged payloads ==")
RParen 3359:3360
Newline 3360:3361
Var 3365:3368
Ident 3369:3371 text="t1"
Assign 3372:3373
Ident 3374:3381 text="enumNew"
LParen 3381:3382
Number 3382:3383 text="0" suf="" isf=0 int=0
Comma 3383:3384
Number 3385:3386 text="3" suf="" isf=0 int=3
RParen 3386:3387
Newline 3387:3388
Var 3392:3395
Ident 3396:3398 text="t2"
Assign 3399:3400
Ident 3401:3408 text="enumNew"
LParen 3408:3409
Number 3409:3410 text="0" suf="" isf=0 int=0
Comma 3410:3411
Number 3412:3413 text="3" suf="" isf=0 int=3
RParen 3413:3414
Newline 3414:3415
Ident 3419:3434 text="abiEnumSetField"
LParen 3434:3435
Ident 3435:3437 text="t1"
Comma 3437:3438
Number 3439:3440 text="0" suf="" isf=0 int=0
Comma 3440:3441
Ident 3442:3451 text="abiBoxI64"
LParen 3451:3452
Number 3452:3454 text="42" suf="" isf=0 int=42
RParen 3454:3455
RParen 3455:3456
Newline 3456:3457
Ident 3461:3476 text="abiEnumSetField"
LParen 3476:3477
Ident 3477:3479 text="t2"
Comma 3479:3480
Number 3481:3482 text="0" suf="" isf=0 int=0
Comma 3482:3483
Ident 3484:3493 text="abiBoxI64"
LParen 3493:3494
Number 3494:3496 text="42" suf="" isf=0 int=42
RParen 3496:3497
RParen 3497:3498
Newline 3498:3499
Ident 3503:3518 text="abiEnumSetField"
LParen 3518:3519
Ident 3519:3521 text="t1"
Comma 3521:3522
Number 3523:3524 text="1" suf="" isf=0 int=1
Comma 3524:3525
Ident 3526:3536 text="abiBoxBool"
LParen 3536:3537
True 3537:3541
RParen 3541:3542
RParen 3542:3543
Newline 3543:3544
Ident 3548:3563 text="abiEnumSetField"
LParen 3563:3564
Ident 3564:3566 text="t2"
Comma 3566:3567
Number 3568:3569 text="1" suf="" isf=0 int=1
Comma 3569:3570
Ident 3571:3581 text="abiBoxBool"
LParen 3581:3582
True 3582:3586
RParen 3586:3587
RParen 3587:3588
Newline 3588:3589
Ident 3593:3608 text="abiEnumSetField"
LParen 3608:3609
Ident 3609:3611 text="t1"
Comma 3611:3612
Number 3613:3614 text="2" suf="" isf=0 int=2
Comma 3614:3615
Ident 3616:3626 text="abiBoxChar"
LParen 3626:3627
Number 3627:3629 text="90" suf="" isf=0 int=90
RParen 3629:3630
RParen 3630:3631
Newline 3631:3632
Ident 3636:3651 text="abiEnumSetField"
LParen 3651:3652
Ident 3652:3654 text="t2"
Comma 3654:3655
Number 3656:3657 text="2" suf="" isf=0 int=2
Comma 3657:3658
Ident 3659:3669 text="abiBoxChar"
LParen 3669:3670
Number 3670:3672 text="90" suf="" isf=0 int=90
RParen 3672:3673
RParen 3673:3674
Newline 3674:3675
Ident 3679:3686 text="println"
LParen 3686:3687
Str 3687:3716 T("  equal=") E[Ident 3697:3706 text="abiEnumEq"; LParen 3706:3707; Ident 3707:3709 text="t1"; Comma 3709:3710; Ident 3711:3713 text="t2"; RParen 3713:3714; Eof 3715:3715]
RParen 3716:3717
Newline 3717:3718
Ident 3722:3737 text="abiEnumSetField"
LParen 3737:3738
Ident 3738:3740 text="t2"
Comma 3740:3741
Number 3742:3743 text="0" suf="" isf=0 int=0
Comma 3743:3744
Ident 3745:3754 text="abiBoxI64"
LParen 3754:3755
Number 3755:3757 text="43" suf="" isf=0 int=43
RParen 3757:3758
RParen 3758:3759
Newline 3759:3760
Ident 3764:3771 text="println"
LParen 3771:3772
Str 3772:3812 T("  after int change=") E[Ident 3793:3802 text="abiEnumEq"; LParen 3802:3803; Ident 3803:3805 text="t1"; Comma 3805:3806; Ident 3807:3809 text="t2"; RParen 3809:3810; Eof 3811:3811]
RParen 3812:3813
Newline 3813:3814
Var 3818:3821
Ident 3822:3824 text="t3"
Assign 3825:3826
Ident 3827:3834 text="enumNew"
LParen 3834:3835
Number 3835:3836 text="1" suf="" isf=0 int=1
Comma 3836:3837
Number 3838:3839 text="3" suf="" isf=0 int=3
RParen 3839:3840
Newline 3840:3841
Ident 3845:3860 text="abiEnumSetField"
LParen 3860:3861
Ident 3861:3863 text="t3"
Comma 3863:3864
Number 3865:3866 text="0" suf="" isf=0 int=0
Comma 3866:3867
Ident 3868:3877 text="abiBoxI64"
LParen 3877:3878
Number 3878:3880 text="42" suf="" isf=0 int=42
RParen 3880:3881
RParen 3881:3882
Newline 3882:3883
Ident 3887:3902 text="abiEnumSetField"
LParen 3902:3903
Ident 3903:3905 text="t3"
Comma 3905:3906
Number 3907:3908 text="1" suf="" isf=0 int=1
Comma 3908:3909
Ident 3910:3920 text="abiBoxBool"
LParen 3920:3921
True 3921:3925
RParen 3925:3926
RParen 3926:3927
Newline 3927:3928
Ident 3932:3947 text="abiEnumSetField"
LParen 3947:3948
Ident 3948:3950 text="t3"
Comma 3950:3951
Number 3952:3953 text="2" suf="" isf=0 int=2
Comma 3953:3954
Ident 3955:3965 text="abiBoxChar"
LParen 3965:3966
Number 3966:3968 text="90" suf="" isf=0 int=90
RParen 3968:3969
RParen 3969:3970
Newline 3970:3971
Ident 3975:3982 text="println"
LParen 3982:3983
Str 3983:4023 T("  after tag change=") E[Ident 4004:4013 text="abiEnumEq"; LParen 4013:4014; Ident 4014:4016 text="t1"; Comma 4016:4017; Ident 4018:4020 text="t3"; RParen 4020:4021; Eof 4022:4022]
RParen 4023:4024
Newline 4024:4025
Newline 4025:4026
Ident 4030:4037 text="println"
LParen 4037:4038
Str 4038:4090 T("== equality: int and bool are different classes ==")
RParen 4090:4091
Newline 4091:4092
Var 4096:4099
Ident 4100:4102 text="c1"
Assign 4103:4104
Ident 4105:4112 text="enumNew"
LParen 4112:4113
Number 4113:4114 text="0" suf="" isf=0 int=0
Comma 4114:4115
Number 4116:4117 text="1" suf="" isf=0 int=1
RParen 4117:4118
Newline 4118:4119
Var 4123:4126
Ident 4127:4129 text="c2"
Assign 4130:4131
Ident 4132:4139 text="enumNew"
LParen 4139:4140
Number 4140:4141 text="0" suf="" isf=0 int=0
Comma 4141:4142
Number 4143:4144 text="1" suf="" isf=0 int=1
RParen 4144:4145
Newline 4145:4146
Ident 4150:4165 text="abiEnumSetField"
LParen 4165:4166
Ident 4166:4168 text="c1"
Comma 4168:4169
Number 4170:4171 text="0" suf="" isf=0 int=0
Comma 4171:4172
Ident 4173:4182 text="abiBoxI64"
LParen 4182:4183
Number 4183:4184 text="1" suf="" isf=0 int=1
RParen 4184:4185
RParen 4185:4186
Newline 4186:4187
Ident 4191:4206 text="abiEnumSetField"
LParen 4206:4207
Ident 4207:4209 text="c2"
Comma 4209:4210
Number 4211:4212 text="0" suf="" isf=0 int=0
Comma 4212:4213
Ident 4214:4224 text="abiBoxBool"
LParen 4224:4225
True 4225:4229
RParen 4229:4230
RParen 4230:4231
Newline 4231:4232
Ident 4236:4243 text="println"
LParen 4243:4244
Str 4244:4273 T("  equal=") E[Ident 4254:4263 text="abiEnumEq"; LParen 4263:4264; Ident 4264:4266 text="c1"; Comma 4266:4267; Ident 4268:4270 text="c2"; RParen 4270:4271; Eof 4272:4272]
RParen 4273:4274
Newline 4274:4275
Newline 4275:4276
Ident 4280:4287 text="println"
LParen 4287:4288
Str 4288:4332 T("== equality: strings compare by content ==")
RParen 4332:4333
Newline 4333:4334
Var 4338:4341
Ident 4342:4344 text="s1"
Assign 4345:4346
Ident 4347:4354 text="enumNew"
LParen 4354:4355
Number 4355:4356 text="0" suf="" isf=0 int=0
Comma 4356:4357
Number 4358:4359 text="1" suf="" isf=0 int=1
RParen 4359:4360
Newline 4360:4361
Var 4365:4368
Ident 4369:4371 text="s2"
Assign 4372:4373
Ident 4374:4381 text="enumNew"
LParen 4381:4382
Number 4382:4383 text="0" suf="" isf=0 int=0
Comma 4383:4384
Number 4385:4386 text="1" suf="" isf=0 int=1
RParen 4386:4387
Newline 4387:4388
Var 4392:4395
Ident 4396:4398 text="s3"
Assign 4399:4400
Ident 4401:4408 text="enumNew"
LParen 4408:4409
Number 4409:4410 text="0" suf="" isf=0 int=0
Comma 4410:4411
Number 4412:4413 text="1" suf="" isf=0 int=1
RParen 4413:4414
Newline 4414:4415
Ident 4419:4434 text="abiEnumSetField"
LParen 4434:4435
Ident 4435:4437 text="s1"
Comma 4437:4438
Number 4439:4440 text="0" suf="" isf=0 int=0
Comma 4440:4441
Ident 4442:4457 text="abiStrFromBytes"
LParen 4457:4458
Ident 4458:4464 text="byteAt"
LParen 4464:4465
Number 4465:4467 text="72" suf="" isf=0 int=72
RParen 4467:4468
Comma 4468:4469
Number 4470:4471 text="1" suf="" isf=0 int=1
RParen 4471:4472
RParen 4472:4473
Newline 4473:4474
Ident 4478:4493 text="abiEnumSetField"
LParen 4493:4494
Ident 4494:4496 text="s2"
Comma 4496:4497
Number 4498:4499 text="0" suf="" isf=0 int=0
Comma 4499:4500
Ident 4501:4516 text="abiStrFromBytes"
LParen 4516:4517
Ident 4517:4523 text="byteAt"
LParen 4523:4524
Number 4524:4526 text="72" suf="" isf=0 int=72
RParen 4526:4527
Comma 4527:4528
Number 4529:4530 text="1" suf="" isf=0 int=1
RParen 4530:4531
RParen 4531:4532
Newline 4532:4533
Ident 4537:4552 text="abiEnumSetField"
LParen 4552:4553
Ident 4553:4555 text="s3"
Comma 4555:4556
Number 4557:4558 text="0" suf="" isf=0 int=0
Comma 4558:4559
Ident 4560:4575 text="abiStrFromBytes"
LParen 4575:4576
Ident 4576:4582 text="byteAt"
LParen 4582:4583
Number 4583:4585 text="73" suf="" isf=0 int=73
RParen 4585:4586
Comma 4586:4587
Number 4588:4589 text="1" suf="" isf=0 int=1
RParen 4589:4590
RParen 4590:4591
Newline 4591:4592
Ident 4596:4603 text="println"
LParen 4603:4604
Str 4604:4674 T("  same content=") E[Ident 4621:4630 text="abiEnumEq"; LParen 4630:4631; Ident 4631:4633 text="s1"; Comma 4633:4634; Ident 4635:4637 text="s2"; RParen 4637:4638; Eof 4639:4639] T(" other content=") E[Ident 4655:4664 text="abiEnumEq"; LParen 4664:4665; Ident 4665:4667 text="s1"; Comma 4667:4668; Ident 4669:4671 text="s3"; RParen 4671:4672; Eof 4673:4673]
RParen 4674:4675
Newline 4675:4676
Newline 4676:4677
Ident 4681:4688 text="println"
LParen 4688:4689
Str 4689:4727 T("== equality: nested enums recurse ==")
RParen 4727:4728
Newline 4728:4729
Var 4733:4736
Ident 4737:4743 text="outer1"
Assign 4744:4745
Ident 4746:4753 text="enumNew"
LParen 4753:4754
Number 4754:4755 text="9" suf="" isf=0 int=9
Comma 4755:4756
Number 4757:4758 text="1" suf="" isf=0 int=1
RParen 4758:4759
Newline 4759:4760
Var 4764:4767
Ident 4768:4774 text="outer2"
Assign 4775:4776
Ident 4777:4784 text="enumNew"
LParen 4784:4785
Number 4785:4786 text="9" suf="" isf=0 int=9
Comma 4786:4787
Number 4788:4789 text="1" suf="" isf=0 int=1
RParen 4789:4790
Newline 4790:4791
Var 4795:4798
Ident 4799:4805 text="inner1"
Assign 4806:4807
Ident 4808:4815 text="enumNew"
LParen 4815:4816
Number 4816:4817 text="4" suf="" isf=0 int=4
Comma 4817:4818
Number 4819:4820 text="1" suf="" isf=0 int=1
RParen 4820:4821
Newline 4821:4822
Var 4826:4829
Ident 4830:4836 text="inner2"
Assign 4837:4838
Ident 4839:4846 text="enumNew"
LParen 4846:4847
Number 4847:4848 text="4" suf="" isf=0 int=4
Comma 4848:4849
Number 4850:4851 text="1" suf="" isf=0 int=1
RParen 4851:4852
Newline 4852:4853
Var 4857:4860
Ident 4861:4867 text="inner3"
Assign 4868:4869
Ident 4870:4877 text="enumNew"
LParen 4877:4878
Number 4878:4879 text="5" suf="" isf=0 int=5
Comma 4879:4880
Number 4881:4882 text="1" suf="" isf=0 int=1
RParen 4882:4883
Newline 4883:4884
Ident 4888:4903 text="abiEnumSetField"
LParen 4903:4904
Ident 4904:4910 text="inner1"
Comma 4910:4911
Number 4912:4913 text="0" suf="" isf=0 int=0
Comma 4913:4914
Ident 4915:4924 text="abiBoxI64"
LParen 4924:4925
Number 4925:4926 text="3" suf="" isf=0 int=3
RParen 4926:4927
RParen 4927:4928
Newline 4928:4929
Ident 4933:4948 text="abiEnumSetField"
LParen 4948:4949
Ident 4949:4955 text="inner2"
Comma 4955:4956
Number 4957:4958 text="0" suf="" isf=0 int=0
Comma 4958:4959
Ident 4960:4969 text="abiBoxI64"
LParen 4969:4970
Number 4970:4971 text="3" suf="" isf=0 int=3
RParen 4971:4972
RParen 4972:4973
Newline 4973:4974
Ident 4978:4993 text="abiEnumSetField"
LParen 4993:4994
Ident 4994:5000 text="inner3"
Comma 5000:5001
Number 5002:5003 text="0" suf="" isf=0 int=0
Comma 5003:5004
Ident 5005:5014 text="abiBoxI64"
LParen 5014:5015
Number 5015:5016 text="3" suf="" isf=0 int=3
RParen 5016:5017
RParen 5017:5018
Newline 5018:5019
Ident 5023:5038 text="abiEnumSetField"
LParen 5038:5039
Ident 5039:5045 text="outer1"
Comma 5045:5046
Number 5047:5048 text="0" suf="" isf=0 int=0
Comma 5048:5049
Ident 5050:5056 text="inner1"
RParen 5056:5057
Newline 5057:5058
Ident 5062:5077 text="abiEnumSetField"
LParen 5077:5078
Ident 5078:5084 text="outer2"
Comma 5084:5085
Number 5086:5087 text="0" suf="" isf=0 int=0
Comma 5087:5088
Ident 5089:5095 text="inner2"
RParen 5095:5096
Newline 5096:5097
Ident 5101:5108 text="println"
LParen 5108:5109
Str 5109:5146 T("  equal=") E[Ident 5119:5128 text="abiEnumEq"; LParen 5128:5129; Ident 5129:5135 text="outer1"; Comma 5135:5136; Ident 5137:5143 text="outer2"; RParen 5143:5144; Eof 5145:5145]
RParen 5146:5147
Newline 5147:5148
Ident 5152:5167 text="abiEnumSetField"
LParen 5167:5168
Ident 5168:5174 text="outer2"
Comma 5174:5175
Number 5176:5177 text="0" suf="" isf=0 int=0
Comma 5177:5178
Ident 5179:5185 text="inner3"
RParen 5185:5186
Newline 5186:5187
Ident 5191:5198 text="println"
LParen 5198:5199
Str 5199:5248 T("  inner tag differs=") E[Ident 5221:5230 text="abiEnumEq"; LParen 5230:5231; Ident 5231:5237 text="outer1"; Comma 5237:5238; Ident 5239:5245 text="outer2"; RParen 5245:5246; Eof 5247:5247]
RParen 5248:5249
Newline 5249:5250
Newline 5250:5251
Ident 5255:5262 text="println"
LParen 5262:5263
Str 5263:5312 T("== equality: float payloads compare by value ==")
RParen 5312:5313
Newline 5313:5314
Var 5318:5321
Ident 5322:5324 text="z1"
Assign 5325:5326
Ident 5327:5334 text="enumNew"
LParen 5334:5335
Number 5335:5336 text="0" suf="" isf=0 int=0
Comma 5336:5337
Number 5338:5339 text="1" suf="" isf=0 int=1
RParen 5339:5340
Newline 5340:5341
Var 5345:5348
Ident 5349:5351 text="z2"
Assign 5352:5353
Ident 5354:5361 text="enumNew"
LParen 5361:5362
Number 5362:5363 text="0" suf="" isf=0 int=0
Comma 5363:5364
Number 5365:5366 text="1" suf="" isf=0 int=1
RParen 5366:5367
Newline 5367:5368
Ident 5372:5387 text="abiEnumSetField"
LParen 5387:5388
Ident 5388:5390 text="z1"
Comma 5390:5391
Number 5392:5393 text="0" suf="" isf=0 int=0
Comma 5393:5394
Ident 5395:5403 text="floatBox"
LParen 5403:5404
Number 5404:5422 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408
RParen 5422:5423
RParen 5423:5424
Newline 5424:5425
Ident 5429:5444 text="abiEnumSetField"
LParen 5444:5445
Ident 5445:5447 text="z2"
Comma 5447:5448
Number 5449:5450 text="0" suf="" isf=0 int=0
Comma 5450:5451
Ident 5452:5460 text="floatBox"
LParen 5460:5461
Number 5461:5479 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408
RParen 5479:5480
RParen 5480:5481
Newline 5481:5482
Ident 5486:5493 text="println"
LParen 5493:5494
Str 5494:5525 T("  one=one=") E[Ident 5506:5515 text="abiEnumEq"; LParen 5515:5516; Ident 5516:5518 text="z1"; Comma 5518:5519; Ident 5520:5522 text="z2"; RParen 5522:5523; Eof 5524:5524]
RParen 5525:5526
Newline 5526:5527
Ident 5531:5546 text="abiEnumSetField"
LParen 5546:5547
Ident 5547:5549 text="z2"
Comma 5549:5550
Number 5551:5552 text="0" suf="" isf=0 int=0
Comma 5552:5553
Ident 5554:5562 text="floatBox"
LParen 5562:5563
Number 5563:5581 text="0x4000000000000000" suf="" isf=0 int=4611686018427387904
RParen 5581:5582
RParen 5582:5583
Newline 5583:5584
Ident 5588:5595 text="println"
LParen 5595:5596
Str 5596:5627 T("  one=two=") E[Ident 5608:5617 text="abiEnumEq"; LParen 5617:5618; Ident 5618:5620 text="z1"; Comma 5620:5621; Ident 5622:5624 text="z2"; RParen 5624:5625; Eof 5626:5626]
RParen 5627:5628
Newline 5628:5629
Ident 5633:5648 text="abiEnumSetField"
LParen 5648:5649
Ident 5649:5651 text="z1"
Comma 5651:5652
Number 5653:5654 text="0" suf="" isf=0 int=0
Comma 5654:5655
Ident 5656:5664 text="floatBox"
LParen 5664:5665
Number 5665:5683 text="0x0000000000000000" suf="" isf=0 int=0
RParen 5683:5684
RParen 5684:5685
Newline 5685:5686
Ident 5690:5705 text="abiEnumSetField"
LParen 5705:5706
Ident 5706:5708 text="z2"
Comma 5708:5709
Number 5710:5711 text="0" suf="" isf=0 int=0
Comma 5711:5712
Ident 5713:5721 text="floatBox"
LParen 5721:5722
Number 5722:5723 text="0" suf="" isf=0 int=0
Minus 5724:5725
Number 5726:5744 text="0x7FFFFFFFFFFFFFFF" suf="" isf=0 int=9223372036854775807
Minus 5745:5746
Number 5747:5748 text="1" suf="" isf=0 int=1
RParen 5748:5749
RParen 5749:5750
Newline 5750:5751
Ident 5755:5762 text="println"
LParen 5762:5763
Str 5763:5792 T("  +0=-0=") E[Ident 5773:5782 text="abiEnumEq"; LParen 5782:5783; Ident 5783:5785 text="z1"; Comma 5785:5786; Ident 5787:5789 text="z2"; RParen 5789:5790; Eof 5791:5791]
RParen 5792:5793
Newline 5793:5794
Ident 5798:5813 text="abiEnumSetField"
LParen 5813:5814
Ident 5814:5816 text="z1"
Comma 5816:5817
Number 5818:5819 text="0" suf="" isf=0 int=0
Comma 5819:5820
Ident 5821:5829 text="floatBox"
LParen 5829:5830
Number 5830:5848 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560
RParen 5848:5849
RParen 5849:5850
Newline 5850:5851
Ident 5855:5870 text="abiEnumSetField"
LParen 5870:5871
Ident 5871:5873 text="z2"
Comma 5873:5874
Number 5875:5876 text="0" suf="" isf=0 int=0
Comma 5876:5877
Ident 5878:5886 text="floatBox"
LParen 5886:5887
Number 5887:5905 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560
RParen 5905:5906
RParen 5906:5907
Newline 5907:5908
Ident 5912:5919 text="println"
LParen 5919:5920
Str 5920:5951 T("  nan=nan=") E[Ident 5932:5941 text="abiEnumEq"; LParen 5941:5942; Ident 5942:5944 text="z1"; Comma 5944:5945; Ident 5946:5948 text="z2"; RParen 5948:5949; Eof 5950:5950]
RParen 5951:5952
Newline 5952:5953
Ident 5957:5972 text="abiEnumSetField"
LParen 5972:5973
Ident 5973:5975 text="z1"
Comma 5975:5976
Number 5977:5978 text="0" suf="" isf=0 int=0
Comma 5978:5979
Ident 5980:5988 text="floatBox"
LParen 5988:5989
Number 5989:6007 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312
RParen 6007:6008
RParen 6008:6009
Newline 6009:6010
Ident 6014:6029 text="abiEnumSetField"
LParen 6029:6030
Ident 6030:6032 text="z2"
Comma 6032:6033
Number 6034:6035 text="0" suf="" isf=0 int=0
Comma 6035:6036
Ident 6037:6045 text="floatBox"
LParen 6045:6046
Number 6046:6064 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312
RParen 6064:6065
RParen 6065:6066
Newline 6066:6067
Ident 6071:6078 text="println"
LParen 6078:6079
Str 6079:6110 T("  inf=inf=") E[Ident 6091:6100 text="abiEnumEq"; LParen 6100:6101; Ident 6101:6103 text="z1"; Comma 6103:6104; Ident 6105:6107 text="z2"; RParen 6107:6108; Eof 6109:6109]
RParen 6110:6111
Newline 6111:6112
Ident 6116:6131 text="abiEnumSetField"
LParen 6131:6132
Ident 6132:6134 text="z2"
Comma 6134:6135
Number 6136:6137 text="0" suf="" isf=0 int=0
Comma 6137:6138
Ident 6139:6147 text="floatBox"
LParen 6147:6148
Number 6148:6149 text="0" suf="" isf=0 int=0
Minus 6150:6151
Number 6152:6170 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312
Minus 6171:6172
Number 6173:6174 text="1" suf="" isf=0 int=1
RParen 6174:6175
RParen 6175:6176
Newline 6176:6177
Ident 6181:6188 text="println"
LParen 6188:6189
Str 6189:6221 T("  inf=-inf=") E[Ident 6202:6211 text="abiEnumEq"; LParen 6211:6212; Ident 6212:6214 text="z1"; Comma 6214:6215; Ident 6216:6218 text="z2"; RParen 6218:6219; Eof 6220:6220]
RParen 6221:6222
Newline 6222:6223
Newline 6223:6224
Ident 6228:6235 text="println"
LParen 6235:6236
Str 6236:6294 T("== equality: other payload kinds are pointer identity ==")
RParen 6294:6295
Newline 6295:6296
Var 6300:6303
Ident 6304:6306 text="p1"
Assign 6307:6308
Ident 6309:6316 text="enumNew"
LParen 6316:6317
Number 6317:6318 text="0" suf="" isf=0 int=0
Comma 6318:6319
Number 6320:6321 text="1" suf="" isf=0 int=1
RParen 6321:6322
Newline 6322:6323
Var 6327:6330
Ident 6331:6333 text="p2"
Assign 6334:6335
Ident 6336:6343 text="enumNew"
LParen 6343:6344
Number 6344:6345 text="0" suf="" isf=0 int=0
Comma 6345:6346
Number 6347:6348 text="1" suf="" isf=0 int=1
RParen 6348:6349
Newline 6349:6350
Var 6354:6357
Ident 6358:6364 text="shared"
Assign 6365:6366
Ident 6367:6375 text="tupleNew"
LParen 6375:6376
Number 6376:6377 text="1" suf="" isf=0 int=1
RParen 6377:6378
Newline 6378:6379
Ident 6383:6398 text="abiEnumSetField"
LParen 6398:6399
Ident 6399:6401 text="p1"
Comma 6401:6402
Number 6403:6404 text="0" suf="" isf=0 int=0
Comma 6404:6405
Ident 6406:6412 text="shared"
RParen 6412:6413
Newline 6413:6414
Ident 6418:6433 text="abiEnumSetField"
LParen 6433:6434
Ident 6434:6436 text="p2"
Comma 6436:6437
Number 6438:6439 text="0" suf="" isf=0 int=0
Comma 6439:6440
Ident 6441:6447 text="shared"
RParen 6447:6448
Newline 6448:6449
Ident 6453:6460 text="println"
LParen 6460:6461
Str 6461:6491 T("  shared=") E[Ident 6472:6481 text="abiEnumEq"; LParen 6481:6482; Ident 6482:6484 text="p1"; Comma 6484:6485; Ident 6486:6488 text="p2"; RParen 6488:6489; Eof 6490:6490]
RParen 6491:6492
Newline 6492:6493
Ident 6497:6512 text="abiEnumSetField"
LParen 6512:6513
Ident 6513:6515 text="p2"
Comma 6515:6516
Number 6517:6518 text="0" suf="" isf=0 int=0
Comma 6518:6519
Ident 6520:6528 text="tupleNew"
LParen 6528:6529
Number 6529:6530 text="1" suf="" isf=0 int=1
RParen 6530:6531
RParen 6531:6532
Newline 6532:6533
Ident 6537:6544 text="println"
LParen 6544:6545
Str 6545:6584 T("  distinct tuples=") E[Ident 6565:6574 text="abiEnumEq"; LParen 6574:6575; Ident 6575:6577 text="p1"; Comma 6577:6578; Ident 6579:6581 text="p2"; RParen 6581:6582; Eof 6583:6583]
RParen 6584:6585
Newline 6585:6586
Newline 6586:6587
Ident 6591:6598 text="println"
LParen 6598:6599
Str 6599:6634 T("== equality: non-enum operands ==")
RParen 6634:6635
Newline 6635:6636
Var 6640:6643
Ident 6644:6648 text="str1"
Assign 6649:6650
Ident 6651:6666 text="abiStrFromBytes"
LParen 6666:6667
Ident 6667:6673 text="byteAt"
LParen 6673:6674
Number 6674:6676 text="65" suf="" isf=0 int=65
RParen 6676:6677
Comma 6677:6678
Number 6679:6680 text="1" suf="" isf=0 int=1
RParen 6680:6681
Newline 6681:6682
Var 6686:6689
Ident 6690:6695 text="plain"
Assign 6696:6697
Ident 6698:6705 text="enumNew"
LParen 6705:6706
Number 6706:6707 text="0" suf="" isf=0 int=0
Comma 6707:6708
Number 6709:6710 text="0" suf="" isf=0 int=0
RParen 6710:6711
Newline 6711:6712
Ident 6716:6723 text="println"
LParen 6723:6724
Str 6724:6807 T("  enum-vs-string=") E[Ident 6743:6752 text="abiEnumEq"; LParen 6752:6753; Ident 6753:6758 text="plain"; Comma 6758:6759; Ident 6760:6764 text="str1"; RParen 6764:6765; Eof 6766:6766] T(" string-vs-enum=") E[Ident 6783:6792 text="abiEnumEq"; LParen 6792:6793; Ident 6793:6797 text="str1"; Comma 6797:6798; Ident 6799:6804 text="plain"; RParen 6804:6805; Eof 6806:6806]
RParen 6807:6808
Newline 6808:6809
Newline 6809:6810
Ident 6814:6821 text="println"
LParen 6821:6822
Str 6822:6850 T("== deep chain, 12 links ==")
RParen 6850:6851
Newline 6851:6852
Var 6856:6859
Ident 6860:6865 text="head1"
Assign 6866:6867
Ident 6868:6875 text="enumNew"
LParen 6875:6876
Number 6876:6877 text="1" suf="" isf=0 int=1
Comma 6877:6878
Number 6879:6880 text="1" suf="" isf=0 int=1
RParen 6880:6881
Newline 6881:6882
Var 6886:6889
Ident 6890:6895 text="head2"
Assign 6896:6897
Ident 6898:6905 text="enumNew"
LParen 6905:6906
Number 6906:6907 text="1" suf="" isf=0 int=1
Comma 6907:6908
Number 6909:6910 text="1" suf="" isf=0 int=1
RParen 6910:6911
Newline 6911:6912
Var 6916:6919
Ident 6920:6922 text="a1"
Assign 6923:6924
Ident 6925:6930 text="head1"
Newline 6930:6931
Var 6935:6938
Ident 6939:6941 text="a2"
Assign 6942:6943
Ident 6944:6949 text="head2"
Newline 6949:6950
Var 6954:6957
Ident 6958:6959 text="i"
Assign 6960:6961
Number 6962:6963 text="0" suf="" isf=0 int=0
Newline 6963:6964
While 6968:6973
LParen 6974:6975
Ident 6975:6976 text="i"
Lt 6977:6978
Number 6979:6981 text="12" suf="" isf=0 int=12
RParen 6981:6982
LBrace 6983:6984
Newline 6984:6985
Var 6993:6996
Ident 6997:6999 text="n1"
Assign 7000:7001
Ident 7002:7009 text="enumNew"
LParen 7009:7010
Number 7010:7011 text="2" suf="" isf=0 int=2
Comma 7011:7012
Number 7013:7014 text="1" suf="" isf=0 int=1
RParen 7014:7015
Newline 7015:7016
Var 7024:7027
Ident 7028:7030 text="n2"
Assign 7031:7032
Ident 7033:7040 text="enumNew"
LParen 7040:7041
Number 7041:7042 text="2" suf="" isf=0 int=2
Comma 7042:7043
Number 7044:7045 text="1" suf="" isf=0 int=1
RParen 7045:7046
Newline 7046:7047
Ident 7055:7070 text="abiEnumSetField"
LParen 7070:7071
Ident 7071:7073 text="n1"
Comma 7073:7074
Number 7075:7076 text="0" suf="" isf=0 int=0
Comma 7076:7077
Ident 7078:7087 text="abiBoxI64"
LParen 7087:7088
Ident 7088:7089 text="i"
RParen 7089:7090
RParen 7090:7091
Newline 7091:7092
Ident 7100:7115 text="abiEnumSetField"
LParen 7115:7116
Ident 7116:7118 text="n2"
Comma 7118:7119
Number 7120:7121 text="0" suf="" isf=0 int=0
Comma 7121:7122
Ident 7123:7132 text="abiBoxI64"
LParen 7132:7133
Ident 7133:7134 text="i"
RParen 7134:7135
RParen 7135:7136
Newline 7136:7137
Ident 7145:7160 text="abiEnumSetField"
LParen 7160:7161
Ident 7161:7163 text="a1"
Comma 7163:7164
Number 7165:7166 text="0" suf="" isf=0 int=0
Comma 7166:7167
Ident 7168:7170 text="n1"
RParen 7170:7171
Newline 7171:7172
Ident 7180:7195 text="abiEnumSetField"
LParen 7195:7196
Ident 7196:7198 text="a2"
Comma 7198:7199
Number 7200:7201 text="0" suf="" isf=0 int=0
Comma 7201:7202
Ident 7203:7205 text="n2"
RParen 7205:7206
Newline 7206:7207
Ident 7215:7217 text="a1"
Assign 7218:7219
Ident 7220:7222 text="n1"
Newline 7222:7223
Ident 7231:7233 text="a2"
Assign 7234:7235
Ident 7236:7238 text="n2"
Newline 7238:7239
Ident 7247:7248 text="i"
Assign 7249:7250
Ident 7251:7252 text="i"
Plus 7253:7254
Number 7255:7256 text="1" suf="" isf=0 int=1
Newline 7256:7257
RBrace 7261:7262
Newline 7262:7263
Ident 7267:7274 text="println"
LParen 7274:7275
Str 7275:7310 T("  equal=") E[Ident 7285:7294 text="abiEnumEq"; LParen 7294:7295; Ident 7295:7300 text="head1"; Comma 7300:7301; Ident 7302:7307 text="head2"; RParen 7307:7308; Eof 7309:7309]
RParen 7310:7311
Newline 7311:7312
Var 7316:7319
Ident 7320:7324 text="node"
Assign 7325:7326
Ident 7327:7332 text="head1"
Newline 7332:7333
Ident 7337:7338 text="i"
Assign 7339:7340
Number 7341:7342 text="0" suf="" isf=0 int=0
Newline 7342:7343
While 7347:7352
LParen 7353:7354
Ident 7354:7355 text="i"
Lt 7356:7357
Number 7358:7359 text="6" suf="" isf=0 int=6
RParen 7359:7360
LBrace 7361:7362
Newline 7362:7363
Ident 7371:7375 text="node"
Assign 7376:7377
Ident 7378:7390 text="abiEnumField"
LParen 7390:7391
Ident 7391:7395 text="node"
Comma 7395:7396
Number 7397:7398 text="0" suf="" isf=0 int=0
RParen 7398:7399
Newline 7399:7400
Ident 7408:7409 text="i"
Assign 7410:7411
Ident 7412:7413 text="i"
Plus 7414:7415
Number 7416:7417 text="1" suf="" isf=0 int=1
Newline 7417:7418
RBrace 7422:7423
Newline 7423:7424
Ident 7428:7443 text="abiEnumSetField"
LParen 7443:7444
Ident 7444:7448 text="node"
Comma 7448:7449
Number 7450:7451 text="0" suf="" isf=0 int=0
Comma 7451:7452
Ident 7453:7462 text="abiBoxI64"
LParen 7462:7463
Number 7463:7466 text="999" suf="" isf=0 int=999
RParen 7466:7467
RParen 7467:7468
Newline 7468:7469
Ident 7473:7480 text="println"
LParen 7480:7481
Str 7481:7532 T("  after mid-chain break=") E[Ident 7507:7516 text="abiEnumEq"; LParen 7516:7517; Ident 7517:7522 text="head1"; Comma 7522:7523; Ident 7524:7529 text="head2"; RParen 7529:7530; Eof 7531:7531]
RParen 7532:7533
Newline 7533:7534
Newline 7534:7535
Ident 7539:7546 text="println"
LParen 7546:7547
Str 7547:7583 T("== f64 value equality, directly ==")
RParen 7583:7584
Newline 7584:7585
Ident 7589:7596 text="println"
LParen 7596:7597
Str 7597:7657 T("  1=1 ") E[Ident 7605:7615 text="f64ValueEq"; LParen 7615:7616; Number 7616:7634 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408; Comma 7634:7635; Number 7636:7654 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408; RParen 7654:7655; Eof 7656:7656]
RParen 7657:7658
Newline 7658:7659
Ident 7663:7670 text="println"
LParen 7670:7671
Str 7671:7731 T("  1=2 ") E[Ident 7679:7689 text="f64ValueEq"; LParen 7689:7690; Number 7690:7708 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408; Comma 7708:7709; Number 7710:7728 text="0x4000000000000000" suf="" isf=0 int=4611686018427387904; RParen 7728:7729; Eof 7730:7730]
RParen 7731:7732
Newline 7732:7733
Ident 7737:7744 text="println"
LParen 7744:7745
Str 7745:7810 T("  1=-1 ") E[Ident 7754:7764 text="f64ValueEq"; LParen 7764:7765; Number 7765:7783 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408; Comma 7783:7784; Number 7785:7786 text="0" suf="" isf=0 int=0; Minus 7787:7788; Number 7789:7807 text="0x4010000000000000" suf="" isf=0 int=4616189618054758400; RParen 7807:7808; Eof 7809:7809]
RParen 7810:7811
Newline 7811:7812
Ident 7816:7823 text="println"
LParen 7823:7824
Str 7824:7894 T("  +0=-0 ") E[Ident 7834:7844 text="f64ValueEq"; LParen 7844:7845; Number 7845:7863 text="0x0000000000000000" suf="" isf=0 int=0; Comma 7863:7864; Number 7865:7866 text="0" suf="" isf=0 int=0; Minus 7867:7868; Number 7869:7887 text="0x7FFFFFFFFFFFFFFF" suf="" isf=0 int=9223372036854775807; Minus 7888:7889; Number 7890:7891 text="1" suf="" isf=0 int=1; RParen 7891:7892; Eof 7893:7893]
RParen 7894:7895
Newline 7895:7896
Ident 7900:7907 text="println"
LParen 7907:7908
Str 7908:7972 T("  inf=inf ") E[Ident 7920:7930 text="f64ValueEq"; LParen 7930:7931; Number 7931:7949 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312; Comma 7949:7950; Number 7951:7969 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312; RParen 7969:7970; Eof 7971:7971]
RParen 7972:7973
Newline 7973:7974
Ident 7978:7985 text="println"
LParen 7985:7986
Str 7986:8059 T("  inf=-inf ") E[Ident 7999:8009 text="f64ValueEq"; LParen 8009:8010; Number 8010:8028 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312; Comma 8028:8029; Number 8030:8031 text="0" suf="" isf=0 int=0; Minus 8032:8033; Number 8034:8052 text="0x7FF0000000000000" suf="" isf=0 int=9218868437227405312; Minus 8053:8054; Number 8055:8056 text="1" suf="" isf=0 int=1; RParen 8056:8057; Eof 8058:8058]
RParen 8059:8060
Newline 8060:8061
Ident 8065:8072 text="println"
LParen 8072:8073
Str 8073:8137 T("  nan=nan ") E[Ident 8085:8095 text="f64ValueEq"; LParen 8095:8096; Number 8096:8114 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560; Comma 8114:8115; Number 8116:8134 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560; RParen 8134:8135; Eof 8136:8136]
RParen 8137:8138
Newline 8138:8139
Ident 8143:8150 text="println"
LParen 8150:8151
Str 8151:8216 T("  nan!=nan ") E[Ident 8164:8174 text="f64ValueEq"; LParen 8174:8175; Number 8175:8193 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560; Comma 8193:8194; Number 8195:8213 text="0x7FF8000000000001" suf="" isf=0 int=9221120237041090561; RParen 8213:8214; Eof 8215:8215]
RParen 8216:8217
Newline 8217:8218
Ident 8222:8229 text="println"
LParen 8229:8230
Str 8230:8292 T("  nan=1 ") E[Ident 8240:8250 text="f64ValueEq"; LParen 8250:8251; Number 8251:8269 text="0x7FF8000000000000" suf="" isf=0 int=9221120237041090560; Comma 8269:8270; Number 8271:8289 text="0x3FF0000000000000" suf="" isf=0 int=4607182418800017408; RParen 8289:8290; Eof 8291:8291]
RParen 8292:8293
Newline 8293:8294
RBrace 8294:8295
Eof 8295:8295
