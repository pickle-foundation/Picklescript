Newline 74:75
Newline 151:152
Newline 230:231
Newline 303:304
Newline 376:377
Newline 379:380
Newline 450:451
Newline 525:526
Newline 603:604
Newline 676:677
Newline 747:748
Newline 825:826
Newline 900:901
Newline 980:981
Newline 1046:1047
Newline 1047:1048
Import 1048:1054
LBrace 1055:1056
Ident 1057:1069 text="abiGcCollect"
RBrace 1070:1071
From 1072:1076
Ident 1077:1084 text="runtime"
Dot 1084:1085
Ident 1085:1091 text="abi_gc"
Newline 1091:1092
Import 1092:1098
LBrace 1099:1100
Ident 1101:1119 text="abiRegisteredCount"
Comma 1119:1120
Ident 1121:1139 text="abiRegisteredBytes"
RBrace 1140:1141
From 1142:1146
Ident 1147:1154 text="runtime"
Dot 1154:1155
Ident 1155:1162 text="abi_raw"
Newline 1162:1163
Import 1163:1169
LBrace 1170:1171
Ident 1172:1179 text="listNew"
Comma 1179:1180
Ident 1181:1192 text="abiListPush"
RBrace 1193:1194
From 1195:1199
Ident 1200:1207 text="runtime"
Dot 1207:1208
Ident 1208:1216 text="abi_list"
Newline 1216:1217
Import 1217:1223
LBrace 1224:1225
Ident 1226:1235 text="abiBoxI64"
RBrace 1236:1237
From 1238:1242
Ident 1243:1250 text="runtime"
Dot 1250:1251
Ident 1251:1258 text="abi_box"
Newline 1258:1259
Newline 1259:1260
Fn 1260:1262
Ident 1263:1267 text="main"
LParen 1267:1268
RParen 1268:1269
LBrace 1270:1271
Newline 1271:1272
Var 1276:1279
Ident 1280:1282 text="c0"
Assign 1283:1284
Ident 1285:1303 text="abiRegisteredCount"
LParen 1303:1304
RParen 1304:1305
Newline 1305:1306
Var 1310:1313
Ident 1314:1316 text="b0"
Assign 1317:1318
Ident 1319:1337 text="abiRegisteredBytes"
LParen 1337:1338
RParen 1338:1339
Newline 1339:1340
Var 1344:1347
Ident 1348:1351 text="all"
Assign 1352:1353
Ident 1354:1361 text="listNew"
LParen 1361:1362
Number 1362:1363 text="0" suf="" isf=0 int=0
RParen 1363:1364
Newline 1364:1365
Ident 1369:1380 text="abiListPush"
LParen 1380:1381
Ident 1381:1384 text="all"
Comma 1384:1385
Ident 1386:1395 text="abiBoxI64"
LParen 1395:1396
Number 1396:1398 text="11" suf="" isf=0 int=11
RParen 1398:1399
RParen 1399:1400
Newline 1400:1401
Ident 1405:1416 text="abiListPush"
LParen 1416:1417
Ident 1417:1420 text="all"
Comma 1420:1421
Ident 1422:1431 text="abiBoxI64"
LParen 1431:1432
Number 1432:1434 text="22" suf="" isf=0 int=22
RParen 1434:1435
RParen 1435:1436
Newline 1436:1437
Var 1441:1444
Ident 1445:1447 text="c1"
Assign 1448:1449
Ident 1450:1468 text="abiRegisteredCount"
LParen 1468:1469
RParen 1469:1470
Newline 1470:1471
Var 1475:1478
Ident 1479:1481 text="b1"
Assign 1482:1483
Ident 1484:1502 text="abiRegisteredBytes"
LParen 1502:1503
RParen 1503:1504
Newline 1504:1505
Var 1509:1512
Ident 1513:1516 text="dc1"
Assign 1517:1518
Ident 1519:1521 text="c1"
Minus 1522:1523
Ident 1524:1526 text="c0"
Newline 1526:1527
Var 1531:1534
Ident 1535:1538 text="db1"
Assign 1539:1540
Ident 1541:1543 text="b1"
Minus 1544:1545
Ident 1546:1548 text="b0"
Newline 1548:1549
Ident 1553:1560 text="println"
LParen 1560:1561
Str 1561:1592 T("made: count ") E[Ident 1575:1578 text="dc1"; Eof 1579:1579] T(" bytes ") E[Ident 1587:1590 text="db1"; Eof 1591:1591]
RParen 1592:1593
Newline 1593:1594
Ident 1598:1610 text="abiGcCollect"
LParen 1610:1611
True 1611:1615
RParen 1615:1616
Newline 1616:1617
Var 1621:1624
Ident 1625:1627 text="c2"
Assign 1628:1629
Ident 1630:1648 text="abiRegisteredCount"
LParen 1648:1649
RParen 1649:1650
Newline 1650:1651
Var 1655:1658
Ident 1659:1661 text="b2"
Assign 1662:1663
Ident 1664:1682 text="abiRegisteredBytes"
LParen 1682:1683
RParen 1683:1684
Newline 1684:1685
Var 1689:1692
Ident 1693:1696 text="dc2"
Assign 1697:1698
Ident 1699:1701 text="c2"
Minus 1702:1703
Ident 1704:1706 text="c0"
Newline 1706:1707
Var 1711:1714
Ident 1715:1718 text="db2"
Assign 1719:1720
Ident 1721:1723 text="b2"
Minus 1724:1725
Ident 1726:1728 text="b0"
Newline 1728:1729
Ident 1733:1740 text="println"
LParen 1740:1741
Str 1741:1786 T("live after collect: count ") E[Ident 1769:1772 text="dc2"; Eof 1773:1773] T(" bytes ") E[Ident 1781:1784 text="db2"; Eof 1785:1785]
RParen 1786:1787
Newline 1787:1788
Ident 1792:1804 text="abiGcCollect"
LParen 1804:1805
False 1805:1810
RParen 1810:1811
Newline 1811:1812
Var 1816:1819
Ident 1820:1822 text="c3"
Assign 1823:1824
Ident 1825:1843 text="abiRegisteredCount"
LParen 1843:1844
RParen 1844:1845
Newline 1845:1846
Var 1850:1853
Ident 1854:1856 text="b3"
Assign 1857:1858
Ident 1859:1877 text="abiRegisteredBytes"
LParen 1877:1878
RParen 1878:1879
Newline 1879:1880
Var 1884:1887
Ident 1888:1891 text="dc3"
Assign 1892:1893
Ident 1894:1896 text="c3"
Minus 1897:1898
Ident 1899:1901 text="c0"
Newline 1901:1902
Var 1906:1909
Ident 1910:1913 text="db3"
Assign 1914:1915
Ident 1916:1918 text="b3"
Minus 1919:1920
Ident 1921:1923 text="b0"
Newline 1923:1924
Ident 1928:1935 text="println"
LParen 1935:1936
Str 1936:1980 T("live after second: count ") E[Ident 1963:1966 text="dc3"; Eof 1967:1967] T(" bytes ") E[Ident 1975:1978 text="db3"; Eof 1979:1979]
RParen 1980:1981
Newline 1981:1982
Ident 1986:1993 text="println"
LParen 1993:1994
Str 1994:2012 T("registry seam ok")
RParen 2012:2013
Newline 2013:2014
RBrace 2014:2015
Eof 2015:2015
