Newline 46:47
Newline 49:50
Newline 121:122
Newline 201:202
Newline 274:275
Newline 353:354
Newline 369:370
Newline 370:371
Async 371:376
Fn 377:379
Ident 380:391 text="slow_square"
LParen 391:392
Ident 392:393 text="n"
Colon 393:394
Ident 395:398 text="int"
RParen 398:399
Arrow 400:402
Ident 403:406 text="int"
LBrace 407:408
Newline 408:409
Ident 413:414 text="n"
Star 415:416
Ident 417:418 text="n"
Newline 418:419
RBrace 419:420
Newline 420:421
Newline 421:422
Async 422:427
Fn 428:430
Ident 431:434 text="add"
LParen 434:435
Ident 435:436 text="a"
Colon 436:437
Ident 438:441 text="int"
Comma 441:442
Ident 443:444 text="b"
Colon 444:445
Ident 446:449 text="int"
RParen 449:450
Arrow 451:453
Ident 454:457 text="int"
LBrace 458:459
Newline 459:460
Ident 464:465 text="a"
Plus 466:467
Ident 468:469 text="b"
Newline 469:470
RBrace 470:471
Newline 471:472
Newline 472:473
Fn 473:475
Ident 476:480 text="main"
LParen 480:481
RParen 481:482
LBrace 483:484
Newline 484:485
Newline 554:555
Let 559:562
Ident 563:569 text="future"
Assign 570:571
Ident 572:583 text="slow_square"
LParen 583:584
Number 584:585 text="7" suf="" isf=0 int=7
RParen 585:586
Newline 586:587
Let 591:594
Ident 595:596 text="v"
Assign 597:598
Await 599:604
Ident 605:611 text="future"
Newline 611:612
Ident 616:622 text="expect"
LParen 622:623
Ident 623:624 text="v"
RParen 624:625
Dot 625:626
Ident 626:630 text="toBe"
LParen 630:631
Number 631:633 text="49" suf="" isf=0 int=49
RParen 633:634
Newline 634:635
Newline 635:636
Newline 704:705
Ident 709:715 text="expect"
LParen 715:716
Await 716:721
Ident 722:733 text="slow_square"
LParen 733:734
Number 734:735 text="6" suf="" isf=0 int=6
RParen 735:736
RParen 736:737
Dot 737:738
Ident 738:742 text="toBe"
LParen 742:743
Number 743:745 text="36" suf="" isf=0 int=36
RParen 745:746
Newline 746:747
Newline 747:748
Newline 827:828
Let 832:835
Ident 836:838 text="f2"
Assign 839:840
Ident 841:852 text="slow_square"
LParen 852:853
Number 853:854 text="3" suf="" isf=0 int=3
RParen 854:855
Newline 855:856
Ident 860:866 text="expect"
LParen 866:867
Await 867:872
Ident 873:875 text="f2"
RParen 875:876
Dot 876:877
Ident 877:881 text="toBe"
LParen 881:882
Number 882:883 text="9" suf="" isf=0 int=9
RParen 883:884
Newline 884:885
Ident 889:895 text="expect"
LParen 895:896
Await 896:901
Ident 902:904 text="f2"
RParen 904:905
Dot 905:906
Ident 906:910 text="toBe"
LParen 910:911
Number 911:912 text="9" suf="" isf=0 int=9
RParen 912:913
Newline 913:914
Newline 914:915
Newline 994:995
Let 999:1002
Ident 1003:1005 text="hi"
Assign 1006:1007
Ident 1008:1011 text="add"
LParen 1011:1012
Number 1012:1014 text="10" suf="" isf=0 int=10
Comma 1014:1015
Number 1016:1017 text="1" suf="" isf=0 int=1
RParen 1017:1018
Newline 1018:1019
Let 1023:1026
Ident 1027:1029 text="lo"
Assign 1030:1031
Ident 1032:1035 text="add"
LParen 1035:1036
Number 1036:1037 text="2" suf="" isf=0 int=2
Comma 1037:1038
Number 1039:1040 text="3" suf="" isf=0 int=3
RParen 1040:1041
Newline 1041:1042
Ident 1046:1052 text="expect"
LParen 1052:1053
Await 1053:1058
Ident 1059:1061 text="hi"
RParen 1061:1062
Dot 1062:1063
Ident 1063:1067 text="toBe"
LParen 1067:1068
Number 1068:1070 text="11" suf="" isf=0 int=11
RParen 1070:1071
Newline 1071:1072
Ident 1076:1082 text="expect"
LParen 1082:1083
Await 1083:1088
Ident 1089:1091 text="lo"
RParen 1091:1092
Dot 1092:1093
Ident 1093:1097 text="toBe"
LParen 1097:1098
Number 1098:1099 text="5" suf="" isf=0 int=5
RParen 1099:1100
Newline 1100:1101
Newline 1101:1102
Newline 1178:1179
Newline 1255:1256
Let 1260:1263
Ident 1264:1265 text="n"
Assign 1266:1267
Number 1268:1269 text="4" suf="" isf=0 int=4
Newline 1269:1270
Ident 1274:1280 text="expect"
LParen 1280:1281
Await 1281:1286
Ident 1287:1298 text="slow_square"
LParen 1298:1299
Ident 1299:1300 text="n"
Star 1301:1302
Number 1303:1304 text="2" suf="" isf=0 int=2
RParen 1304:1305
RParen 1305:1306
Dot 1306:1307
Ident 1307:1311 text="toBe"
LParen 1311:1312
Number 1312:1314 text="64" suf="" isf=0 int=64
RParen 1314:1315
Newline 1315:1316
RBrace 1316:1317
Eof 1317:1317
