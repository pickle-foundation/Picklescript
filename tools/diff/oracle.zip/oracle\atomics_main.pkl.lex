Newline 75:76
Newline 131:132
Newline 207:208
Newline 284:285
Newline 361:362
Newline 387:388
Newline 388:389
Fn 389:391
Ident 392:396 text="main"
LParen 396:397
RParen 397:398
LBrace 399:400
Newline 400:401
Newline 426:427
Let 431:434
Ident 435:436 text="a"
Assign 437:438
Ident 439:449 text="atomic_new"
LParen 449:450
Number 450:451 text="3" suf="" isf=0 int=3
RParen 451:452
Newline 452:453
Ident 457:463 text="expect"
LParen 463:464
Ident 464:475 text="atomic_load"
LParen 475:476
Ident 476:477 text="a"
RParen 477:478
RParen 478:479
Dot 479:480
Ident 480:484 text="toBe"
LParen 484:485
Number 485:486 text="3" suf="" isf=0 int=3
RParen 486:487
Newline 487:488
Ident 492:504 text="atomic_store"
LParen 504:505
Ident 505:506 text="a"
Comma 506:507
Number 508:510 text="10" suf="" isf=0 int=10
RParen 510:511
Newline 511:512
Ident 516:522 text="expect"
LParen 522:523
Ident 523:534 text="atomic_load"
LParen 534:535
Ident 535:536 text="a"
RParen 536:537
RParen 537:538
Dot 538:539
Ident 539:543 text="toBe"
LParen 543:544
Number 544:546 text="10" suf="" isf=0 int=10
RParen 546:547
Newline 547:548
Newline 548:549
Newline 624:625
Newline 661:662
Let 666:669
Ident 670:671 text="b"
Assign 672:673
Ident 674:684 text="atomic_new"
LParen 684:685
Number 685:688 text="100" suf="" isf=0 int=100
RParen 688:689
Newline 689:690
Ident 694:700 text="expect"
LParen 700:701
Ident 701:711 text="atomic_add"
LParen 711:712
Ident 712:713 text="b"
Comma 713:714
Number 715:716 text="5" suf="" isf=0 int=5
RParen 716:717
RParen 717:718
Dot 718:719
Ident 719:723 text="toBe"
LParen 723:724
Number 724:727 text="100" suf="" isf=0 int=100
RParen 727:728
Newline 728:729
Ident 733:739 text="expect"
LParen 739:740
Ident 740:750 text="atomic_add"
LParen 750:751
Ident 751:752 text="b"
Comma 752:753
Minus 754:755
Number 755:757 text="30" suf="" isf=0 int=30
RParen 757:758
RParen 758:759
Dot 759:760
Ident 760:764 text="toBe"
LParen 764:765
Number 765:768 text="105" suf="" isf=0 int=105
RParen 768:769
Newline 769:770
Ident 774:780 text="expect"
LParen 780:781
Ident 781:792 text="atomic_load"
LParen 792:793
Ident 793:794 text="b"
RParen 794:795
RParen 795:796
Dot 796:797
Ident 797:801 text="toBe"
LParen 801:802
Number 802:804 text="75" suf="" isf=0 int=75
RParen 804:805
Newline 805:806
Newline 806:807
Newline 882:883
Newline 935:936
Let 940:943
Ident 944:945 text="c"
Assign 946:947
Ident 948:958 text="atomic_new"
LParen 958:959
Number 959:960 text="7" suf="" isf=0 int=7
RParen 960:961
Newline 961:962
Ident 966:972 text="expect"
LParen 972:973
Ident 973:983 text="atomic_cas"
LParen 983:984
Ident 984:985 text="c"
Comma 985:986
Number 987:988 text="7" suf="" isf=0 int=7
Comma 988:989
Number 990:992 text="42" suf="" isf=0 int=42
RParen 992:993
RParen 993:994
Dot 994:995
Ident 995:999 text="toBe"
LParen 999:1000
True 1000:1004
RParen 1004:1005
Newline 1005:1006
Ident 1010:1016 text="expect"
LParen 1016:1017
Ident 1017:1028 text="atomic_load"
LParen 1028:1029
Ident 1029:1030 text="c"
RParen 1030:1031
RParen 1031:1032
Dot 1032:1033
Ident 1033:1037 text="toBe"
LParen 1037:1038
Number 1038:1040 text="42" suf="" isf=0 int=42
RParen 1040:1041
Newline 1041:1042
Ident 1046:1052 text="expect"
LParen 1052:1053
Ident 1053:1063 text="atomic_cas"
LParen 1063:1064
Ident 1064:1065 text="c"
Comma 1065:1066
Number 1067:1068 text="7" suf="" isf=0 int=7
Comma 1068:1069
Number 1070:1072 text="99" suf="" isf=0 int=99
RParen 1072:1073
RParen 1073:1074
Dot 1074:1075
Ident 1075:1079 text="toBe"
LParen 1079:1080
False 1080:1085
RParen 1085:1086
Newline 1086:1087
Ident 1091:1097 text="expect"
LParen 1097:1098
Ident 1098:1109 text="atomic_load"
LParen 1109:1110
Ident 1110:1111 text="c"
RParen 1111:1112
RParen 1112:1113
Dot 1113:1114
Ident 1114:1118 text="toBe"
LParen 1118:1119
Number 1119:1121 text="42" suf="" isf=0 int=42
RParen 1121:1122
Newline 1122:1123
Ident 1127:1133 text="expect"
LParen 1133:1134
Ident 1134:1144 text="atomic_cas"
LParen 1144:1145
Ident 1145:1146 text="c"
Comma 1146:1147
Number 1148:1150 text="42" suf="" isf=0 int=42
Comma 1150:1151
Number 1152:1153 text="0" suf="" isf=0 int=0
RParen 1153:1154
RParen 1154:1155
Dot 1155:1156
Ident 1156:1160 text="toBe"
LParen 1160:1161
True 1161:1165
RParen 1165:1166
Newline 1166:1167
Ident 1171:1177 text="expect"
LParen 1177:1178
Ident 1178:1189 text="atomic_load"
LParen 1189:1190
Ident 1190:1191 text="c"
RParen 1191:1192
RParen 1192:1193
Dot 1193:1194
Ident 1194:1198 text="toBe"
LParen 1198:1199
Number 1199:1200 text="0" suf="" isf=0 int=0
RParen 1200:1201
Newline 1201:1202
Newline 1202:1203
Newline 1279:1280
Newline 1355:1356
Let 1360:1363
Ident 1364:1365 text="d"
Assign 1366:1367
Ident 1368:1378 text="atomic_new"
LParen 1378:1379
Minus 1379:1380
Number 1380:1381 text="1" suf="" isf=0 int=1
RParen 1381:1382
Newline 1382:1383
Ident 1387:1393 text="expect"
LParen 1393:1394
Ident 1394:1405 text="atomic_load"
LParen 1405:1406
Ident 1406:1407 text="d"
RParen 1407:1408
RParen 1408:1409
Dot 1409:1410
Ident 1410:1414 text="toBe"
LParen 1414:1415
Minus 1415:1416
Number 1416:1417 text="1" suf="" isf=0 int=1
RParen 1417:1418
Newline 1418:1419
Ident 1423:1433 text="atomic_add"
LParen 1433:1434
Ident 1434:1435 text="d"
Comma 1435:1436
Number 1437:1438 text="1" suf="" isf=0 int=1
RParen 1438:1439
Newline 1439:1440
Ident 1444:1450 text="expect"
LParen 1450:1451
Ident 1451:1462 text="atomic_load"
LParen 1462:1463
Ident 1463:1464 text="d"
RParen 1464:1465
RParen 1465:1466
Dot 1466:1467
Ident 1467:1471 text="toBe"
LParen 1471:1472
Number 1472:1473 text="0" suf="" isf=0 int=0
RParen 1473:1474
Newline 1474:1475
Ident 1479:1485 text="expect"
LParen 1485:1486
Ident 1486:1497 text="atomic_load"
LParen 1497:1498
Ident 1498:1499 text="a"
RParen 1499:1500
RParen 1500:1501
Dot 1501:1502
Ident 1502:1506 text="toBe"
LParen 1506:1507
Number 1507:1509 text="10" suf="" isf=0 int=10
RParen 1509:1510
Newline 1510:1511
Ident 1515:1521 text="expect"
LParen 1521:1522
Ident 1522:1533 text="atomic_load"
LParen 1533:1534
Ident 1534:1535 text="b"
RParen 1535:1536
RParen 1536:1537
Dot 1537:1538
Ident 1538:1542 text="toBe"
LParen 1542:1543
Number 1543:1545 text="75" suf="" isf=0 int=75
RParen 1545:1546
Newline 1546:1547
Newline 1547:1548
Ident 1552:1559 text="println"
LParen 1559:1560
Str 1560:1572 T("atomics ok")
RParen 1572:1573
Newline 1573:1574
RBrace 1574:1575
Newline 1575:1576
Eof 1576:1576
