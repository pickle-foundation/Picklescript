Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Newline 90:91
Newline 167:168
Newline 200:201
Newline 203:204
Newline 282:283
Newline 362:363
Newline 442:443
Newline 518:519
Newline 598:599
Newline 679:680
Newline 759:760
Newline 831:832
Newline 834:835
Newline 911:912
Newline 973:974
Newline 974:975
Fn 975:977
Ident 978:979 text="b"
LParen 979:980
Ident 980:981 text="v"
Colon 981:982
Ident 983:987 text="bool"
RParen 987:988
Colon 988:989
Ident 990:996 text="string"
LBrace 997:998
Newline 998:999
If 1003:1005
LParen 1006:1007
Ident 1007:1008 text="v"
RParen 1008:1009
LBrace 1010:1011
Str 1012:1015 T("T")
RBrace 1016:1017
Else 1018:1022
LBrace 1023:1024
Str 1025:1028 T("F")
RBrace 1029:1030
Newline 1030:1031
RBrace 1031:1032
Newline 1032:1033
Newline 1033:1034
Fn 1034:1036
Ident 1037:1040 text="row"
LParen 1040:1041
Ident 1041:1042 text="n"
Colon 1042:1043
Ident 1044:1047 text="int"
Comma 1047:1048
Ident 1049:1050 text="a"
Colon 1050:1051
Ident 1052:1057 text="float"
Comma 1057:1058
Ident 1059:1060 text="c"
Colon 1060:1061
Ident 1062:1067 text="float"
RParen 1067:1068
LBrace 1069:1070
Newline 1070:1071
Ident 1075:1082 text="println"
LParen 1082:1083
Str 1083:1086 T("r")
Comma 1086:1087
Ident 1088:1089 text="n"
Comma 1089:1090
Str 1091:1094 T(" ")
Comma 1094:1095
Ident 1096:1097 text="b"
LParen 1097:1098
Ident 1098:1099 text="a"
EqEq 1100:1102
Ident 1103:1104 text="c"
RParen 1104:1105
Comma 1105:1106
Ident 1107:1108 text="b"
LParen 1108:1109
Ident 1109:1110 text="a"
NotEq 1111:1113
Ident 1114:1115 text="c"
RParen 1115:1116
Comma 1116:1117
Ident 1118:1119 text="b"
LParen 1119:1120
Ident 1120:1121 text="a"
Lt 1122:1123
Ident 1124:1125 text="c"
RParen 1125:1126
Comma 1126:1127
Ident 1128:1129 text="b"
LParen 1129:1130
Ident 1130:1131 text="a"
Le 1132:1134
Ident 1135:1136 text="c"
RParen 1136:1137
Comma 1137:1138
Ident 1139:1140 text="b"
LParen 1140:1141
Ident 1141:1142 text="a"
Gt 1143:1144
Ident 1145:1146 text="c"
RParen 1146:1147
Comma 1147:1148
Ident 1149:1150 text="b"
LParen 1150:1151
Ident 1151:1152 text="a"
Ge 1153:1155
Ident 1156:1157 text="c"
RParen 1157:1158
RParen 1158:1159
Newline 1159:1160
RBrace 1160:1161
Newline 1161:1162
Newline 1162:1163
Fn 1163:1165
Ident 1166:1170 text="main"
LParen 1170:1171
RParen 1171:1172
LBrace 1173:1174
Newline 1174:1175
Newline 1199:1200
Ident 1204:1207 text="row"
LParen 1207:1208
Number 1208:1209 text="0" suf="" isf=0 int=0
Comma 1209:1210
Number 1211:1214 text="1.0" suf="" isf=1 int=-
Comma 1214:1215
Number 1216:1219 text="1.0" suf="" isf=1 int=-
RParen 1219:1220
Newline 1220:1221
Ident 1225:1228 text="row"
LParen 1228:1229
Number 1229:1230 text="1" suf="" isf=0 int=1
Comma 1230:1231
Number 1232:1235 text="1.0" suf="" isf=1 int=-
Comma 1235:1236
Number 1237:1240 text="2.0" suf="" isf=1 int=-
RParen 1240:1241
Newline 1241:1242
Ident 1246:1249 text="row"
LParen 1249:1250
Number 1250:1251 text="2" suf="" isf=0 int=2
Comma 1251:1252
Number 1253:1256 text="2.0" suf="" isf=1 int=-
Comma 1256:1257
Number 1258:1261 text="1.0" suf="" isf=1 int=-
RParen 1261:1262
Newline 1262:1263
Ident 1267:1270 text="row"
LParen 1270:1271
Number 1271:1272 text="3" suf="" isf=0 int=3
Comma 1272:1273
Minus 1274:1275
Number 1275:1278 text="1.0" suf="" isf=1 int=-
Comma 1278:1279
Number 1280:1283 text="1.0" suf="" isf=1 int=-
RParen 1283:1284
Newline 1284:1285
Ident 1289:1292 text="row"
LParen 1292:1293
Number 1293:1294 text="4" suf="" isf=0 int=4
Comma 1294:1295
Minus 1296:1297
Number 1297:1300 text="2.0" suf="" isf=1 int=-
Comma 1300:1301
Minus 1302:1303
Number 1303:1306 text="1.0" suf="" isf=1 int=-
RParen 1306:1307
Newline 1307:1308
Ident 1312:1315 text="row"
LParen 1315:1316
Number 1316:1317 text="5" suf="" isf=0 int=5
Comma 1317:1318
Minus 1319:1320
Number 1320:1323 text="1.0" suf="" isf=1 int=-
Comma 1323:1324
Minus 1325:1326
Number 1326:1329 text="2.0" suf="" isf=1 int=-
RParen 1329:1330
Newline 1330:1331
Ident 1335:1338 text="row"
LParen 1338:1339
Number 1339:1340 text="6" suf="" isf=0 int=6
Comma 1340:1341
Number 1342:1345 text="0.0" suf="" isf=1 int=-
Comma 1345:1346
Number 1347:1350 text="0.0" suf="" isf=1 int=-
RParen 1350:1351
Newline 1351:1352
Ident 1356:1359 text="row"
LParen 1359:1360
Number 1360:1361 text="7" suf="" isf=0 int=7
Comma 1361:1362
Number 1363:1366 text="0.0" suf="" isf=1 int=-
Comma 1366:1367
Minus 1368:1369
Number 1369:1372 text="0.0" suf="" isf=1 int=-
RParen 1372:1373
Newline 1373:1374
Ident 1378:1381 text="row"
LParen 1381:1382
Number 1382:1383 text="8" suf="" isf=0 int=8
Comma 1383:1384
Minus 1385:1386
Number 1386:1389 text="0.0" suf="" isf=1 int=-
Comma 1389:1390
Number 1391:1394 text="0.0" suf="" isf=1 int=-
RParen 1394:1395
Newline 1395:1396
Ident 1400:1403 text="row"
LParen 1403:1404
Number 1404:1405 text="9" suf="" isf=0 int=9
Comma 1405:1406
Number 1407:1410 text="0.5" suf="" isf=1 int=-
Comma 1410:1411
Minus 1412:1413
Number 1413:1416 text="0.5" suf="" isf=1 int=-
RParen 1416:1417
Newline 1417:1418
Newline 1486:1487
Ident 1491:1494 text="row"
LParen 1494:1495
Number 1495:1497 text="10" suf="" isf=0 int=10
Comma 1497:1498
Number 1499:1507 text="1.0e-320" suf="" isf=1 int=-
Comma 1507:1508
Number 1509:1517 text="1.0e-320" suf="" isf=1 int=-
RParen 1517:1518
Newline 1518:1519
Ident 1523:1526 text="row"
LParen 1526:1527
Number 1527:1529 text="11" suf="" isf=0 int=11
Comma 1529:1530
Number 1531:1537 text="5e-324" suf="" isf=1 int=-
Comma 1537:1538
Number 1539:1547 text="1.0e-320" suf="" isf=1 int=-
RParen 1547:1548
Newline 1548:1549
Newline 1600:1601
Ident 1605:1608 text="row"
LParen 1608:1609
Number 1609:1611 text="12" suf="" isf=0 int=12
Comma 1611:1612
Number 1613:1635 text="1.7976931348623157e308" suf="" isf=1 int=-
Comma 1635:1636
Number 1637:1644 text="1.0e308" suf="" isf=1 int=-
RParen 1644:1645
Newline 1645:1646
Ident 1650:1653 text="row"
LParen 1653:1654
Number 1654:1656 text="13" suf="" isf=0 int=13
Comma 1656:1657
Number 1658:1661 text="1.0" suf="" isf=1 int=-
Comma 1661:1662
Number 1663:1685 text="1.7976931348623157e308" suf="" isf=1 int=-
RParen 1685:1686
Newline 1686:1687
Newline 1756:1757
Ident 1761:1768 text="println"
LParen 1768:1769
Str 1769:1774 T("c0 ")
Comma 1774:1775
Ident 1776:1777 text="b"
LParen 1777:1778
Number 1778:1781 text="1.0" suf="" isf=1 int=-
Lt 1782:1783
Number 1784:1787 text="2.0" suf="" isf=1 int=-
AndAnd 1788:1790
Number 1791:1794 text="2.0" suf="" isf=1 int=-
Lt 1795:1796
Number 1797:1800 text="3.0" suf="" isf=1 int=-
RParen 1800:1801
Comma 1801:1802
Ident 1803:1804 text="b"
LParen 1804:1805
Number 1805:1808 text="3.0" suf="" isf=1 int=-
Lt 1809:1810
Number 1811:1814 text="2.0" suf="" isf=1 int=-
AndAnd 1815:1817
Number 1818:1821 text="2.0" suf="" isf=1 int=-
Lt 1822:1823
Number 1824:1827 text="1.0" suf="" isf=1 int=-
RParen 1827:1828
RParen 1828:1829
Newline 1829:1830
Ident 1834:1841 text="println"
LParen 1841:1842
Str 1842:1847 T("c1 ")
Comma 1847:1848
Ident 1849:1850 text="b"
LParen 1850:1851
Number 1851:1854 text="1.0" suf="" isf=1 int=-
Le 1855:1857
Number 1858:1861 text="1.0" suf="" isf=1 int=-
AndAnd 1862:1864
Number 1865:1868 text="1.0" suf="" isf=1 int=-
Ge 1869:1871
Number 1872:1875 text="1.0" suf="" isf=1 int=-
RParen 1875:1876
Comma 1876:1877
Ident 1878:1879 text="b"
LParen 1879:1880
Number 1880:1883 text="1.0" suf="" isf=1 int=-
Ge 1884:1886
Number 1887:1890 text="2.0" suf="" isf=1 int=-
RParen 1890:1891
RParen 1891:1892
Newline 1892:1893
Ident 1897:1904 text="println"
LParen 1904:1905
Str 1905:1910 T("c2 ")
Comma 1910:1911
Ident 1912:1913 text="b"
LParen 1913:1914
Number 1914:1917 text="1.0" suf="" isf=1 int=-
Gt 1918:1919
Number 1920:1923 text="2.0" suf="" isf=1 int=-
OrOr 1924:1926
Number 1927:1930 text="2.0" suf="" isf=1 int=-
Gt 1931:1932
Number 1933:1936 text="3.0" suf="" isf=1 int=-
RParen 1936:1937
Comma 1937:1938
Ident 1939:1940 text="b"
LParen 1940:1941
Number 1941:1944 text="1.0" suf="" isf=1 int=-
Gt 1945:1946
Number 1947:1950 text="2.0" suf="" isf=1 int=-
OrOr 1951:1953
Number 1954:1957 text="3.0" suf="" isf=1 int=-
Gt 1958:1959
Number 1960:1963 text="2.0" suf="" isf=1 int=-
RParen 1963:1964
RParen 1964:1965
Newline 1965:1966
Newline 2042:2043
Newline 2111:2112
Var 2116:2119
Ident 2120:2121 text="n"
Assign 2122:2123
Number 2124:2125 text="0" suf="" isf=0 int=0
Newline 2125:2126
Var 2130:2133
Ident 2134:2135 text="i"
Assign 2136:2137
Number 2138:2139 text="0" suf="" isf=0 int=0
Newline 2139:2140
While 2144:2149
LParen 2150:2151
Ident 2151:2152 text="i"
Lt 2153:2154
Number 2155:2156 text="6" suf="" isf=0 int=6
RParen 2156:2157
LBrace 2158:2159
Newline 2159:2160
If 2168:2170
LParen 2171:2172
Ident 2172:2181 text="floats_lt"
LParen 2181:2182
Ident 2182:2183 text="i"
RParen 2183:2184
RParen 2184:2185
LBrace 2186:2187
Newline 2187:2188
Ident 2200:2201 text="n"
Assign 2202:2203
Ident 2204:2205 text="n"
Plus 2206:2207
Number 2208:2209 text="1" suf="" isf=0 int=1
Newline 2209:2210
RBrace 2218:2219
Newline 2219:2220
Ident 2228:2229 text="i"
Assign 2230:2231
Ident 2232:2233 text="i"
Plus 2234:2235
Number 2236:2237 text="1" suf="" isf=0 int=1
Newline 2237:2238
RBrace 2242:2243
Newline 2243:2244
Ident 2248:2255 text="println"
LParen 2255:2256
Str 2256:2264 T("count ")
Comma 2264:2265
Ident 2266:2267 text="n"
RParen 2267:2268
Newline 2268:2269
Ident 2273:2280 text="println"
LParen 2280:2281
Str 2281:2288 T("sign ")
Comma 2288:2289
Ident 2290:2291 text="b"
LParen 2291:2292
Number 2292:2295 text="0.0" suf="" isf=1 int=-
Lt 2296:2297
Minus 2298:2299
Number 2299:2302 text="0.0" suf="" isf=1 int=-
RParen 2302:2303
Comma 2303:2304
Ident 2305:2306 text="b"
LParen 2306:2307
Minus 2307:2308
Number 2308:2311 text="0.0" suf="" isf=1 int=-
Lt 2312:2313
Number 2314:2317 text="0.0" suf="" isf=1 int=-
RParen 2317:2318
Comma 2318:2319
Ident 2320:2321 text="b"
LParen 2321:2322
Number 2322:2325 text="0.0" suf="" isf=1 int=-
EqEq 2326:2328
Minus 2329:2330
Number 2330:2333 text="0.0" suf="" isf=1 int=-
RParen 2333:2334
RParen 2334:2335
Newline 2335:2336
RBrace 2336:2337
Newline 2337:2338
Newline 2338:2339
Fn 2339:2341
Ident 2342:2351 text="floats_lt"
LParen 2351:2352
Ident 2352:2353 text="i"
Colon 2353:2354
Ident 2355:2358 text="int"
RParen 2358:2359
Colon 2359:2360
Ident 2361:2365 text="bool"
LBrace 2366:2367
Newline 2367:2368
If 2372:2374
LParen 2375:2376
Ident 2376:2377 text="i"
Lt 2378:2379
Number 2380:2381 text="3" suf="" isf=0 int=3
RParen 2381:2382
LBrace 2383:2384
Newline 2384:2385
Return 2393:2399
Number 2400:2403 text="1.0" suf="" isf=1 int=-
Lt 2404:2405
Number 2406:2409 text="2.0" suf="" isf=1 int=-
Newline 2409:2410
RBrace 2414:2415
Newline 2415:2416
If 2420:2422
LParen 2423:2424
Ident 2424:2425 text="i"
Lt 2426:2427
Number 2428:2429 text="5" suf="" isf=0 int=5
RParen 2429:2430
LBrace 2431:2432
Newline 2432:2433
Return 2441:2447
Number 2448:2451 text="2.0" suf="" isf=1 int=-
Lt 2452:2453
Number 2454:2457 text="1.0" suf="" isf=1 int=-
Newline 2457:2458
RBrace 2462:2463
Newline 2463:2464
Number 2468:2471 text="1.0" suf="" isf=1 int=-
NotEq 2472:2474
Number 2475:2478 text="1.0" suf="" isf=1 int=-
Newline 2478:2479
RBrace 2479:2480
Eof 2480:2480
