Newline 80:81
Newline 162:163
Newline 241:242
Newline 322:323
Newline 355:356
Newline 357:358
Class 358:363
Ident 364:370 text="Holder"
LBrace 371:372
Newline 373:374
Var 378:381
Ident 382:389 text="backing"
Colon 389:390
Ident 391:394 text="int"
Assign 395:396
Number 397:398 text="0" suf="" isf=0 int=0
Newline 399:400
Newline 401:402
Property 406:414
Ident 415:420 text="value"
Colon 420:421
Ident 422:425 text="int"
LBrace 426:427
Newline 428:429
Get 437:440
LBrace 441:442
Return 443:449
This 450:454
Dot 454:455
Ident 455:462 text="backing"
RBrace 463:464
Newline 465:466
Set 474:477
LBrace 478:479
This 480:484
Dot 484:485
Ident 485:492 text="backing"
Assign 493:494
Ident 495:500 text="value"
RBrace 501:502
Newline 503:504
RBrace 508:509
Newline 510:511
Newline 512:513
Property 517:525
Ident 526:530 text="boom"
Colon 530:531
Ident 532:535 text="int"
LBrace 536:537
Newline 538:539
Get 547:550
LBrace 551:552
Return 553:559
Number 560:561 text="0" suf="" isf=0 int=0
RBrace 562:563
Newline 564:565
Set 573:576
LBrace 577:578
Throw 579:584
Str 585:598 T("setter boom")
RBrace 599:600
Newline 601:602
RBrace 606:607
Newline 608:609
Newline 610:611
Property 615:623
Ident 624:629 text="plain"
Colon 629:630
Ident 631:634 text="int"
LBrace 635:636
Newline 637:638
Get 646:649
LBrace 650:651
Return 652:658
This 659:663
Dot 663:664
Ident 664:671 text="backing"
RBrace 672:673
Newline 674:675
Set 683:686
LBrace 687:688
This 689:693
Dot 693:694
Ident 694:701 text="backing"
Assign 702:703
Ident 704:709 text="value"
RBrace 710:711
Newline 712:713
RBrace 717:718
Newline 719:720
RBrace 720:721
Newline 722:723
Newline 724:725
Fn 725:727
Ident 728:733 text="id_fn"
Lt 733:734
Ident 734:735 text="T"
Gt 735:736
LParen 736:737
Ident 737:738 text="x"
Colon 738:739
Ident 740:741 text="T"
RParen 741:742
Arrow 743:745
Ident 746:747 text="T"
LBrace 748:749
Newline 750:751
Return 755:761
Ident 762:763 text="x"
Newline 764:765
RBrace 765:766
Newline 767:768
Newline 769:770
Fn 770:772
Ident 773:777 text="sum3"
LParen 777:778
Ident 778:779 text="a"
Colon 779:780
Ident 781:784 text="int"
Comma 784:785
Ident 786:787 text="b"
Colon 787:788
Ident 789:792 text="int"
Comma 792:793
Ident 794:795 text="c"
Colon 795:796
Ident 797:800 text="int"
RParen 800:801
Arrow 802:804
Ident 805:808 text="int"
LBrace 809:810
Newline 811:812
Return 816:822
Ident 823:824 text="a"
Plus 825:826
Ident 827:828 text="b"
Plus 829:830
Ident 831:832 text="c"
Newline 833:834
RBrace 834:835
Newline 836:837
Newline 838:839
Fn 839:841
Ident 842:855 text="sum3_throwing"
LParen 855:856
Ident 856:857 text="a"
Colon 857:858
Ident 859:862 text="int"
Comma 862:863
Ident 864:865 text="b"
Colon 865:866
Ident 867:870 text="int"
Comma 870:871
Ident 872:873 text="c"
Colon 873:874
Ident 875:878 text="int"
RParen 878:879
Arrow 880:882
Ident 883:886 text="int"
LBrace 887:888
Newline 889:890
Throw 894:899
Str 900:913 T("spread boom")
Newline 914:915
RBrace 915:916
Newline 917:918
Newline 919:920
Newline 996:997
Newline 1024:1025
Fn 1025:1027
Ident 1028:1045 text="uses_plain_setter"
LParen 1045:1046
Ident 1046:1047 text="h"
Colon 1047:1048
Ident 1049:1055 text="Holder"
Comma 1055:1056
Ident 1057:1058 text="n"
Colon 1058:1059
Ident 1060:1063 text="int"
RParen 1063:1064
Arrow 1065:1067
Ident 1068:1071 text="int"
LBrace 1072:1073
Newline 1074:1075
Ident 1079:1080 text="h"
Dot 1080:1081
Ident 1081:1086 text="plain"
Assign 1087:1088
Ident 1089:1090 text="n"
Newline 1091:1092
Return 1096:1102
Ident 1103:1104 text="h"
Dot 1104:1105
Ident 1105:1110 text="plain"
Newline 1111:1112
RBrace 1112:1113
Newline 1114:1115
Newline 1116:1117
Fn 1117:1119
Ident 1120:1136 text="sets_then_throws"
LParen 1136:1137
Ident 1137:1138 text="h"
Colon 1138:1139
Ident 1140:1146 text="Holder"
Comma 1146:1147
Ident 1148:1149 text="n"
Colon 1149:1150
Ident 1151:1154 text="int"
RParen 1154:1155
Arrow 1156:1158
Ident 1159:1162 text="int"
LBrace 1163:1164
Newline 1165:1166
Ident 1170:1171 text="h"
Dot 1171:1172
Ident 1172:1177 text="plain"
Assign 1178:1179
Ident 1180:1181 text="n"
Newline 1182:1183
Throw 1187:1192
Str 1193:1204 T("after set")
Newline 1205:1206
RBrace 1206:1207
Newline 1208:1209
Newline 1210:1211
Newline 1293:1294
Newline 1374:1375
Newline 1449:1450
Fn 1450:1452
Ident 1453:1480 text="setter_throw_caught_locally"
LParen 1480:1481
Ident 1481:1482 text="h"
Colon 1482:1483
Ident 1484:1490 text="Holder"
Comma 1490:1491
Ident 1492:1493 text="n"
Colon 1493:1494
Ident 1495:1498 text="int"
RParen 1498:1499
Arrow 1500:1502
Ident 1503:1506 text="int"
LBrace 1507:1508
Newline 1509:1510
Try 1514:1517
LBrace 1518:1519
Newline 1520:1521
Ident 1529:1530 text="h"
Dot 1530:1531
Ident 1531:1535 text="boom"
Assign 1536:1537
Ident 1538:1539 text="n"
Newline 1540:1541
Number 1549:1552 text="100" suf="" isf=0 int=100
Newline 1553:1554
RBrace 1558:1559
Catch 1560:1565
LParen 1566:1567
Ident 1567:1568 text="e"
RParen 1568:1569
LBrace 1570:1571
Newline 1572:1573
Number 1581:1582 text="7" suf="" isf=0 int=7
Newline 1583:1584
RBrace 1588:1589
Newline 1590:1591
RBrace 1591:1592
Newline 1593:1594
Newline 1595:1596
Ident 1596:1600 text="test"
Fn 1601:1603
Ident 1604:1635 text="an_ordinary_setter_is_unchanged"
LParen 1635:1636
RParen 1636:1637
LBrace 1638:1639
Newline 1640:1641
Let 1645:1648
Ident 1649:1650 text="h"
Assign 1651:1652
Ident 1653:1659 text="Holder"
LParen 1659:1660
RParen 1660:1661
Newline 1662:1663
Ident 1667:1673 text="expect"
LParen 1673:1674
Ident 1674:1679 text="id_fn"
Lt 1679:1680
Ident 1680:1683 text="int"
Gt 1683:1684
LParen 1684:1685
Ident 1685:1702 text="uses_plain_setter"
LParen 1702:1703
Ident 1703:1704 text="h"
Comma 1704:1705
Number 1706:1707 text="7" suf="" isf=0 int=7
RParen 1707:1708
RParen 1708:1709
RParen 1709:1710
Dot 1710:1711
Ident 1711:1715 text="toBe"
LParen 1715:1716
Number 1716:1717 text="7" suf="" isf=0 int=7
RParen 1717:1718
Newline 1719:1720
RBrace 1720:1721
Newline 1722:1723
Newline 1724:1725
Ident 1725:1729 text="test"
Fn 1730:1732
Ident 1733:1769 text="a_setter_call_is_a_propagation_point"
LParen 1769:1770
RParen 1770:1771
LBrace 1772:1773
Newline 1774:1775
Let 1779:1782
Ident 1783:1784 text="h"
Assign 1785:1786
Ident 1787:1793 text="Holder"
LParen 1793:1794
RParen 1794:1795
Newline 1796:1797
Try 1801:1804
LBrace 1805:1806
Newline 1807:1808
Ident 1816:1832 text="sets_then_throws"
LParen 1832:1833
Ident 1833:1834 text="h"
Comma 1834:1835
Number 1836:1837 text="1" suf="" isf=0 int=1
RParen 1837:1838
Newline 1839:1840
Ident 1848:1854 text="expect"
LParen 1854:1855
Str 1855:1865 T("no throw")
RParen 1865:1866
Dot 1866:1867
Ident 1867:1871 text="toBe"
LParen 1871:1872
Str 1872:1885 T("unreachable")
RParen 1885:1886
Newline 1887:1888
RBrace 1892:1893
Catch 1894:1899
LParen 1900:1901
Ident 1901:1902 text="e"
RParen 1902:1903
LBrace 1904:1905
Newline 1906:1907
Ident 1915:1921 text="expect"
LParen 1921:1922
Ident 1922:1923 text="e"
RParen 1923:1924
Dot 1924:1925
Ident 1925:1929 text="toBe"
LParen 1929:1930
Str 1930:1941 T("after set")
RParen 1941:1942
Newline 1943:1944
RBrace 1948:1949
Newline 1950:1951
RBrace 1951:1952
Newline 1953:1954
Newline 1955:1956
Ident 1956:1960 text="test"
Fn 1961:1963
Ident 1964:2011 text="a_throwing_setter_is_caught_by_an_enclosing_try"
LParen 2011:2012
RParen 2012:2013
LBrace 2014:2015
Newline 2016:2017
Let 2021:2024
Ident 2025:2026 text="h"
Assign 2027:2028
Ident 2029:2035 text="Holder"
LParen 2035:2036
RParen 2036:2037
Newline 2038:2039
Try 2043:2046
LBrace 2047:2048
Newline 2049:2050
Ident 2058:2059 text="h"
Dot 2059:2060
Ident 2060:2064 text="boom"
Assign 2065:2066
Number 2067:2068 text="5" suf="" isf=0 int=5
Newline 2069:2070
Ident 2078:2084 text="expect"
LParen 2084:2085
Str 2085:2095 T("no throw")
RParen 2095:2096
Dot 2096:2097
Ident 2097:2101 text="toBe"
LParen 2101:2102
Str 2102:2115 T("unreachable")
RParen 2115:2116
Newline 2117:2118
RBrace 2122:2123
Catch 2124:2129
LParen 2130:2131
Ident 2131:2132 text="e"
RParen 2132:2133
LBrace 2134:2135
Newline 2136:2137
Ident 2145:2151 text="expect"
LParen 2151:2152
Ident 2152:2153 text="e"
RParen 2153:2154
Dot 2154:2155
Ident 2155:2159 text="toBe"
LParen 2159:2160
Str 2160:2173 T("setter boom")
RParen 2173:2174
Newline 2175:2176
RBrace 2180:2181
Newline 2182:2183
RBrace 2183:2184
Newline 2185:2186
Newline 2187:2188
Ident 2188:2192 text="test"
Fn 2193:2195
Ident 2196:2242 text="a_throwing_setter_propagates_out_of_its_callee"
LParen 2242:2243
RParen 2243:2244
LBrace 2245:2246
Newline 2247:2248
Ident 2252:2258 text="expect"
LParen 2258:2259
Ident 2259:2264 text="id_fn"
Lt 2264:2265
Ident 2265:2268 text="int"
Gt 2268:2269
LParen 2269:2270
Ident 2270:2297 text="setter_throw_caught_locally"
LParen 2297:2298
Ident 2298:2304 text="Holder"
LParen 2304:2305
RParen 2305:2306
Comma 2306:2307
Number 2308:2309 text="3" suf="" isf=0 int=3
RParen 2309:2310
RParen 2310:2311
RParen 2311:2312
Dot 2312:2313
Ident 2313:2317 text="toBe"
LParen 2317:2318
Number 2318:2319 text="7" suf="" isf=0 int=7
RParen 2319:2320
Newline 2321:2322
RBrace 2322:2323
Newline 2324:2325
Newline 2326:2327
Newline 2407:2408
Newline 2488:2489
Newline 2543:2544
Fn 2544:2546
Ident 2547:2577 text="compound_setter_caught_locally"
LParen 2577:2578
Ident 2578:2579 text="h"
Colon 2579:2580
Ident 2581:2587 text="Holder"
Comma 2587:2588
Ident 2589:2590 text="n"
Colon 2590:2591
Ident 2592:2595 text="int"
RParen 2595:2596
Arrow 2597:2599
Ident 2600:2603 text="int"
LBrace 2604:2605
Newline 2606:2607
Try 2611:2614
LBrace 2615:2616
Newline 2617:2618
Ident 2626:2627 text="h"
Dot 2627:2628
Ident 2628:2632 text="boom"
PlusEq 2633:2635
Ident 2636:2637 text="n"
Newline 2638:2639
Number 2647:2650 text="100" suf="" isf=0 int=100
Newline 2651:2652
RBrace 2656:2657
Catch 2658:2663
LParen 2664:2665
Ident 2665:2666 text="e"
RParen 2666:2667
LBrace 2668:2669
Newline 2670:2671
Number 2679:2680 text="7" suf="" isf=0 int=7
Newline 2681:2682
RBrace 2686:2687
Newline 2688:2689
RBrace 2689:2690
Newline 2691:2692
Newline 2693:2694
Ident 2694:2698 text="test"
Fn 2699:2701
Ident 2702:2756 text="a_throwing_setter_in_compound_assign_is_caught_locally"
LParen 2756:2757
RParen 2757:2758
LBrace 2759:2760
Newline 2761:2762
Ident 2766:2772 text="expect"
LParen 2772:2773
Ident 2773:2778 text="id_fn"
Lt 2778:2779
Ident 2779:2782 text="int"
Gt 2782:2783
LParen 2783:2784
Ident 2784:2814 text="compound_setter_caught_locally"
LParen 2814:2815
Ident 2815:2821 text="Holder"
LParen 2821:2822
RParen 2822:2823
Comma 2823:2824
Number 2825:2826 text="1" suf="" isf=0 int=1
RParen 2826:2827
RParen 2827:2828
RParen 2828:2829
Dot 2829:2830
Ident 2830:2834 text="toBe"
LParen 2834:2835
Number 2835:2836 text="7" suf="" isf=0 int=7
RParen 2836:2837
Newline 2838:2839
RBrace 2839:2840
Newline 2841:2842
Newline 2843:2844
Newline 2920:2921
Newline 2993:2994
Class 2994:2999
Ident 3000:3012 text="StaticHolder"
LBrace 3013:3014
Newline 3015:3016
Static 3020:3026
Var 3027:3030
Ident 3031:3038 text="backing"
Colon 3038:3039
Ident 3040:3043 text="int"
Assign 3044:3045
Number 3046:3047 text="0" suf="" isf=0 int=0
Newline 3048:3049
Newline 3050:3051
Static 3055:3061
Property 3062:3070
Ident 3071:3076 text="value"
Colon 3076:3077
Ident 3078:3081 text="int"
LBrace 3082:3083
Newline 3084:3085
Get 3093:3096
LBrace 3097:3098
Return 3099:3105
Ident 3106:3118 text="StaticHolder"
Dot 3118:3119
Ident 3119:3126 text="backing"
RBrace 3127:3128
Newline 3129:3130
Set 3138:3141
LBrace 3142:3143
Ident 3144:3156 text="StaticHolder"
Dot 3156:3157
Ident 3157:3164 text="backing"
Assign 3165:3166
Ident 3167:3172 text="value"
RBrace 3173:3174
Newline 3175:3176
RBrace 3180:3181
Newline 3182:3183
Newline 3184:3185
Static 3189:3195
Property 3196:3204
Ident 3205:3209 text="boom"
Colon 3209:3210
Ident 3211:3214 text="int"
LBrace 3215:3216
Newline 3217:3218
Get 3226:3229
LBrace 3230:3231
Return 3232:3238
Number 3239:3240 text="0" suf="" isf=0 int=0
RBrace 3241:3242
Newline 3243:3244
Set 3252:3255
LBrace 3256:3257
Throw 3258:3263
Str 3264:3284 T("static setter boom")
RBrace 3285:3286
Newline 3287:3288
RBrace 3292:3293
Newline 3294:3295
RBrace 3295:3296
Newline 3297:3298
Newline 3299:3300
Fn 3300:3302
Ident 3303:3327 text="uses_plain_static_setter"
LParen 3327:3328
Ident 3328:3329 text="n"
Colon 3329:3330
Ident 3331:3334 text="int"
RParen 3334:3335
Arrow 3336:3338
Ident 3339:3342 text="int"
LBrace 3343:3344
Newline 3345:3346
Ident 3350:3362 text="StaticHolder"
Dot 3362:3363
Ident 3363:3368 text="value"
Assign 3369:3370
Ident 3371:3372 text="n"
Newline 3373:3374
Return 3378:3384
Ident 3385:3397 text="StaticHolder"
Dot 3397:3398
Ident 3398:3405 text="backing"
Newline 3406:3407
RBrace 3407:3408
Newline 3409:3410
Newline 3411:3412
Newline 3491:3492
Newline 3572:3573
Newline 3654:3655
Newline 3668:3669
Fn 3669:3671
Ident 3672:3688 text="static_boom_sets"
LParen 3688:3689
Ident 3689:3690 text="n"
Colon 3690:3691
Ident 3692:3695 text="int"
RParen 3695:3696
Arrow 3697:3699
Ident 3700:3703 text="int"
LBrace 3704:3705
Newline 3706:3707
Ident 3711:3723 text="StaticHolder"
Dot 3723:3724
Ident 3724:3728 text="boom"
Assign 3729:3730
Ident 3731:3732 text="n"
Newline 3733:3734
Return 3738:3744
Number 3745:3746 text="0" suf="" isf=0 int=0
Newline 3747:3748
RBrace 3748:3749
Newline 3750:3751
Newline 3752:3753
Ident 3753:3757 text="test"
Fn 3758:3760
Ident 3761:3799 text="an_ordinary_static_setter_is_unchanged"
LParen 3799:3800
RParen 3800:3801
LBrace 3802:3803
Newline 3804:3805
Ident 3809:3815 text="expect"
LParen 3815:3816
Ident 3816:3821 text="id_fn"
Lt 3821:3822
Ident 3822:3825 text="int"
Gt 3825:3826
LParen 3826:3827
Ident 3827:3851 text="uses_plain_static_setter"
LParen 3851:3852
Number 3852:3853 text="9" suf="" isf=0 int=9
RParen 3853:3854
RParen 3854:3855
RParen 3855:3856
Dot 3856:3857
Ident 3857:3861 text="toBe"
LParen 3861:3862
Number 3862:3863 text="9" suf="" isf=0 int=9
RParen 3863:3864
Newline 3865:3866
RBrace 3866:3867
Newline 3868:3869
Newline 3870:3871
Ident 3871:3875 text="test"
Fn 3876:3878
Ident 3879:3929 text="a_static_setter_throw_propagates_out_of_its_callee"
LParen 3929:3930
RParen 3930:3931
LBrace 3932:3933
Newline 3934:3935
Try 3939:3942
LBrace 3943:3944
Newline 3945:3946
Ident 3954:3970 text="static_boom_sets"
LParen 3970:3971
Number 3971:3972 text="4" suf="" isf=0 int=4
RParen 3972:3973
Newline 3974:3975
Ident 3983:3989 text="expect"
LParen 3989:3990
Str 3990:4000 T("no throw")
RParen 4000:4001
Dot 4001:4002
Ident 4002:4006 text="toBe"
LParen 4006:4007
Str 4007:4020 T("unreachable")
RParen 4020:4021
Newline 4022:4023
RBrace 4027:4028
Catch 4029:4034
LParen 4035:4036
Ident 4036:4037 text="e"
RParen 4037:4038
LBrace 4039:4040
Newline 4041:4042
Ident 4050:4056 text="expect"
LParen 4056:4057
Ident 4057:4058 text="e"
RParen 4058:4059
Dot 4059:4060
Ident 4060:4064 text="toBe"
LParen 4064:4065
Str 4065:4085 T("static setter boom")
RParen 4085:4086
Newline 4087:4088
RBrace 4092:4093
Newline 4094:4095
RBrace 4095:4096
Newline 4097:4098
Newline 4099:4100
Newline 4126:4127
Newline 4128:4129
Fn 4129:4131
Ident 4132:4144 text="spread_plain"
LParen 4144:4145
Ident 4145:4147 text="xs"
Colon 4147:4148
Ident 4149:4153 text="List"
Lt 4153:4154
Ident 4154:4157 text="int"
Gt 4157:4158
RParen 4158:4159
Arrow 4160:4162
Ident 4163:4166 text="int"
LBrace 4167:4168
Newline 4169:4170
Return 4174:4180
Ident 4181:4185 text="sum3"
LParen 4185:4186
Number 4186:4187 text="1" suf="" isf=0 int=1
Comma 4187:4188
Ellipsis 4189:4192
Ident 4192:4194 text="xs"
RParen 4194:4195
Newline 4196:4197
RBrace 4197:4198
Newline 4199:4200
Newline 4201:4202
Fn 4202:4204
Ident 4205:4223 text="spread_of_throwing"
LParen 4223:4224
RParen 4224:4225
Arrow 4226:4228
Ident 4229:4232 text="int"
LBrace 4233:4234
Newline 4235:4236
Return 4240:4246
Ident 4247:4260 text="sum3_throwing"
LParen 4260:4261
Number 4261:4262 text="1" suf="" isf=0 int=1
Comma 4262:4263
Number 4264:4265 text="2" suf="" isf=0 int=2
Comma 4265:4266
Number 4267:4268 text="3" suf="" isf=0 int=3
RParen 4268:4269
Newline 4270:4271
RBrace 4271:4272
Newline 4273:4274
Newline 4275:4276
Ident 4276:4280 text="test"
Fn 4281:4283
Ident 4284:4321 text="a_spread_call_still_returns_its_value"
LParen 4321:4322
RParen 4322:4323
LBrace 4324:4325
Newline 4326:4327
Ident 4331:4337 text="expect"
LParen 4337:4338
Ident 4338:4343 text="id_fn"
Lt 4343:4344
Ident 4344:4347 text="int"
Gt 4347:4348
LParen 4348:4349
Ident 4349:4361 text="spread_plain"
LParen 4361:4362
LBracket 4362:4363
Number 4363:4365 text="10" suf="" isf=0 int=10
Comma 4365:4366
Number 4367:4370 text="100" suf="" isf=0 int=100
RBracket 4370:4371
RParen 4371:4372
RParen 4372:4373
RParen 4373:4374
Dot 4374:4375
Ident 4375:4379 text="toBe"
LParen 4379:4380
Number 4380:4383 text="111" suf="" isf=0 int=111
RParen 4383:4384
Newline 4385:4386
RBrace 4386:4387
Newline 4388:4389
Newline 4390:4391
Ident 4391:4395 text="test"
Fn 4396:4398
Ident 4399:4446 text="a_spread_call_to_a_throwing_function_propagates"
LParen 4446:4447
RParen 4447:4448
LBrace 4449:4450
Newline 4451:4452
Try 4456:4459
LBrace 4460:4461
Newline 4462:4463
Ident 4471:4489 text="spread_of_throwing"
LParen 4489:4490
RParen 4490:4491
Newline 4492:4493
Ident 4501:4507 text="expect"
LParen 4507:4508
Str 4508:4518 T("no throw")
RParen 4518:4519
Dot 4519:4520
Ident 4520:4524 text="toBe"
LParen 4524:4525
Str 4525:4538 T("unreachable")
RParen 4538:4539
Newline 4540:4541
RBrace 4545:4546
Catch 4547:4552
LParen 4553:4554
Ident 4554:4555 text="e"
RParen 4555:4556
LBrace 4557:4558
Newline 4559:4560
Ident 4568:4574 text="expect"
LParen 4574:4575
Ident 4575:4576 text="e"
RParen 4576:4577
Dot 4577:4578
Ident 4578:4582 text="toBe"
LParen 4582:4583
Str 4583:4596 T("spread boom")
RParen 4596:4597
Newline 4598:4599
RBrace 4603:4604
Newline 4605:4606
RBrace 4606:4607
Newline 4608:4609
Newline 4610:4611
Fn 4611:4613
Ident 4614:4629 text="spread_in_a_try"
LParen 4629:4630
Ident 4630:4632 text="xs"
Colon 4632:4633
Ident 4634:4638 text="List"
Lt 4638:4639
Ident 4639:4642 text="int"
Gt 4642:4643
RParen 4643:4644
Arrow 4645:4647
Ident 4648:4651 text="int"
LBrace 4652:4653
Newline 4654:4655
Try 4659:4662
LBrace 4663:4664
Newline 4665:4666
Ident 4674:4678 text="sum3"
LParen 4678:4679
Ellipsis 4679:4682
Ident 4682:4684 text="xs"
RParen 4684:4685
Newline 4686:4687
RBrace 4691:4692
Catch 4693:4698
LParen 4699:4700
Ident 4700:4701 text="e"
RParen 4701:4702
LBrace 4703:4704
Newline 4705:4706
Minus 4714:4715
Number 4715:4716 text="1" suf="" isf=0 int=1
Newline 4717:4718
RBrace 4722:4723
Newline 4724:4725
RBrace 4725:4726
Newline 4727:4728
Newline 4729:4730
Ident 4730:4734 text="test"
Fn 4735:4737
Ident 4738:4780 text="a_spread_call_inside_a_try_keeps_its_value"
LParen 4780:4781
RParen 4781:4782
LBrace 4783:4784
Newline 4785:4786
Ident 4790:4796 text="expect"
LParen 4796:4797
Ident 4797:4802 text="id_fn"
Lt 4802:4803
Ident 4803:4806 text="int"
Gt 4806:4807
LParen 4807:4808
Ident 4808:4823 text="spread_in_a_try"
LParen 4823:4824
LBracket 4824:4825
Number 4825:4826 text="1" suf="" isf=0 int=1
Comma 4826:4827
Number 4828:4829 text="2" suf="" isf=0 int=2
Comma 4829:4830
Number 4831:4832 text="3" suf="" isf=0 int=3
RBracket 4832:4833
RParen 4833:4834
RParen 4834:4835
RParen 4835:4836
Dot 4836:4837
Ident 4837:4841 text="toBe"
LParen 4841:4842
Number 4842:4843 text="6" suf="" isf=0 int=6
RParen 4843:4844
Newline 4845:4846
RBrace 4846:4847
Newline 4848:4849
Newline 4850:4851
Newline 4932:4933
Newline 4992:4993
Fn 4993:4995
Ident 4996:5007 text="spread_tail"
LParen 5007:5008
Ident 5008:5010 text="xs"
Colon 5010:5011
Ident 5012:5016 text="List"
Lt 5016:5017
Ident 5017:5020 text="int"
Gt 5020:5021
RParen 5021:5022
Arrow 5023:5025
Ident 5026:5029 text="int"
LBrace 5030:5031
Newline 5032:5033
Return 5037:5043
Ident 5044:5048 text="sum3"
LParen 5048:5049
Number 5049:5050 text="1" suf="" isf=0 int=1
Comma 5050:5051
Number 5052:5053 text="1" suf="" isf=0 int=1
Comma 5053:5054
Ellipsis 5055:5058
Ident 5058:5060 text="xs"
RParen 5060:5061
Newline 5062:5063
RBrace 5063:5064
Newline 5065:5066
Newline 5067:5068
Ident 5068:5072 text="test"
Fn 5073:5075
Ident 5076:5110 text="a_spread_tail_call_keeps_its_value"
LParen 5110:5111
RParen 5111:5112
LBrace 5113:5114
Newline 5115:5116
Ident 5120:5126 text="expect"
LParen 5126:5127
Ident 5127:5132 text="id_fn"
Lt 5132:5133
Ident 5133:5136 text="int"
Gt 5136:5137
LParen 5137:5138
Ident 5138:5149 text="spread_tail"
LParen 5149:5150
LBracket 5150:5151
Number 5151:5152 text="5" suf="" isf=0 int=5
RBracket 5152:5153
RParen 5153:5154
RParen 5154:5155
RParen 5155:5156
Dot 5156:5157
Ident 5157:5161 text="toBe"
LParen 5161:5162
Number 5162:5163 text="7" suf="" isf=0 int=7
RParen 5163:5164
Newline 5165:5166
RBrace 5166:5167
Newline 5168:5169
Newline 5170:5171
Newline 5220:5221
Newline 5222:5223
Class 5223:5228
Ident 5229:5236 text="Counter"
LBrace 5237:5238
Newline 5239:5240
Var 5244:5247
Ident 5248:5249 text="n"
Colon 5249:5250
Ident 5251:5254 text="int"
Assign 5255:5256
Number 5257:5258 text="0" suf="" isf=0 int=0
Newline 5259:5260
Fn 5264:5266
Ident 5267:5271 text="bump"
LParen 5271:5272
RParen 5272:5273
LBrace 5274:5275
Newline 5276:5277
This 5285:5289
Dot 5289:5290
Ident 5290:5291 text="n"
Assign 5292:5293
This 5294:5298
Dot 5298:5299
Ident 5299:5300 text="n"
Plus 5301:5302
Number 5303:5304 text="1" suf="" isf=0 int=1
Newline 5305:5306
RBrace 5310:5311
Newline 5312:5313
Fn 5317:5319
Ident 5320:5324 text="boom"
LParen 5324:5325
RParen 5325:5326
LBrace 5327:5328
Newline 5329:5330
Throw 5338:5343
Str 5344:5357 T("method boom")
Newline 5358:5359
RBrace 5363:5364
Newline 5365:5366
RBrace 5366:5367
Newline 5368:5369
Newline 5370:5371
Fn 5371:5373
Ident 5374:5390 text="calls_bump_twice"
LParen 5390:5391
Ident 5391:5392 text="c"
Colon 5392:5393
Ident 5394:5401 text="Counter"
RParen 5401:5402
Arrow 5403:5405
Ident 5406:5409 text="int"
LBrace 5410:5411
Newline 5412:5413
Ident 5417:5418 text="c"
Dot 5418:5419
Ident 5419:5423 text="bump"
LParen 5423:5424
RParen 5424:5425
Newline 5426:5427
Ident 5431:5432 text="c"
Dot 5432:5433
Ident 5433:5437 text="bump"
LParen 5437:5438
RParen 5438:5439
Newline 5440:5441
Return 5445:5451
Ident 5452:5453 text="c"
Dot 5453:5454
Ident 5454:5455 text="n"
Newline 5456:5457
RBrace 5457:5458
Newline 5459:5460
Newline 5461:5462
Fn 5462:5464
Ident 5465:5475 text="calls_boom"
LParen 5475:5476
Ident 5476:5477 text="c"
Colon 5477:5478
Ident 5479:5486 text="Counter"
RParen 5486:5487
Arrow 5488:5490
Ident 5491:5494 text="int"
LBrace 5495:5496
Newline 5497:5498
Ident 5502:5503 text="c"
Dot 5503:5504
Ident 5504:5508 text="boom"
LParen 5508:5509
RParen 5509:5510
Newline 5511:5512
Return 5516:5522
Number 5523:5524 text="0" suf="" isf=0 int=0
Newline 5525:5526
RBrace 5526:5527
Newline 5528:5529
Newline 5530:5531
Ident 5531:5535 text="test"
Fn 5536:5538
Ident 5539:5578 text="repeated_method_calls_keep_accumulating"
LParen 5578:5579
RParen 5579:5580
LBrace 5581:5582
Newline 5583:5584
Let 5588:5591
Ident 5592:5593 text="c"
Assign 5594:5595
Ident 5596:5603 text="Counter"
LParen 5603:5604
RParen 5604:5605
Newline 5606:5607
Ident 5611:5617 text="expect"
LParen 5617:5618
Ident 5618:5623 text="id_fn"
Lt 5623:5624
Ident 5624:5627 text="int"
Gt 5627:5628
LParen 5628:5629
Ident 5629:5645 text="calls_bump_twice"
LParen 5645:5646
Ident 5646:5647 text="c"
RParen 5647:5648
RParen 5648:5649
RParen 5649:5650
Dot 5650:5651
Ident 5651:5655 text="toBe"
LParen 5655:5656
Number 5656:5657 text="2" suf="" isf=0 int=2
RParen 5657:5658
Newline 5659:5660
RBrace 5660:5661
Newline 5662:5663
Newline 5664:5665
Ident 5665:5669 text="test"
Fn 5670:5672
Ident 5673:5712 text="a_method_throw_propagates_to_the_caller"
LParen 5712:5713
RParen 5713:5714
LBrace 5715:5716
Newline 5717:5718
Try 5722:5725
LBrace 5726:5727
Newline 5728:5729
Ident 5737:5747 text="calls_boom"
LParen 5747:5748
Ident 5748:5755 text="Counter"
LParen 5755:5756
RParen 5756:5757
RParen 5757:5758
Newline 5759:5760
Ident 5768:5774 text="expect"
LParen 5774:5775
Str 5775:5785 T("no throw")
RParen 5785:5786
Dot 5786:5787
Ident 5787:5791 text="toBe"
LParen 5791:5792
Str 5792:5805 T("unreachable")
RParen 5805:5806
Newline 5807:5808
RBrace 5812:5813
Catch 5814:5819
LParen 5820:5821
Ident 5821:5822 text="e"
RParen 5822:5823
LBrace 5824:5825
Newline 5826:5827
Ident 5835:5841 text="expect"
LParen 5841:5842
Ident 5842:5843 text="e"
RParen 5843:5844
Dot 5844:5845
Ident 5845:5849 text="toBe"
LParen 5849:5850
Str 5850:5863 T("method boom")
RParen 5863:5864
Newline 5865:5866
RBrace 5870:5871
Newline 5872:5873
RBrace 5873:5874
Newline 5875:5876
Eof 5876:5876
