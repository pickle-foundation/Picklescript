Newline 79:80
Newline 160:161
Newline 238:239
Newline 318:319
Newline 350:351
Newline 351:352
Class 352:357
Ident 358:364 text="Holder"
LBrace 365:366
Newline 366:367
Var 371:374
Ident 375:382 text="backing"
Colon 382:383
Ident 384:387 text="int"
Assign 388:389
Number 390:391 text="0" suf="" isf=0 int=0
Newline 391:392
Newline 392:393
Property 397:405
Ident 406:411 text="value"
Colon 411:412
Ident 413:416 text="int"
LBrace 417:418
Newline 418:419
Get 427:430
LBrace 431:432
Return 433:439
This 440:444
Dot 444:445
Ident 445:452 text="backing"
RBrace 453:454
Newline 454:455
Set 463:466
LBrace 467:468
This 469:473
Dot 473:474
Ident 474:481 text="backing"
Assign 482:483
Ident 484:489 text="value"
RBrace 490:491
Newline 491:492
RBrace 496:497
Newline 497:498
Newline 498:499
Property 503:511
Ident 512:516 text="boom"
Colon 516:517
Ident 518:521 text="int"
LBrace 522:523
Newline 523:524
Get 532:535
LBrace 536:537
Return 538:544
Number 545:546 text="0" suf="" isf=0 int=0
RBrace 547:548
Newline 548:549
Set 557:560
LBrace 561:562
Throw 563:568
Str 569:582 T("setter boom")
RBrace 583:584
Newline 584:585
RBrace 589:590
Newline 590:591
Newline 591:592
Property 596:604
Ident 605:610 text="plain"
Colon 610:611
Ident 612:615 text="int"
LBrace 616:617
Newline 617:618
Get 626:629
LBrace 630:631
Return 632:638
This 639:643
Dot 643:644
Ident 644:651 text="backing"
RBrace 652:653
Newline 653:654
Set 662:665
LBrace 666:667
This 668:672
Dot 672:673
Ident 673:680 text="backing"
Assign 681:682
Ident 683:688 text="value"
RBrace 689:690
Newline 690:691
RBrace 695:696
Newline 696:697
RBrace 697:698
Newline 698:699
Newline 699:700
Fn 700:702
Ident 703:708 text="id_fn"
Lt 708:709
Ident 709:710 text="T"
Gt 710:711
LParen 711:712
Ident 712:713 text="x"
Colon 713:714
Ident 715:716 text="T"
RParen 716:717
Arrow 718:720
Ident 721:722 text="T"
LBrace 723:724
Newline 724:725
Return 729:735
Ident 736:737 text="x"
Newline 737:738
RBrace 738:739
Newline 739:740
Newline 740:741
Fn 741:743
Ident 744:748 text="sum3"
LParen 748:749
Ident 749:750 text="a"
Colon 750:751
Ident 752:755 text="int"
Comma 755:756
Ident 757:758 text="b"
Colon 758:759
Ident 760:763 text="int"
Comma 763:764
Ident 765:766 text="c"
Colon 766:767
Ident 768:771 text="int"
RParen 771:772
Arrow 773:775
Ident 776:779 text="int"
LBrace 780:781
Newline 781:782
Return 786:792
Ident 793:794 text="a"
Plus 795:796
Ident 797:798 text="b"
Plus 799:800
Ident 801:802 text="c"
Newline 802:803
RBrace 803:804
Newline 804:805
Newline 805:806
Fn 806:808
Ident 809:822 text="sum3_throwing"
LParen 822:823
Ident 823:824 text="a"
Colon 824:825
Ident 826:829 text="int"
Comma 829:830
Ident 831:832 text="b"
Colon 832:833
Ident 834:837 text="int"
Comma 837:838
Ident 839:840 text="c"
Colon 840:841
Ident 842:845 text="int"
RParen 845:846
Arrow 847:849
Ident 850:853 text="int"
LBrace 854:855
Newline 855:856
Throw 860:865
Str 866:879 T("spread boom")
Newline 879:880
RBrace 880:881
Newline 881:882
Newline 882:883
Newline 958:959
Newline 985:986
Fn 986:988
Ident 989:1006 text="uses_plain_setter"
LParen 1006:1007
Ident 1007:1008 text="h"
Colon 1008:1009
Ident 1010:1016 text="Holder"
Comma 1016:1017
Ident 1018:1019 text="n"
Colon 1019:1020
Ident 1021:1024 text="int"
RParen 1024:1025
Arrow 1026:1028
Ident 1029:1032 text="int"
LBrace 1033:1034
Newline 1034:1035
Ident 1039:1040 text="h"
Dot 1040:1041
Ident 1041:1046 text="plain"
Assign 1047:1048
Ident 1049:1050 text="n"
Newline 1050:1051
Return 1055:1061
Ident 1062:1063 text="h"
Dot 1063:1064
Ident 1064:1069 text="plain"
Newline 1069:1070
RBrace 1070:1071
Newline 1071:1072
Newline 1072:1073
Fn 1073:1075
Ident 1076:1092 text="sets_then_throws"
LParen 1092:1093
Ident 1093:1094 text="h"
Colon 1094:1095
Ident 1096:1102 text="Holder"
Comma 1102:1103
Ident 1104:1105 text="n"
Colon 1105:1106
Ident 1107:1110 text="int"
RParen 1110:1111
Arrow 1112:1114
Ident 1115:1118 text="int"
LBrace 1119:1120
Newline 1120:1121
Ident 1125:1126 text="h"
Dot 1126:1127
Ident 1127:1132 text="plain"
Assign 1133:1134
Ident 1135:1136 text="n"
Newline 1136:1137
Throw 1141:1146
Str 1147:1158 T("after set")
Newline 1158:1159
RBrace 1159:1160
Newline 1160:1161
Newline 1161:1162
Newline 1243:1244
Newline 1323:1324
Newline 1397:1398
Fn 1398:1400
Ident 1401:1428 text="setter_throw_caught_locally"
LParen 1428:1429
Ident 1429:1430 text="h"
Colon 1430:1431
Ident 1432:1438 text="Holder"
Comma 1438:1439
Ident 1440:1441 text="n"
Colon 1441:1442
Ident 1443:1446 text="int"
RParen 1446:1447
Arrow 1448:1450
Ident 1451:1454 text="int"
LBrace 1455:1456
Newline 1456:1457
Try 1461:1464
LBrace 1465:1466
Newline 1466:1467
Ident 1475:1476 text="h"
Dot 1476:1477
Ident 1477:1481 text="boom"
Assign 1482:1483
Ident 1484:1485 text="n"
Newline 1485:1486
Number 1494:1497 text="100" suf="" isf=0 int=100
Newline 1497:1498
RBrace 1502:1503
Catch 1504:1509
LParen 1510:1511
Ident 1511:1512 text="e"
RParen 1512:1513
LBrace 1514:1515
Newline 1515:1516
Number 1524:1525 text="7" suf="" isf=0 int=7
Newline 1525:1526
RBrace 1530:1531
Newline 1531:1532
RBrace 1532:1533
Newline 1533:1534
Newline 1534:1535
Ident 1535:1539 text="test"
Fn 1540:1542
Ident 1543:1574 text="an_ordinary_setter_is_unchanged"
LParen 1574:1575
RParen 1575:1576
LBrace 1577:1578
Newline 1578:1579
Let 1583:1586
Ident 1587:1588 text="h"
Assign 1589:1590
Ident 1591:1597 text="Holder"
LParen 1597:1598
RParen 1598:1599
Newline 1599:1600
Ident 1604:1610 text="expect"
LParen 1610:1611
Ident 1611:1616 text="id_fn"
Lt 1616:1617
Ident 1617:1620 text="int"
Gt 1620:1621
LParen 1621:1622
Ident 1622:1639 text="uses_plain_setter"
LParen 1639:1640
Ident 1640:1641 text="h"
Comma 1641:1642
Number 1643:1644 text="7" suf="" isf=0 int=7
RParen 1644:1645
RParen 1645:1646
RParen 1646:1647
Dot 1647:1648
Ident 1648:1652 text="toBe"
LParen 1652:1653
Number 1653:1654 text="7" suf="" isf=0 int=7
RParen 1654:1655
Newline 1655:1656
RBrace 1656:1657
Newline 1657:1658
Newline 1658:1659
Ident 1659:1663 text="test"
Fn 1664:1666
Ident 1667:1703 text="a_setter_call_is_a_propagation_point"
LParen 1703:1704
RParen 1704:1705
LBrace 1706:1707
Newline 1707:1708
Let 1712:1715
Ident 1716:1717 text="h"
Assign 1718:1719
Ident 1720:1726 text="Holder"
LParen 1726:1727
RParen 1727:1728
Newline 1728:1729
Try 1733:1736
LBrace 1737:1738
Newline 1738:1739
Ident 1747:1763 text="sets_then_throws"
LParen 1763:1764
Ident 1764:1765 text="h"
Comma 1765:1766
Number 1767:1768 text="1" suf="" isf=0 int=1
RParen 1768:1769
Newline 1769:1770
Ident 1778:1784 text="expect"
LParen 1784:1785
Str 1785:1795 T("no throw")
RParen 1795:1796
Dot 1796:1797
Ident 1797:1801 text="toBe"
LParen 1801:1802
Str 1802:1815 T("unreachable")
RParen 1815:1816
Newline 1816:1817
RBrace 1821:1822
Catch 1823:1828
LParen 1829:1830
Ident 1830:1831 text="e"
RParen 1831:1832
LBrace 1833:1834
Newline 1834:1835
Ident 1843:1849 text="expect"
LParen 1849:1850
Ident 1850:1851 text="e"
RParen 1851:1852
Dot 1852:1853
Ident 1853:1857 text="toBe"
LParen 1857:1858
Str 1858:1869 T("after set")
RParen 1869:1870
Newline 1870:1871
RBrace 1875:1876
Newline 1876:1877
RBrace 1877:1878
Newline 1878:1879
Newline 1879:1880
Ident 1880:1884 text="test"
Fn 1885:1887
Ident 1888:1935 text="a_throwing_setter_is_caught_by_an_enclosing_try"
LParen 1935:1936
RParen 1936:1937
LBrace 1938:1939
Newline 1939:1940
Let 1944:1947
Ident 1948:1949 text="h"
Assign 1950:1951
Ident 1952:1958 text="Holder"
LParen 1958:1959
RParen 1959:1960
Newline 1960:1961
Try 1965:1968
LBrace 1969:1970
Newline 1970:1971
Ident 1979:1980 text="h"
Dot 1980:1981
Ident 1981:1985 text="boom"
Assign 1986:1987
Number 1988:1989 text="5" suf="" isf=0 int=5
Newline 1989:1990
Ident 1998:2004 text="expect"
LParen 2004:2005
Str 2005:2015 T("no throw")
RParen 2015:2016
Dot 2016:2017
Ident 2017:2021 text="toBe"
LParen 2021:2022
Str 2022:2035 T("unreachable")
RParen 2035:2036
Newline 2036:2037
RBrace 2041:2042
Catch 2043:2048
LParen 2049:2050
Ident 2050:2051 text="e"
RParen 2051:2052
LBrace 2053:2054
Newline 2054:2055
Ident 2063:2069 text="expect"
LParen 2069:2070
Ident 2070:2071 text="e"
RParen 2071:2072
Dot 2072:2073
Ident 2073:2077 text="toBe"
LParen 2077:2078
Str 2078:2091 T("setter boom")
RParen 2091:2092
Newline 2092:2093
RBrace 2097:2098
Newline 2098:2099
RBrace 2099:2100
Newline 2100:2101
Newline 2101:2102
Ident 2102:2106 text="test"
Fn 2107:2109
Ident 2110:2156 text="a_throwing_setter_propagates_out_of_its_callee"
LParen 2156:2157
RParen 2157:2158
LBrace 2159:2160
Newline 2160:2161
Ident 2165:2171 text="expect"
LParen 2171:2172
Ident 2172:2177 text="id_fn"
Lt 2177:2178
Ident 2178:2181 text="int"
Gt 2181:2182
LParen 2182:2183
Ident 2183:2210 text="setter_throw_caught_locally"
LParen 2210:2211
Ident 2211:2217 text="Holder"
LParen 2217:2218
RParen 2218:2219
Comma 2219:2220
Number 2221:2222 text="3" suf="" isf=0 int=3
RParen 2222:2223
RParen 2223:2224
RParen 2224:2225
Dot 2225:2226
Ident 2226:2230 text="toBe"
LParen 2230:2231
Number 2231:2232 text="7" suf="" isf=0 int=7
RParen 2232:2233
Newline 2233:2234
RBrace 2234:2235
Newline 2235:2236
Newline 2236:2237
Newline 2316:2317
Newline 2396:2397
Newline 2450:2451
Fn 2451:2453
Ident 2454:2484 text="compound_setter_caught_locally"
LParen 2484:2485
Ident 2485:2486 text="h"
Colon 2486:2487
Ident 2488:2494 text="Holder"
Comma 2494:2495
Ident 2496:2497 text="n"
Colon 2497:2498
Ident 2499:2502 text="int"
RParen 2502:2503
Arrow 2504:2506
Ident 2507:2510 text="int"
LBrace 2511:2512
Newline 2512:2513
Try 2517:2520
LBrace 2521:2522
Newline 2522:2523
Ident 2531:2532 text="h"
Dot 2532:2533
Ident 2533:2537 text="boom"
PlusEq 2538:2540
Ident 2541:2542 text="n"
Newline 2542:2543
Number 2551:2554 text="100" suf="" isf=0 int=100
Newline 2554:2555
RBrace 2559:2560
Catch 2561:2566
LParen 2567:2568
Ident 2568:2569 text="e"
RParen 2569:2570
LBrace 2571:2572
Newline 2572:2573
Number 2581:2582 text="7" suf="" isf=0 int=7
Newline 2582:2583
RBrace 2587:2588
Newline 2588:2589
RBrace 2589:2590
Newline 2590:2591
Newline 2591:2592
Ident 2592:2596 text="test"
Fn 2597:2599
Ident 2600:2654 text="a_throwing_setter_in_compound_assign_is_caught_locally"
LParen 2654:2655
RParen 2655:2656
LBrace 2657:2658
Newline 2658:2659
Ident 2663:2669 text="expect"
LParen 2669:2670
Ident 2670:2675 text="id_fn"
Lt 2675:2676
Ident 2676:2679 text="int"
Gt 2679:2680
LParen 2680:2681
Ident 2681:2711 text="compound_setter_caught_locally"
LParen 2711:2712
Ident 2712:2718 text="Holder"
LParen 2718:2719
RParen 2719:2720
Comma 2720:2721
Number 2722:2723 text="1" suf="" isf=0 int=1
RParen 2723:2724
RParen 2724:2725
RParen 2725:2726
Dot 2726:2727
Ident 2727:2731 text="toBe"
LParen 2731:2732
Number 2732:2733 text="7" suf="" isf=0 int=7
RParen 2733:2734
Newline 2734:2735
RBrace 2735:2736
Newline 2736:2737
Newline 2737:2738
Newline 2813:2814
Newline 2885:2886
Class 2886:2891
Ident 2892:2904 text="StaticHolder"
LBrace 2905:2906
Newline 2906:2907
Static 2911:2917
Var 2918:2921
Ident 2922:2929 text="backing"
Colon 2929:2930
Ident 2931:2934 text="int"
Assign 2935:2936
Number 2937:2938 text="0" suf="" isf=0 int=0
Newline 2938:2939
Newline 2939:2940
Static 2944:2950
Property 2951:2959
Ident 2960:2965 text="value"
Colon 2965:2966
Ident 2967:2970 text="int"
LBrace 2971:2972
Newline 2972:2973
Get 2981:2984
LBrace 2985:2986
Return 2987:2993
Ident 2994:3006 text="StaticHolder"
Dot 3006:3007
Ident 3007:3014 text="backing"
RBrace 3015:3016
Newline 3016:3017
Set 3025:3028
LBrace 3029:3030
Ident 3031:3043 text="StaticHolder"
Dot 3043:3044
Ident 3044:3051 text="backing"
Assign 3052:3053
Ident 3054:3059 text="value"
RBrace 3060:3061
Newline 3061:3062
RBrace 3066:3067
Newline 3067:3068
Newline 3068:3069
Static 3073:3079
Property 3080:3088
Ident 3089:3093 text="boom"
Colon 3093:3094
Ident 3095:3098 text="int"
LBrace 3099:3100
Newline 3100:3101
Get 3109:3112
LBrace 3113:3114
Return 3115:3121
Number 3122:3123 text="0" suf="" isf=0 int=0
RBrace 3124:3125
Newline 3125:3126
Set 3134:3137
LBrace 3138:3139
Throw 3140:3145
Str 3146:3166 T("static setter boom")
RBrace 3167:3168
Newline 3168:3169
RBrace 3173:3174
Newline 3174:3175
RBrace 3175:3176
Newline 3176:3177
Newline 3177:3178
Fn 3178:3180
Ident 3181:3205 text="uses_plain_static_setter"
LParen 3205:3206
Ident 3206:3207 text="n"
Colon 3207:3208
Ident 3209:3212 text="int"
RParen 3212:3213
Arrow 3214:3216
Ident 3217:3220 text="int"
LBrace 3221:3222
Newline 3222:3223
Ident 3227:3239 text="StaticHolder"
Dot 3239:3240
Ident 3240:3245 text="value"
Assign 3246:3247
Ident 3248:3249 text="n"
Newline 3249:3250
Return 3254:3260
Ident 3261:3273 text="StaticHolder"
Dot 3273:3274
Ident 3274:3281 text="backing"
Newline 3281:3282
RBrace 3282:3283
Newline 3283:3284
Newline 3284:3285
Newline 3363:3364
Newline 3443:3444
Newline 3524:3525
Newline 3537:3538
Fn 3538:3540
Ident 3541:3557 text="static_boom_sets"
LParen 3557:3558
Ident 3558:3559 text="n"
Colon 3559:3560
Ident 3561:3564 text="int"
RParen 3564:3565
Arrow 3566:3568
Ident 3569:3572 text="int"
LBrace 3573:3574
Newline 3574:3575
Ident 3579:3591 text="StaticHolder"
Dot 3591:3592
Ident 3592:3596 text="boom"
Assign 3597:3598
Ident 3599:3600 text="n"
Newline 3600:3601
Return 3605:3611
Number 3612:3613 text="0" suf="" isf=0 int=0
Newline 3613:3614
RBrace 3614:3615
Newline 3615:3616
Newline 3616:3617
Ident 3617:3621 text="test"
Fn 3622:3624
Ident 3625:3663 text="an_ordinary_static_setter_is_unchanged"
LParen 3663:3664
RParen 3664:3665
LBrace 3666:3667
Newline 3667:3668
Ident 3672:3678 text="expect"
LParen 3678:3679
Ident 3679:3684 text="id_fn"
Lt 3684:3685
Ident 3685:3688 text="int"
Gt 3688:3689
LParen 3689:3690
Ident 3690:3714 text="uses_plain_static_setter"
LParen 3714:3715
Number 3715:3716 text="9" suf="" isf=0 int=9
RParen 3716:3717
RParen 3717:3718
RParen 3718:3719
Dot 3719:3720
Ident 3720:3724 text="toBe"
LParen 3724:3725
Number 3725:3726 text="9" suf="" isf=0 int=9
RParen 3726:3727
Newline 3727:3728
RBrace 3728:3729
Newline 3729:3730
Newline 3730:3731
Ident 3731:3735 text="test"
Fn 3736:3738
Ident 3739:3789 text="a_static_setter_throw_propagates_out_of_its_callee"
LParen 3789:3790
RParen 3790:3791
LBrace 3792:3793
Newline 3793:3794
Try 3798:3801
LBrace 3802:3803
Newline 3803:3804
Ident 3812:3828 text="static_boom_sets"
LParen 3828:3829
Number 3829:3830 text="4" suf="" isf=0 int=4
RParen 3830:3831
Newline 3831:3832
Ident 3840:3846 text="expect"
LParen 3846:3847
Str 3847:3857 T("no throw")
RParen 3857:3858
Dot 3858:3859
Ident 3859:3863 text="toBe"
LParen 3863:3864
Str 3864:3877 T("unreachable")
RParen 3877:3878
Newline 3878:3879
RBrace 3883:3884
Catch 3885:3890
LParen 3891:3892
Ident 3892:3893 text="e"
RParen 3893:3894
LBrace 3895:3896
Newline 3896:3897
Ident 3905:3911 text="expect"
LParen 3911:3912
Ident 3912:3913 text="e"
RParen 3913:3914
Dot 3914:3915
Ident 3915:3919 text="toBe"
LParen 3919:3920
Str 3920:3940 T("static setter boom")
RParen 3940:3941
Newline 3941:3942
RBrace 3946:3947
Newline 3947:3948
RBrace 3948:3949
Newline 3949:3950
Newline 3950:3951
Newline 3976:3977
Newline 3977:3978
Fn 3978:3980
Ident 3981:3993 text="spread_plain"
LParen 3993:3994
Ident 3994:3996 text="xs"
Colon 3996:3997
Ident 3998:4002 text="List"
Lt 4002:4003
Ident 4003:4006 text="int"
Gt 4006:4007
RParen 4007:4008
Arrow 4009:4011
Ident 4012:4015 text="int"
LBrace 4016:4017
Newline 4017:4018
Return 4022:4028
Ident 4029:4033 text="sum3"
LParen 4033:4034
Number 4034:4035 text="1" suf="" isf=0 int=1
Comma 4035:4036
Ellipsis 4037:4040
Ident 4040:4042 text="xs"
RParen 4042:4043
Newline 4043:4044
RBrace 4044:4045
Newline 4045:4046
Newline 4046:4047
Fn 4047:4049
Ident 4050:4068 text="spread_of_throwing"
LParen 4068:4069
RParen 4069:4070
Arrow 4071:4073
Ident 4074:4077 text="int"
LBrace 4078:4079
Newline 4079:4080
Return 4084:4090
Ident 4091:4104 text="sum3_throwing"
LParen 4104:4105
Number 4105:4106 text="1" suf="" isf=0 int=1
Comma 4106:4107
Number 4108:4109 text="2" suf="" isf=0 int=2
Comma 4109:4110
Number 4111:4112 text="3" suf="" isf=0 int=3
RParen 4112:4113
Newline 4113:4114
RBrace 4114:4115
Newline 4115:4116
Newline 4116:4117
Ident 4117:4121 text="test"
Fn 4122:4124
Ident 4125:4162 text="a_spread_call_still_returns_its_value"
LParen 4162:4163
RParen 4163:4164
LBrace 4165:4166
Newline 4166:4167
Ident 4171:4177 text="expect"
LParen 4177:4178
Ident 4178:4183 text="id_fn"
Lt 4183:4184
Ident 4184:4187 text="int"
Gt 4187:4188
LParen 4188:4189
Ident 4189:4201 text="spread_plain"
LParen 4201:4202
LBracket 4202:4203
Number 4203:4205 text="10" suf="" isf=0 int=10
Comma 4205:4206
Number 4207:4210 text="100" suf="" isf=0 int=100
RBracket 4210:4211
RParen 4211:4212
RParen 4212:4213
RParen 4213:4214
Dot 4214:4215
Ident 4215:4219 text="toBe"
LParen 4219:4220
Number 4220:4223 text="111" suf="" isf=0 int=111
RParen 4223:4224
Newline 4224:4225
RBrace 4225:4226
Newline 4226:4227
Newline 4227:4228
Ident 4228:4232 text="test"
Fn 4233:4235
Ident 4236:4283 text="a_spread_call_to_a_throwing_function_propagates"
LParen 4283:4284
RParen 4284:4285
LBrace 4286:4287
Newline 4287:4288
Try 4292:4295
LBrace 4296:4297
Newline 4297:4298
Ident 4306:4324 text="spread_of_throwing"
LParen 4324:4325
RParen 4325:4326
Newline 4326:4327
Ident 4335:4341 text="expect"
LParen 4341:4342
Str 4342:4352 T("no throw")
RParen 4352:4353
Dot 4353:4354
Ident 4354:4358 text="toBe"
LParen 4358:4359
Str 4359:4372 T("unreachable")
RParen 4372:4373
Newline 4373:4374
RBrace 4378:4379
Catch 4380:4385
LParen 4386:4387
Ident 4387:4388 text="e"
RParen 4388:4389
LBrace 4390:4391
Newline 4391:4392
Ident 4400:4406 text="expect"
LParen 4406:4407
Ident 4407:4408 text="e"
RParen 4408:4409
Dot 4409:4410
Ident 4410:4414 text="toBe"
LParen 4414:4415
Str 4415:4428 T("spread boom")
RParen 4428:4429
Newline 4429:4430
RBrace 4434:4435
Newline 4435:4436
RBrace 4436:4437
Newline 4437:4438
Newline 4438:4439
Fn 4439:4441
Ident 4442:4457 text="spread_in_a_try"
LParen 4457:4458
Ident 4458:4460 text="xs"
Colon 4460:4461
Ident 4462:4466 text="List"
Lt 4466:4467
Ident 4467:4470 text="int"
Gt 4470:4471
RParen 4471:4472
Arrow 4473:4475
Ident 4476:4479 text="int"
LBrace 4480:4481
Newline 4481:4482
Try 4486:4489
LBrace 4490:4491
Newline 4491:4492
Ident 4500:4504 text="sum3"
LParen 4504:4505
Ellipsis 4505:4508
Ident 4508:4510 text="xs"
RParen 4510:4511
Newline 4511:4512
RBrace 4516:4517
Catch 4518:4523
LParen 4524:4525
Ident 4525:4526 text="e"
RParen 4526:4527
LBrace 4528:4529
Newline 4529:4530
Minus 4538:4539
Number 4539:4540 text="1" suf="" isf=0 int=1
Newline 4540:4541
RBrace 4545:4546
Newline 4546:4547
RBrace 4547:4548
Newline 4548:4549
Newline 4549:4550
Ident 4550:4554 text="test"
Fn 4555:4557
Ident 4558:4600 text="a_spread_call_inside_a_try_keeps_its_value"
LParen 4600:4601
RParen 4601:4602
LBrace 4603:4604
Newline 4604:4605
Ident 4609:4615 text="expect"
LParen 4615:4616
Ident 4616:4621 text="id_fn"
Lt 4621:4622
Ident 4622:4625 text="int"
Gt 4625:4626
LParen 4626:4627
Ident 4627:4642 text="spread_in_a_try"
LParen 4642:4643
LBracket 4643:4644
Number 4644:4645 text="1" suf="" isf=0 int=1
Comma 4645:4646
Number 4647:4648 text="2" suf="" isf=0 int=2
Comma 4648:4649
Number 4650:4651 text="3" suf="" isf=0 int=3
RBracket 4651:4652
RParen 4652:4653
RParen 4653:4654
RParen 4654:4655
Dot 4655:4656
Ident 4656:4660 text="toBe"
LParen 4660:4661
Number 4661:4662 text="6" suf="" isf=0 int=6
RParen 4662:4663
Newline 4663:4664
RBrace 4664:4665
Newline 4665:4666
Newline 4666:4667
Newline 4747:4748
Newline 4806:4807
Fn 4807:4809
Ident 4810:4821 text="spread_tail"
LParen 4821:4822
Ident 4822:4824 text="xs"
Colon 4824:4825
Ident 4826:4830 text="List"
Lt 4830:4831
Ident 4831:4834 text="int"
Gt 4834:4835
RParen 4835:4836
Arrow 4837:4839
Ident 4840:4843 text="int"
LBrace 4844:4845
Newline 4845:4846
Return 4850:4856
Ident 4857:4861 text="sum3"
LParen 4861:4862
Number 4862:4863 text="1" suf="" isf=0 int=1
Comma 4863:4864
Number 4865:4866 text="1" suf="" isf=0 int=1
Comma 4866:4867
Ellipsis 4868:4871
Ident 4871:4873 text="xs"
RParen 4873:4874
Newline 4874:4875
RBrace 4875:4876
Newline 4876:4877
Newline 4877:4878
Ident 4878:4882 text="test"
Fn 4883:4885
Ident 4886:4920 text="a_spread_tail_call_keeps_its_value"
LParen 4920:4921
RParen 4921:4922
LBrace 4923:4924
Newline 4924:4925
Ident 4929:4935 text="expect"
LParen 4935:4936
Ident 4936:4941 text="id_fn"
Lt 4941:4942
Ident 4942:4945 text="int"
Gt 4945:4946
LParen 4946:4947
Ident 4947:4958 text="spread_tail"
LParen 4958:4959
LBracket 4959:4960
Number 4960:4961 text="5" suf="" isf=0 int=5
RBracket 4961:4962
RParen 4962:4963
RParen 4963:4964
RParen 4964:4965
Dot 4965:4966
Ident 4966:4970 text="toBe"
LParen 4970:4971
Number 4971:4972 text="7" suf="" isf=0 int=7
RParen 4972:4973
Newline 4973:4974
RBrace 4974:4975
Newline 4975:4976
Newline 4976:4977
Newline 5025:5026
Newline 5026:5027
Class 5027:5032
Ident 5033:5040 text="Counter"
LBrace 5041:5042
Newline 5042:5043
Var 5047:5050
Ident 5051:5052 text="n"
Colon 5052:5053
Ident 5054:5057 text="int"
Assign 5058:5059
Number 5060:5061 text="0" suf="" isf=0 int=0
Newline 5061:5062
Fn 5066:5068
Ident 5069:5073 text="bump"
LParen 5073:5074
RParen 5074:5075
LBrace 5076:5077
Newline 5077:5078
This 5086:5090
Dot 5090:5091
Ident 5091:5092 text="n"
Assign 5093:5094
This 5095:5099
Dot 5099:5100
Ident 5100:5101 text="n"
Plus 5102:5103
Number 5104:5105 text="1" suf="" isf=0 int=1
Newline 5105:5106
RBrace 5110:5111
Newline 5111:5112
Fn 5116:5118
Ident 5119:5123 text="boom"
LParen 5123:5124
RParen 5124:5125
LBrace 5126:5127
Newline 5127:5128
Throw 5136:5141
Str 5142:5155 T("method boom")
Newline 5155:5156
RBrace 5160:5161
Newline 5161:5162
RBrace 5162:5163
Newline 5163:5164
Newline 5164:5165
Fn 5165:5167
Ident 5168:5184 text="calls_bump_twice"
LParen 5184:5185
Ident 5185:5186 text="c"
Colon 5186:5187
Ident 5188:5195 text="Counter"
RParen 5195:5196
Arrow 5197:5199
Ident 5200:5203 text="int"
LBrace 5204:5205
Newline 5205:5206
Ident 5210:5211 text="c"
Dot 5211:5212
Ident 5212:5216 text="bump"
LParen 5216:5217
RParen 5217:5218
Newline 5218:5219
Ident 5223:5224 text="c"
Dot 5224:5225
Ident 5225:5229 text="bump"
LParen 5229:5230
RParen 5230:5231
Newline 5231:5232
Return 5236:5242
Ident 5243:5244 text="c"
Dot 5244:5245
Ident 5245:5246 text="n"
Newline 5246:5247
RBrace 5247:5248
Newline 5248:5249
Newline 5249:5250
Fn 5250:5252
Ident 5253:5263 text="calls_boom"
LParen 5263:5264
Ident 5264:5265 text="c"
Colon 5265:5266
Ident 5267:5274 text="Counter"
RParen 5274:5275
Arrow 5276:5278
Ident 5279:5282 text="int"
LBrace 5283:5284
Newline 5284:5285
Ident 5289:5290 text="c"
Dot 5290:5291
Ident 5291:5295 text="boom"
LParen 5295:5296
RParen 5296:5297
Newline 5297:5298
Return 5302:5308
Number 5309:5310 text="0" suf="" isf=0 int=0
Newline 5310:5311
RBrace 5311:5312
Newline 5312:5313
Newline 5313:5314
Ident 5314:5318 text="test"
Fn 5319:5321
Ident 5322:5361 text="repeated_method_calls_keep_accumulating"
LParen 5361:5362
RParen 5362:5363
LBrace 5364:5365
Newline 5365:5366
Let 5370:5373
Ident 5374:5375 text="c"
Assign 5376:5377
Ident 5378:5385 text="Counter"
LParen 5385:5386
RParen 5386:5387
Newline 5387:5388
Ident 5392:5398 text="expect"
LParen 5398:5399
Ident 5399:5404 text="id_fn"
Lt 5404:5405
Ident 5405:5408 text="int"
Gt 5408:5409
LParen 5409:5410
Ident 5410:5426 text="calls_bump_twice"
LParen 5426:5427
Ident 5427:5428 text="c"
RParen 5428:5429
RParen 5429:5430
RParen 5430:5431
Dot 5431:5432
Ident 5432:5436 text="toBe"
LParen 5436:5437
Number 5437:5438 text="2" suf="" isf=0 int=2
RParen 5438:5439
Newline 5439:5440
RBrace 5440:5441
Newline 5441:5442
Newline 5442:5443
Ident 5443:5447 text="test"
Fn 5448:5450
Ident 5451:5490 text="a_method_throw_propagates_to_the_caller"
LParen 5490:5491
RParen 5491:5492
LBrace 5493:5494
Newline 5494:5495
Try 5499:5502
LBrace 5503:5504
Newline 5504:5505
Ident 5513:5523 text="calls_boom"
LParen 5523:5524
Ident 5524:5531 text="Counter"
LParen 5531:5532
RParen 5532:5533
RParen 5533:5534
Newline 5534:5535
Ident 5543:5549 text="expect"
LParen 5549:5550
Str 5550:5560 T("no throw")
RParen 5560:5561
Dot 5561:5562
Ident 5562:5566 text="toBe"
LParen 5566:5567
Str 5567:5580 T("unreachable")
RParen 5580:5581
Newline 5581:5582
RBrace 5586:5587
Catch 5588:5593
LParen 5594:5595
Ident 5595:5596 text="e"
RParen 5596:5597
LBrace 5598:5599
Newline 5599:5600
Ident 5608:5614 text="expect"
LParen 5614:5615
Ident 5615:5616 text="e"
RParen 5616:5617
Dot 5617:5618
Ident 5618:5622 text="toBe"
LParen 5622:5623
Str 5623:5636 T("method boom")
RParen 5636:5637
Newline 5637:5638
RBrace 5642:5643
Newline 5643:5644
RBrace 5644:5645
Newline 5645:5646
Eof 5646:5646
