Ident 0:4 text="test"
Fn 5:7
Ident 8:18 text="tuple_keys"
LParen 18:19
RParen 19:20
LBrace 21:22
Newline 22:23
Var 27:30
Ident 31:32 text="m"
Assign 33:34
LBrace 35:36
LParen 36:37
Number 37:38 text="1" suf="" isf=0 int=1
Comma 38:39
Number 40:41 text="2" suf="" isf=0 int=2
RParen 41:42
Colon 42:43
Str 44:50 T("pair")
RBrace 50:51
Newline 51:52
Ident 56:62 text="expect"
LParen 62:63
Ident 63:64 text="m"
LBracket 64:65
LParen 65:66
Number 66:67 text="1" suf="" isf=0 int=1
Comma 67:68
Number 69:70 text="2" suf="" isf=0 int=2
RParen 70:71
RBracket 71:72
RParen 72:73
Dot 73:74
Ident 74:78 text="toBe"
LParen 78:79
Str 79:85 T("pair")
RParen 85:86
Newline 86:87
Ident 91:97 text="expect"
LParen 97:98
Ident 98:99 text="m"
Dot 99:100
Ident 100:103 text="has"
LParen 103:104
LParen 104:105
Number 105:106 text="1" suf="" isf=0 int=1
Comma 106:107
Number 108:109 text="2" suf="" isf=0 int=2
RParen 109:110
RParen 110:111
RParen 111:112
Dot 112:113
Ident 113:117 text="toBe"
LParen 117:118
True 118:122
RParen 122:123
Newline 123:124
Ident 128:134 text="expect"
LParen 134:135
Ident 135:136 text="m"
Dot 136:137
Ident 137:140 text="has"
LParen 140:141
LParen 141:142
Number 142:143 text="1" suf="" isf=0 int=1
Comma 143:144
Number 145:146 text="3" suf="" isf=0 int=3
RParen 146:147
RParen 147:148
RParen 148:149
Dot 149:150
Ident 150:154 text="toBe"
LParen 154:155
False 155:160
RParen 160:161
Newline 161:162
Ident 166:172 text="expect"
LParen 172:173
Ident 173:174 text="m"
LBracket 174:175
LParen 175:176
Number 176:177 text="1" suf="" isf=0 int=1
Comma 177:178
Number 179:180 text="3" suf="" isf=0 int=3
RParen 180:181
RBracket 181:182
RParen 182:183
Dot 183:184
Ident 184:188 text="toBe"
LParen 188:189
Str 189:191
RParen 191:192
Newline 192:193
Ident 197:198 text="m"
LBracket 198:199
LParen 199:200
Number 200:201 text="3" suf="" isf=0 int=3
Comma 201:202
Number 203:204 text="4" suf="" isf=0 int=4
RParen 204:205
RBracket 205:206
Assign 207:208
Str 209:216 T("other")
Newline 216:217
Ident 221:227 text="expect"
LParen 227:228
Ident 228:229 text="m"
LBracket 229:230
LParen 230:231
Number 231:232 text="3" suf="" isf=0 int=3
Comma 232:233
Number 234:235 text="4" suf="" isf=0 int=4
RParen 235:236
RBracket 236:237
RParen 237:238
Dot 238:239
Ident 239:243 text="toBe"
LParen 243:244
Str 244:251 T("other")
RParen 251:252
Newline 252:253
Ident 257:263 text="expect"
LParen 263:264
Ident 264:267 text="len"
LParen 267:268
Ident 268:269 text="m"
RParen 269:270
RParen 270:271
Dot 271:272
Ident 272:276 text="toBe"
LParen 276:277
Number 277:278 text="2" suf="" isf=0 int=2
RParen 278:279
Newline 279:280
Ident 284:285 text="m"
LBracket 285:286
LParen 286:287
Number 287:288 text="1" suf="" isf=0 int=1
Comma 288:289
Number 290:291 text="2" suf="" isf=0 int=2
RParen 291:292
RBracket 292:293
Assign 294:295
Str 296:306 T("replaced")
Newline 306:307
Ident 311:317 text="expect"
LParen 317:318
Ident 318:319 text="m"
LBracket 319:320
LParen 320:321
Number 321:322 text="1" suf="" isf=0 int=1
Comma 322:323
Number 324:325 text="2" suf="" isf=0 int=2
RParen 325:326
RBracket 326:327
RParen 327:328
Dot 328:329
Ident 329:333 text="toBe"
LParen 333:334
Str 334:344 T("replaced")
RParen 344:345
Newline 345:346
Ident 350:356 text="expect"
LParen 356:357
Ident 357:360 text="len"
LParen 360:361
Ident 361:362 text="m"
RParen 362:363
RParen 363:364
Dot 364:365
Ident 365:369 text="toBe"
LParen 369:370
Number 370:371 text="2" suf="" isf=0 int=2
RParen 371:372
Newline 372:373
RBrace 373:374
Newline 374:375
Newline 375:376
Ident 376:380 text="test"
Fn 381:383
Ident 384:410 text="tuple_keys_order_sensitive"
LParen 410:411
RParen 411:412
LBrace 413:414
Newline 414:415
Var 419:422
Ident 423:424 text="m"
Assign 425:426
LBrace 427:428
LParen 428:429
Number 429:430 text="1" suf="" isf=0 int=1
Comma 430:431
Number 432:433 text="2" suf="" isf=0 int=2
RParen 433:434
Colon 434:435
Str 436:439 T("a")
Comma 439:440
LParen 441:442
Number 442:443 text="2" suf="" isf=0 int=2
Comma 443:444
Number 445:446 text="1" suf="" isf=0 int=1
RParen 446:447
Colon 447:448
Str 449:452 T("b")
RBrace 452:453
Newline 453:454
Ident 458:464 text="expect"
LParen 464:465
Ident 465:466 text="m"
LBracket 466:467
LParen 467:468
Number 468:469 text="1" suf="" isf=0 int=1
Comma 469:470
Number 471:472 text="2" suf="" isf=0 int=2
RParen 472:473
RBracket 473:474
RParen 474:475
Dot 475:476
Ident 476:480 text="toBe"
LParen 480:481
Str 481:484 T("a")
RParen 484:485
Newline 485:486
Ident 490:496 text="expect"
LParen 496:497
Ident 497:498 text="m"
LBracket 498:499
LParen 499:500
Number 500:501 text="2" suf="" isf=0 int=2
Comma 501:502
Number 503:504 text="1" suf="" isf=0 int=1
RParen 504:505
RBracket 505:506
RParen 506:507
Dot 507:508
Ident 508:512 text="toBe"
LParen 512:513
Str 513:516 T("b")
RParen 516:517
Newline 517:518
Ident 522:528 text="expect"
LParen 528:529
Ident 529:532 text="len"
LParen 532:533
Ident 533:534 text="m"
RParen 534:535
RParen 535:536
Dot 536:537
Ident 537:541 text="toBe"
LParen 541:542
Number 542:543 text="2" suf="" isf=0 int=2
RParen 543:544
Newline 544:545
RBrace 545:546
Newline 546:547
Newline 547:548
Ident 548:552 text="test"
Fn 553:555
Ident 556:583 text="mixed_string_int_tuple_keys"
LParen 583:584
RParen 584:585
LBrace 586:587
Newline 587:588
Var 592:595
Ident 596:597 text="m"
Assign 598:599
LBrace 600:601
LParen 601:602
Number 602:603 text="1" suf="" isf=0 int=1
Comma 603:604
Str 605:608 T("a")
RParen 608:609
Colon 609:610
Str 611:620 T("int-str")
RBrace 620:621
Newline 621:622
Ident 626:632 text="expect"
LParen 632:633
Ident 633:634 text="m"
LBracket 634:635
LParen 635:636
Number 636:637 text="1" suf="" isf=0 int=1
Comma 637:638
Str 639:642 T("a")
RParen 642:643
RBracket 643:644
RParen 644:645
Dot 645:646
Ident 646:650 text="toBe"
LParen 650:651
Str 651:660 T("int-str")
RParen 660:661
Newline 661:662
Ident 666:672 text="expect"
LParen 672:673
Ident 673:674 text="m"
Dot 674:675
Ident 675:678 text="has"
LParen 678:679
LParen 679:680
Number 680:681 text="1" suf="" isf=0 int=1
Comma 681:682
Str 683:686 T("b")
RParen 686:687
RParen 687:688
RParen 688:689
Dot 689:690
Ident 690:694 text="toBe"
LParen 694:695
False 695:700
RParen 700:701
Newline 701:702
Ident 706:712 text="expect"
LParen 712:713
Ident 713:714 text="m"
Dot 714:715
Ident 715:718 text="has"
LParen 718:719
LParen 719:720
Number 720:721 text="2" suf="" isf=0 int=2
Comma 721:722
Str 723:726 T("a")
RParen 726:727
RParen 727:728
RParen 728:729
Dot 729:730
Ident 730:734 text="toBe"
LParen 734:735
False 735:740
RParen 740:741
Newline 741:742
Ident 746:747 text="m"
LBracket 747:748
LParen 748:749
Number 749:750 text="2" suf="" isf=0 int=2
Comma 750:751
Str 752:755 T("b")
RParen 755:756
RBracket 756:757
Assign 758:759
Str 760:768 T("second")
Newline 768:769
Ident 773:779 text="expect"
LParen 779:780
Ident 780:783 text="len"
LParen 783:784
Ident 784:785 text="m"
RParen 785:786
RParen 786:787
Dot 787:788
Ident 788:792 text="toBe"
LParen 792:793
Number 793:794 text="2" suf="" isf=0 int=2
RParen 794:795
Newline 795:796
RBrace 796:797
Newline 797:798
Newline 798:799
Ident 799:803 text="test"
Fn 804:806
Ident 807:836 text="tuple_keys_structurally_equal"
LParen 836:837
RParen 837:838
LBrace 839:840
Newline 840:841
Let 845:848
Ident 849:850 text="a"
Assign 851:852
LParen 853:854
Number 854:855 text="5" suf="" isf=0 int=5
Comma 855:856
Number 857:858 text="6" suf="" isf=0 int=6
RParen 858:859
Newline 859:860
Let 864:867
Ident 868:869 text="b"
Assign 870:871
LParen 872:873
Number 873:874 text="5" suf="" isf=0 int=5
Comma 874:875
Number 876:877 text="6" suf="" isf=0 int=6
RParen 877:878
Newline 878:879
Var 883:886
Ident 887:888 text="m"
Assign 889:890
LBrace 891:892
Ident 892:893 text="a"
Colon 893:894
Str 895:898 T("v")
RBrace 898:899
Newline 899:900
Ident 904:910 text="expect"
LParen 910:911
Ident 911:912 text="m"
LBracket 912:913
Ident 913:914 text="b"
RBracket 914:915
RParen 915:916
Dot 916:917
Ident 917:921 text="toBe"
LParen 921:922
Str 922:925 T("v")
RParen 925:926
Newline 926:927
Ident 931:937 text="expect"
LParen 937:938
Ident 938:939 text="m"
LBracket 939:940
LParen 940:941
Number 941:942 text="5" suf="" isf=0 int=5
Comma 942:943
Number 944:945 text="6" suf="" isf=0 int=6
RParen 945:946
RBracket 946:947
RParen 947:948
Dot 948:949
Ident 949:953 text="toBe"
LParen 953:954
Str 954:957 T("v")
RParen 957:958
Newline 958:959
Ident 963:964 text="m"
LBracket 964:965
LParen 965:966
Number 966:967 text="7" suf="" isf=0 int=7
Comma 967:968
Number 969:970 text="8" suf="" isf=0 int=8
RParen 970:971
RBracket 971:972
Assign 973:974
Str 975:978 T("w")
Newline 978:979
Ident 983:989 text="expect"
LParen 989:990
Ident 990:993 text="len"
LParen 993:994
Ident 994:995 text="m"
RParen 995:996
RParen 996:997
Dot 997:998
Ident 998:1002 text="toBe"
LParen 1002:1003
Number 1003:1004 text="2" suf="" isf=0 int=2
RParen 1004:1005
Newline 1005:1006
RBrace 1006:1007
Newline 1007:1008
Newline 1008:1009
Ident 1009:1013 text="test"
Fn 1014:1016
Ident 1017:1032 text="tuple_keys_grow"
LParen 1032:1033
RParen 1033:1034
LBrace 1035:1036
Newline 1036:1037
Var 1041:1044
Ident 1045:1046 text="m"
Assign 1047:1048
LBrace 1049:1050
LParen 1050:1051
Number 1051:1052 text="0" suf="" isf=0 int=0
Comma 1052:1053
Number 1054:1055 text="0" suf="" isf=0 int=0
RParen 1055:1056
Colon 1056:1057
Str 1058:1064 T("seed")
RBrace 1064:1065
Newline 1065:1066
For 1070:1073
LParen 1074:1075
Ident 1075:1076 text="i"
In 1077:1079
Number 1080:1081 text="1" suf="" isf=0 int=1
Range 1081:1083
Number 1083:1086 text="100" suf="" isf=0 int=100
RParen 1086:1087
LBrace 1088:1089
Newline 1089:1090
Ident 1098:1099 text="m"
LBracket 1099:1100
LParen 1100:1101
Ident 1101:1102 text="i"
Comma 1102:1103
Ident 1104:1105 text="i"
RParen 1105:1106
RBracket 1106:1107
Assign 1108:1109
Str 1110:1115 E[Ident 1112:1113 text="i"; Eof 1114:1114]
Newline 1115:1116
RBrace 1120:1121
Newline 1121:1122
Ident 1126:1132 text="expect"
LParen 1132:1133
Ident 1133:1136 text="len"
LParen 1136:1137
Ident 1137:1138 text="m"
RParen 1138:1139
RParen 1139:1140
Dot 1140:1141
Ident 1141:1145 text="toBe"
LParen 1145:1146
Number 1146:1149 text="100" suf="" isf=0 int=100
RParen 1149:1150
Newline 1150:1151
Ident 1155:1161 text="expect"
LParen 1161:1162
Ident 1162:1163 text="m"
LBracket 1163:1164
LParen 1164:1165
Number 1165:1166 text="0" suf="" isf=0 int=0
Comma 1166:1167
Number 1168:1169 text="0" suf="" isf=0 int=0
RParen 1169:1170
RBracket 1170:1171
RParen 1171:1172
Dot 1172:1173
Ident 1173:1177 text="toBe"
LParen 1177:1178
Str 1178:1184 T("seed")
RParen 1184:1185
Newline 1185:1186
Ident 1190:1196 text="expect"
LParen 1196:1197
Ident 1197:1198 text="m"
LBracket 1198:1199
LParen 1199:1200
Number 1200:1202 text="75" suf="" isf=0 int=75
Comma 1202:1203
Number 1204:1206 text="75" suf="" isf=0 int=75
RParen 1206:1207
RBracket 1207:1208
RParen 1208:1209
Dot 1209:1210
Ident 1210:1214 text="toBe"
LParen 1214:1215
Str 1215:1219 T("75")
RParen 1219:1220
Newline 1220:1221
Var 1225:1228
Ident 1229:1230 text="n"
Assign 1231:1232
Number 1233:1234 text="0" suf="" isf=0 int=0
Newline 1234:1235
For 1239:1242
LParen 1243:1244
LParen 1244:1245
Ident 1245:1246 text="k"
Comma 1246:1247
Ident 1248:1249 text="v"
RParen 1249:1250
In 1251:1253
Ident 1254:1255 text="m"
RParen 1255:1256
LBrace 1257:1258
Newline 1258:1259
If 1267:1269
LParen 1270:1271
Ident 1271:1272 text="m"
LBracket 1272:1273
Ident 1273:1274 text="k"
RBracket 1274:1275
EqEq 1276:1278
Ident 1279:1280 text="v"
RParen 1280:1281
LBrace 1282:1283
Newline 1283:1284
Ident 1296:1297 text="n"
PlusEq 1298:1300
Number 1301:1302 text="1" suf="" isf=0 int=1
Newline 1302:1303
RBrace 1311:1312
Newline 1312:1313
RBrace 1317:1318
Newline 1318:1319
Ident 1323:1329 text="expect"
LParen 1329:1330
Ident 1330:1331 text="n"
RParen 1331:1332
Dot 1332:1333
Ident 1333:1337 text="toBe"
LParen 1337:1338
Number 1338:1341 text="100" suf="" isf=0 int=100
RParen 1341:1342
Newline 1342:1343
RBrace 1343:1344
Newline 1344:1345
Newline 1345:1346
Ident 1346:1350 text="test"
Fn 1351:1353
Ident 1354:1370 text="tuple_key_remove"
LParen 1370:1371
RParen 1371:1372
LBrace 1373:1374
Newline 1374:1375
Var 1379:1382
Ident 1383:1384 text="m"
Assign 1385:1386
LBrace 1387:1388
LParen 1388:1389
Number 1389:1390 text="1" suf="" isf=0 int=1
Comma 1390:1391
Number 1392:1393 text="2" suf="" isf=0 int=2
RParen 1393:1394
Colon 1394:1395
Str 1396:1401 T("one")
Comma 1401:1402
LParen 1403:1404
Number 1404:1405 text="3" suf="" isf=0 int=3
Comma 1405:1406
Number 1407:1408 text="4" suf="" isf=0 int=4
RParen 1408:1409
Colon 1409:1410
Str 1411:1416 T("two")
RBrace 1416:1417
Newline 1417:1418
If 1422:1424
LParen 1425:1426
Let 1426:1429
Ident 1430:1434 text="some"
LParen 1434:1435
Ident 1435:1436 text="r"
RParen 1436:1437
Assign 1438:1439
Ident 1440:1441 text="m"
Dot 1441:1442
Ident 1442:1448 text="remove"
LParen 1448:1449
LParen 1449:1450
Number 1450:1451 text="1" suf="" isf=0 int=1
Comma 1451:1452
Number 1453:1454 text="2" suf="" isf=0 int=2
RParen 1454:1455
RParen 1455:1456
RParen 1456:1457
LBrace 1458:1459
Newline 1459:1460
Ident 1468:1474 text="expect"
LParen 1474:1475
Ident 1475:1476 text="r"
RParen 1476:1477
Dot 1477:1478
Ident 1478:1482 text="toBe"
LParen 1482:1483
Str 1483:1488 T("one")
RParen 1488:1489
Newline 1489:1490
RBrace 1494:1495
Else 1496:1500
LBrace 1501:1502
Newline 1502:1503
Ident 1511:1517 text="expect"
LParen 1517:1518
Str 1518:1530 T("unexpected")
RParen 1530:1531
Dot 1531:1532
Ident 1532:1536 text="toBe"
LParen 1536:1537
Str 1537:1595 T("tuple_key_remove: remove returned none for a present key")
RParen 1595:1596
Newline 1596:1597
RBrace 1601:1602
Newline 1602:1603
Ident 1607:1613 text="expect"
LParen 1613:1614
Ident 1614:1615 text="m"
Dot 1615:1616
Ident 1616:1619 text="has"
LParen 1619:1620
LParen 1620:1621
Number 1621:1622 text="1" suf="" isf=0 int=1
Comma 1622:1623
Number 1624:1625 text="2" suf="" isf=0 int=2
RParen 1625:1626
RParen 1626:1627
RParen 1627:1628
Dot 1628:1629
Ident 1629:1633 text="toBe"
LParen 1633:1634
False 1634:1639
RParen 1639:1640
Newline 1640:1641
Ident 1645:1651 text="expect"
LParen 1651:1652
Ident 1652:1653 text="m"
Dot 1653:1654
Ident 1654:1657 text="has"
LParen 1657:1658
LParen 1658:1659
Number 1659:1660 text="3" suf="" isf=0 int=3
Comma 1660:1661
Number 1662:1663 text="4" suf="" isf=0 int=4
RParen 1663:1664
RParen 1664:1665
RParen 1665:1666
Dot 1666:1667
Ident 1667:1671 text="toBe"
LParen 1671:1672
True 1672:1676
RParen 1676:1677
Newline 1677:1678
Ident 1682:1688 text="expect"
LParen 1688:1689
Ident 1689:1692 text="len"
LParen 1692:1693
Ident 1693:1694 text="m"
RParen 1694:1695
RParen 1695:1696
Dot 1696:1697
Ident 1697:1701 text="toBe"
LParen 1701:1702
Number 1702:1703 text="1" suf="" isf=0 int=1
RParen 1703:1704
Newline 1704:1705
Ident 1709:1715 text="expect"
LParen 1715:1716
Ident 1716:1717 text="m"
Dot 1717:1718
Ident 1718:1724 text="remove"
LParen 1724:1725
LParen 1725:1726
Number 1726:1727 text="9" suf="" isf=0 int=9
Comma 1727:1728
Number 1729:1730 text="9" suf="" isf=0 int=9
RParen 1730:1731
RParen 1731:1732
RParen 1732:1733
Dot 1733:1734
Ident 1734:1738 text="toBe"
LParen 1738:1739
None 1739:1743
RParen 1743:1744
Newline 1744:1745
RBrace 1745:1746
Newline 1746:1747
Newline 1747:1748
Ident 1748:1752 text="test"
Fn 1753:1755
Ident 1756:1791 text="tuple_and_list_keys_are_independent"
LParen 1791:1792
RParen 1792:1793
LBrace 1794:1795
Newline 1795:1796
Var 1800:1803
Ident 1804:1806 text="mt"
Colon 1806:1807
Ident 1808:1811 text="Map"
Lt 1811:1812
LParen 1812:1813
Ident 1813:1816 text="int"
Comma 1816:1817
Ident 1818:1821 text="int"
RParen 1821:1822
Comma 1822:1823
Ident 1824:1830 text="string"
Gt 1830:1831
Assign 1832:1833
LBrace 1834:1835
LParen 1835:1836
Number 1836:1837 text="1" suf="" isf=0 int=1
Comma 1837:1838
Number 1839:1840 text="2" suf="" isf=0 int=2
RParen 1840:1841
Colon 1841:1842
Str 1843:1850 T("tuple")
RBrace 1850:1851
Newline 1851:1852
Var 1856:1859
Ident 1860:1862 text="ml"
Colon 1862:1863
Ident 1864:1867 text="Map"
Lt 1867:1868
Ident 1868:1872 text="List"
Lt 1872:1873
Ident 1873:1876 text="int"
Gt 1876:1877
Comma 1877:1878
Ident 1879:1885 text="string"
Gt 1885:1886
Assign 1887:1888
LBrace 1889:1890
LBracket 1890:1891
Number 1891:1892 text="1" suf="" isf=0 int=1
Comma 1892:1893
Number 1894:1895 text="2" suf="" isf=0 int=2
RBracket 1895:1896
Colon 1896:1897
Str 1898:1904 T("list")
RBrace 1904:1905
Newline 1905:1906
Ident 1910:1916 text="expect"
LParen 1916:1917
Ident 1917:1919 text="mt"
LBracket 1919:1920
LParen 1920:1921
Number 1921:1922 text="1" suf="" isf=0 int=1
Comma 1922:1923
Number 1924:1925 text="2" suf="" isf=0 int=2
RParen 1925:1926
RBracket 1926:1927
RParen 1927:1928
Dot 1928:1929
Ident 1929:1933 text="toBe"
LParen 1933:1934
Str 1934:1941 T("tuple")
RParen 1941:1942
Newline 1942:1943
Ident 1947:1953 text="expect"
LParen 1953:1954
Ident 1954:1956 text="ml"
LBracket 1956:1957
LBracket 1957:1958
Number 1958:1959 text="1" suf="" isf=0 int=1
Comma 1959:1960
Number 1961:1962 text="2" suf="" isf=0 int=2
RBracket 1962:1963
RBracket 1963:1964
RParen 1964:1965
Dot 1965:1966
Ident 1966:1970 text="toBe"
LParen 1970:1971
Str 1971:1977 T("list")
RParen 1977:1978
Newline 1978:1979
Ident 1983:1989 text="expect"
LParen 1989:1990
Ident 1990:1992 text="mt"
LBracket 1992:1993
LParen 1993:1994
Number 1994:1995 text="9" suf="" isf=0 int=9
Comma 1995:1996
Number 1997:1998 text="9" suf="" isf=0 int=9
RParen 1998:1999
RBracket 1999:2000
RParen 2000:2001
Dot 2001:2002
Ident 2002:2006 text="toBe"
LParen 2006:2007
Str 2007:2009
RParen 2009:2010
Newline 2010:2011
Ident 2015:2021 text="expect"
LParen 2021:2022
Ident 2022:2024 text="ml"
LBracket 2024:2025
LBracket 2025:2026
Number 2026:2027 text="9" suf="" isf=0 int=9
Comma 2027:2028
Number 2029:2030 text="9" suf="" isf=0 int=9
RBracket 2030:2031
RBracket 2031:2032
RParen 2032:2033
Dot 2033:2034
Ident 2034:2038 text="toBe"
LParen 2038:2039
Str 2039:2041
RParen 2041:2042
Newline 2042:2043
Ident 2047:2053 text="expect"
LParen 2053:2054
Ident 2054:2056 text="mt"
Dot 2056:2057
Ident 2057:2060 text="has"
LParen 2060:2061
LParen 2061:2062
Number 2062:2063 text="1" suf="" isf=0 int=1
Comma 2063:2064
Number 2065:2066 text="2" suf="" isf=0 int=2
RParen 2066:2067
RParen 2067:2068
RParen 2068:2069
Dot 2069:2070
Ident 2070:2074 text="toBe"
LParen 2074:2075
True 2075:2079
RParen 2079:2080
Newline 2080:2081
Ident 2085:2091 text="expect"
LParen 2091:2092
Ident 2092:2094 text="ml"
Dot 2094:2095
Ident 2095:2098 text="has"
LParen 2098:2099
LBracket 2099:2100
Number 2100:2101 text="1" suf="" isf=0 int=1
Comma 2101:2102
Number 2103:2104 text="2" suf="" isf=0 int=2
RBracket 2104:2105
RParen 2105:2106
RParen 2106:2107
Dot 2107:2108
Ident 2108:2112 text="toBe"
LParen 2112:2113
True 2113:2117
RParen 2117:2118
Newline 2118:2119
Ident 2123:2129 text="expect"
LParen 2129:2130
Ident 2130:2133 text="len"
LParen 2133:2134
Ident 2134:2136 text="mt"
RParen 2136:2137
RParen 2137:2138
Dot 2138:2139
Ident 2139:2143 text="toBe"
LParen 2143:2144
Number 2144:2145 text="1" suf="" isf=0 int=1
RParen 2145:2146
Newline 2146:2147
Ident 2151:2157 text="expect"
LParen 2157:2158
Ident 2158:2161 text="len"
LParen 2161:2162
Ident 2162:2164 text="ml"
RParen 2164:2165
RParen 2165:2166
Dot 2166:2167
Ident 2167:2171 text="toBe"
LParen 2171:2172
Number 2172:2173 text="1" suf="" isf=0 int=1
RParen 2173:2174
Newline 2174:2175
RBrace 2175:2176
Newline 2176:2177
Newline 2177:2178
Ident 2178:2182 text="test"
Fn 2183:2185
Ident 2186:2197 text="option_keys"
LParen 2197:2198
RParen 2198:2199
LBrace 2200:2201
Newline 2201:2202
Var 2206:2209
Ident 2210:2211 text="m"
Colon 2211:2212
Ident 2213:2216 text="Map"
Lt 2216:2217
Ident 2217:2220 text="int"
Question 2220:2221
Comma 2221:2222
Ident 2223:2229 text="string"
Gt 2229:2230
Assign 2231:2232
LBrace 2233:2234
Number 2234:2235 text="1" suf="" isf=0 int=1
Colon 2235:2236
Str 2237:2242 T("one")
RBrace 2242:2243
Newline 2243:2244
Ident 2248:2254 text="expect"
LParen 2254:2255
Ident 2255:2256 text="m"
LBracket 2256:2257
Number 2257:2258 text="1" suf="" isf=0 int=1
RBracket 2258:2259
RParen 2259:2260
Dot 2260:2261
Ident 2261:2265 text="toBe"
LParen 2265:2266
Str 2266:2271 T("one")
RParen 2271:2272
Newline 2272:2273
Ident 2277:2283 text="expect"
LParen 2283:2284
Ident 2284:2285 text="m"
Dot 2285:2286
Ident 2286:2289 text="has"
LParen 2289:2290
Number 2290:2291 text="1" suf="" isf=0 int=1
RParen 2291:2292
RParen 2292:2293
Dot 2293:2294
Ident 2294:2298 text="toBe"
LParen 2298:2299
True 2299:2303
RParen 2303:2304
Newline 2304:2305
Ident 2309:2315 text="expect"
LParen 2315:2316
Ident 2316:2317 text="m"
Dot 2317:2318
Ident 2318:2321 text="has"
LParen 2321:2322
Number 2322:2323 text="2" suf="" isf=0 int=2
RParen 2323:2324
RParen 2324:2325
Dot 2325:2326
Ident 2326:2330 text="toBe"
LParen 2330:2331
False 2331:2336
RParen 2336:2337
Newline 2337:2338
Ident 2342:2343 text="m"
LBracket 2343:2344
Number 2344:2345 text="2" suf="" isf=0 int=2
RBracket 2345:2346
Assign 2347:2348
Str 2349:2354 T("two")
Newline 2354:2355
Ident 2359:2365 text="expect"
LParen 2365:2366
Ident 2366:2367 text="m"
LBracket 2367:2368
Number 2368:2369 text="2" suf="" isf=0 int=2
RBracket 2369:2370
RParen 2370:2371
Dot 2371:2372
Ident 2372:2376 text="toBe"
LParen 2376:2377
Str 2377:2382 T("two")
RParen 2382:2383
Newline 2383:2384
Ident 2388:2389 text="m"
LBracket 2389:2390
Number 2390:2391 text="1" suf="" isf=0 int=1
RBracket 2391:2392
Assign 2393:2394
Str 2395:2400 T("uno")
Newline 2400:2401
Ident 2405:2411 text="expect"
LParen 2411:2412
Ident 2412:2413 text="m"
LBracket 2413:2414
Number 2414:2415 text="1" suf="" isf=0 int=1
RBracket 2415:2416
RParen 2416:2417
Dot 2417:2418
Ident 2418:2422 text="toBe"
LParen 2422:2423
Str 2423:2428 T("uno")
RParen 2428:2429
Newline 2429:2430
Ident 2434:2440 text="expect"
LParen 2440:2441
Ident 2441:2444 text="len"
LParen 2444:2445
Ident 2445:2446 text="m"
RParen 2446:2447
RParen 2447:2448
Dot 2448:2449
Ident 2449:2453 text="toBe"
LParen 2453:2454
Number 2454:2455 text="2" suf="" isf=0 int=2
RParen 2455:2456
Newline 2456:2457
RBrace 2457:2458
Newline 2458:2459
Newline 2459:2460
Ident 2460:2464 text="test"
Fn 2465:2467
Ident 2468:2483 text="option_none_key"
LParen 2483:2484
RParen 2484:2485
LBrace 2486:2487
Newline 2487:2488
Var 2492:2495
Ident 2496:2497 text="m"
Colon 2497:2498
Ident 2499:2502 text="Map"
Lt 2502:2503
Ident 2503:2509 text="string"
Question 2509:2510
Comma 2510:2511
Ident 2512:2515 text="int"
Gt 2515:2516
Assign 2517:2518
LBrace 2519:2520
Str 2520:2523 T("a")
Colon 2523:2524
Number 2525:2526 text="1" suf="" isf=0 int=1
RBrace 2526:2527
Newline 2527:2528
Ident 2532:2533 text="m"
LBracket 2533:2534
None 2534:2538
RBracket 2538:2539
Assign 2540:2541
Number 2542:2543 text="0" suf="" isf=0 int=0
Newline 2543:2544
Ident 2548:2554 text="expect"
LParen 2554:2555
Ident 2555:2556 text="m"
LBracket 2556:2557
None 2557:2561
RBracket 2561:2562
RParen 2562:2563
Dot 2563:2564
Ident 2564:2568 text="toBe"
LParen 2568:2569
Number 2569:2570 text="0" suf="" isf=0 int=0
RParen 2570:2571
Newline 2571:2572
Ident 2576:2582 text="expect"
LParen 2582:2583
Ident 2583:2584 text="m"
Dot 2584:2585
Ident 2585:2588 text="has"
LParen 2588:2589
None 2589:2593
RParen 2593:2594
RParen 2594:2595
Dot 2595:2596
Ident 2596:2600 text="toBe"
LParen 2600:2601
True 2601:2605
RParen 2605:2606
Newline 2606:2607
Ident 2611:2617 text="expect"
LParen 2617:2618
Ident 2618:2619 text="m"
LBracket 2619:2620
Str 2620:2623 T("a")
RBracket 2623:2624
RParen 2624:2625
Dot 2625:2626
Ident 2626:2630 text="toBe"
LParen 2630:2631
Number 2631:2632 text="1" suf="" isf=0 int=1
RParen 2632:2633
Newline 2633:2634
Ident 2638:2644 text="expect"
LParen 2644:2645
Ident 2645:2648 text="len"
LParen 2648:2649
Ident 2649:2650 text="m"
RParen 2650:2651
RParen 2651:2652
Dot 2652:2653
Ident 2653:2657 text="toBe"
LParen 2657:2658
Number 2658:2659 text="2" suf="" isf=0 int=2
RParen 2659:2660
Newline 2660:2661
Ident 2665:2666 text="m"
LBracket 2666:2667
None 2667:2671
RBracket 2671:2672
Assign 2673:2674
Minus 2675:2676
Number 2676:2677 text="1" suf="" isf=0 int=1
Newline 2677:2678
Ident 2682:2688 text="expect"
LParen 2688:2689
Ident 2689:2690 text="m"
LBracket 2690:2691
None 2691:2695
RBracket 2695:2696
RParen 2696:2697
Dot 2697:2698
Ident 2698:2702 text="toBe"
LParen 2702:2703
Minus 2703:2704
Number 2704:2705 text="1" suf="" isf=0 int=1
RParen 2705:2706
Newline 2706:2707
Ident 2711:2717 text="expect"
LParen 2717:2718
Ident 2718:2721 text="len"
LParen 2721:2722
Ident 2722:2723 text="m"
RParen 2723:2724
RParen 2724:2725
Dot 2725:2726
Ident 2726:2730 text="toBe"
LParen 2730:2731
Number 2731:2732 text="2" suf="" isf=0 int=2
RParen 2732:2733
Newline 2733:2734
RBrace 2734:2735
Newline 2735:2736
Newline 2736:2737
Ident 2737:2741 text="test"
Fn 2742:2744
Ident 2745:2764 text="option_keys_iterate"
LParen 2764:2765
RParen 2765:2766
LBrace 2767:2768
Newline 2768:2769
Var 2773:2776
Ident 2777:2778 text="m"
Colon 2778:2779
Ident 2780:2783 text="Map"
Lt 2783:2784
Ident 2784:2787 text="int"
Question 2787:2788
Comma 2788:2789
Ident 2790:2796 text="string"
Gt 2796:2797
Assign 2798:2799
LBrace 2800:2801
Number 2801:2802 text="1" suf="" isf=0 int=1
Colon 2802:2803
Str 2804:2809 T("one")
Comma 2809:2810
Number 2811:2812 text="2" suf="" isf=0 int=2
Colon 2812:2813
Str 2814:2819 T("two")
RBrace 2819:2820
Newline 2820:2821
Ident 2825:2826 text="m"
LBracket 2826:2827
None 2827:2831
RBracket 2831:2832
Assign 2833:2834
Str 2835:2845 T("none-key")
Newline 2845:2846
Var 2850:2853
Ident 2854:2855 text="n"
Assign 2856:2857
Number 2858:2859 text="0" suf="" isf=0 int=0
Newline 2859:2860
Var 2864:2867
Ident 2868:2871 text="sum"
Assign 2872:2873
Number 2874:2875 text="0" suf="" isf=0 int=0
Newline 2875:2876
Var 2880:2883
Ident 2884:2893 text="none_keys"
Assign 2894:2895
Number 2896:2897 text="0" suf="" isf=0 int=0
Newline 2897:2898
For 2902:2905
LParen 2906:2907
LParen 2907:2908
Ident 2908:2909 text="k"
Comma 2909:2910
Ident 2911:2912 text="v"
RParen 2912:2913
In 2914:2916
Ident 2917:2918 text="m"
RParen 2918:2919
LBrace 2920:2921
Newline 2921:2922
Ident 2930:2931 text="n"
PlusEq 2932:2934
Number 2935:2936 text="1" suf="" isf=0 int=1
Newline 2936:2937
If 2945:2947
LParen 2948:2949
Let 2949:2952
Ident 2953:2957 text="some"
LParen 2957:2958
Ident 2958:2959 text="x"
RParen 2959:2960
Assign 2961:2962
Ident 2963:2964 text="k"
RParen 2964:2965
LBrace 2966:2967
Newline 2967:2968
Ident 2980:2983 text="sum"
PlusEq 2984:2986
Ident 2987:2988 text="x"
Newline 2988:2989
RBrace 2997:2998
Else 2999:3003
LBrace 3004:3005
Newline 3005:3006
Ident 3018:3027 text="none_keys"
PlusEq 3028:3030
Number 3031:3032 text="1" suf="" isf=0 int=1
Newline 3032:3033
RBrace 3041:3042
Newline 3042:3043
Ident 3051:3057 text="expect"
LParen 3057:3058
Ident 3058:3059 text="v"
RParen 3059:3060
Dot 3060:3061
Ident 3061:3065 text="toBe"
LParen 3065:3066
Ident 3066:3067 text="m"
LBracket 3067:3068
Ident 3068:3069 text="k"
RBracket 3069:3070
RParen 3070:3071
Newline 3071:3072
RBrace 3076:3077
Newline 3077:3078
Ident 3082:3088 text="expect"
LParen 3088:3089
Ident 3089:3090 text="n"
RParen 3090:3091
Dot 3091:3092
Ident 3092:3096 text="toBe"
LParen 3096:3097
Number 3097:3098 text="3" suf="" isf=0 int=3
RParen 3098:3099
Newline 3099:3100
Ident 3104:3110 text="expect"
LParen 3110:3111
Ident 3111:3120 text="none_keys"
RParen 3120:3121
Dot 3121:3122
Ident 3122:3126 text="toBe"
LParen 3126:3127
Number 3127:3128 text="1" suf="" isf=0 int=1
RParen 3128:3129
Newline 3129:3130
RBrace 3130:3131
Newline 3131:3132
Newline 3132:3133
Ident 3133:3137 text="test"
Fn 3138:3140
Ident 3141:3154 text="option_remove"
LParen 3154:3155
RParen 3155:3156
LBrace 3157:3158
Newline 3158:3159
Var 3163:3166
Ident 3167:3168 text="m"
Colon 3168:3169
Ident 3170:3173 text="Map"
Lt 3173:3174
Ident 3174:3177 text="int"
Question 3177:3178
Comma 3178:3179
Ident 3180:3186 text="string"
Gt 3186:3187
Assign 3188:3189
LBrace 3190:3191
Number 3191:3192 text="1" suf="" isf=0 int=1
Colon 3192:3193
Str 3194:3199 T("one")
RBrace 3199:3200
Newline 3200:3201
Ident 3205:3206 text="m"
LBracket 3206:3207
None 3207:3211
RBracket 3211:3212
Assign 3213:3214
Str 3215:3221 T("nada")
Newline 3221:3222
If 3226:3228
LParen 3229:3230
Let 3230:3233
Ident 3234:3238 text="some"
LParen 3238:3239
Ident 3239:3240 text="r"
RParen 3240:3241
Assign 3242:3243
Ident 3244:3245 text="m"
Dot 3245:3246
Ident 3246:3252 text="remove"
LParen 3252:3253
None 3253:3257
RParen 3257:3258
RParen 3258:3259
LBrace 3260:3261
Newline 3261:3262
Ident 3270:3276 text="expect"
LParen 3276:3277
Ident 3277:3278 text="r"
RParen 3278:3279
Dot 3279:3280
Ident 3280:3284 text="toBe"
LParen 3284:3285
Str 3285:3291 T("nada")
RParen 3291:3292
Newline 3292:3293
RBrace 3297:3298
Else 3299:3303
LBrace 3304:3305
Newline 3305:3306
Ident 3314:3320 text="expect"
LParen 3320:3321
Str 3321:3333 T("unexpected")
RParen 3333:3334
Dot 3334:3335
Ident 3335:3339 text="toBe"
LParen 3339:3340
Str 3340:3395 T("option_remove: remove returned none for a present key")
RParen 3395:3396
Newline 3396:3397
RBrace 3401:3402
Newline 3402:3403
Ident 3407:3413 text="expect"
LParen 3413:3414
Ident 3414:3415 text="m"
Dot 3415:3416
Ident 3416:3419 text="has"
LParen 3419:3420
None 3420:3424
RParen 3424:3425
RParen 3425:3426
Dot 3426:3427
Ident 3427:3431 text="toBe"
LParen 3431:3432
False 3432:3437
RParen 3437:3438
Newline 3438:3439
Ident 3443:3449 text="expect"
LParen 3449:3450
Ident 3450:3451 text="m"
Dot 3451:3452
Ident 3452:3455 text="has"
LParen 3455:3456
Number 3456:3457 text="1" suf="" isf=0 int=1
RParen 3457:3458
RParen 3458:3459
Dot 3459:3460
Ident 3460:3464 text="toBe"
LParen 3464:3465
True 3465:3469
RParen 3469:3470
Newline 3470:3471
Ident 3475:3481 text="expect"
LParen 3481:3482
Ident 3482:3485 text="len"
LParen 3485:3486
Ident 3486:3487 text="m"
RParen 3487:3488
RParen 3488:3489
Dot 3489:3490
Ident 3490:3494 text="toBe"
LParen 3494:3495
Number 3495:3496 text="1" suf="" isf=0 int=1
RParen 3496:3497
Newline 3497:3498
RBrace 3498:3499
Newline 3499:3500
Newline 3500:3501
Ident 3501:3505 text="test"
Fn 3506:3508
Ident 3509:3548 text="option_key_none_vs_present_are_distinct"
LParen 3548:3549
RParen 3549:3550
LBrace 3551:3552
Newline 3552:3553
Var 3557:3560
Ident 3561:3562 text="m"
Colon 3562:3563
Ident 3564:3567 text="Map"
Lt 3567:3568
Ident 3568:3571 text="int"
Question 3571:3572
Comma 3572:3573
Ident 3574:3580 text="string"
Gt 3580:3581
Assign 3582:3583
LBrace 3584:3585
Number 3585:3586 text="1" suf="" isf=0 int=1
Colon 3586:3587
Str 3588:3593 T("one")
RBrace 3593:3594
Newline 3594:3595
Ident 3599:3605 text="expect"
LParen 3605:3606
Ident 3606:3607 text="m"
Dot 3607:3608
Ident 3608:3611 text="has"
LParen 3611:3612
Number 3612:3613 text="1" suf="" isf=0 int=1
RParen 3613:3614
RParen 3614:3615
Dot 3615:3616
Ident 3616:3620 text="toBe"
LParen 3620:3621
True 3621:3625
RParen 3625:3626
Newline 3626:3627
Ident 3631:3637 text="expect"
LParen 3637:3638
Ident 3638:3639 text="m"
Dot 3639:3640
Ident 3640:3643 text="has"
LParen 3643:3644
Number 3644:3645 text="2" suf="" isf=0 int=2
RParen 3645:3646
RParen 3646:3647
Dot 3647:3648
Ident 3648:3652 text="toBe"
LParen 3652:3653
False 3653:3658
RParen 3658:3659
Newline 3659:3660
Ident 3664:3665 text="m"
LBracket 3665:3666
None 3666:3670
RBracket 3670:3671
Assign 3672:3673
Str 3674:3683 T("nothing")
Newline 3683:3684
Ident 3688:3694 text="expect"
LParen 3694:3695
Ident 3695:3696 text="m"
Dot 3696:3697
Ident 3697:3700 text="has"
LParen 3700:3701
None 3701:3705
RParen 3705:3706
RParen 3706:3707
Dot 3707:3708
Ident 3708:3712 text="toBe"
LParen 3712:3713
True 3713:3717
RParen 3717:3718
Newline 3718:3719
Ident 3723:3729 text="expect"
LParen 3729:3730
Ident 3730:3731 text="m"
Dot 3731:3732
Ident 3732:3735 text="has"
LParen 3735:3736
Number 3736:3737 text="1" suf="" isf=0 int=1
RParen 3737:3738
RParen 3738:3739
Dot 3739:3740
Ident 3740:3744 text="toBe"
LParen 3744:3745
True 3745:3749
RParen 3749:3750
Newline 3750:3751
Ident 3755:3761 text="expect"
LParen 3761:3762
Ident 3762:3765 text="len"
LParen 3765:3766
Ident 3766:3767 text="m"
RParen 3767:3768
RParen 3768:3769
Dot 3769:3770
Ident 3770:3774 text="toBe"
LParen 3774:3775
Number 3775:3776 text="2" suf="" isf=0 int=2
RParen 3776:3777
Newline 3777:3778
RBrace 3778:3779
Eof 3779:3779
