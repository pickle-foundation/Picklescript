Newline 65:66
Newline 68:69
Newline 142:143
Newline 221:222
Newline 300:301
Newline 379:380
Newline 440:441
Newline 443:444
Newline 516:517
Newline 592:593
Newline 650:651
Newline 653:654
Newline 732:733
Newline 781:782
Newline 782:783
Fn 783:785
Ident 786:790 text="main"
LParen 790:791
RParen 791:792
LBrace 793:794
Newline 794:795
Newline 873:874
Let 878:881
Ident 882:883 text="s"
Assign 884:885
Ident 886:893 text="sem_new"
LParen 893:894
Number 894:895 text="2" suf="" isf=0 int=2
RParen 895:896
Newline 896:897
Newline 897:898
Newline 951:952
Ident 956:962 text="expect"
LParen 962:963
Ident 963:978 text="sem_try_acquire"
LParen 978:979
Ident 979:980 text="s"
Comma 980:981
Number 982:983 text="1" suf="" isf=0 int=1
RParen 983:984
RParen 984:985
Dot 985:986
Ident 986:990 text="toBe"
LParen 990:991
True 991:995
RParen 995:996
Newline 996:997
Ident 1001:1007 text="expect"
LParen 1007:1008
Ident 1008:1023 text="sem_try_acquire"
LParen 1023:1024
Ident 1024:1025 text="s"
Comma 1025:1026
Number 1027:1028 text="1" suf="" isf=0 int=1
RParen 1028:1029
RParen 1029:1030
Dot 1030:1031
Ident 1031:1035 text="toBe"
LParen 1035:1036
True 1036:1040
RParen 1040:1041
Newline 1041:1042
Newline 1042:1043
Newline 1118:1119
Ident 1123:1129 text="expect"
LParen 1129:1130
Ident 1130:1145 text="sem_try_acquire"
LParen 1145:1146
Ident 1146:1147 text="s"
Comma 1147:1148
Number 1149:1150 text="1" suf="" isf=0 int=1
RParen 1150:1151
RParen 1151:1152
Dot 1152:1153
Ident 1153:1157 text="toBe"
LParen 1157:1158
False 1158:1163
RParen 1163:1164
Newline 1164:1165
Ident 1169:1175 text="expect"
LParen 1175:1176
Ident 1176:1191 text="sem_try_acquire"
LParen 1191:1192
Ident 1192:1193 text="s"
Comma 1193:1194
Number 1195:1196 text="2" suf="" isf=0 int=2
RParen 1196:1197
RParen 1197:1198
Dot 1198:1199
Ident 1199:1203 text="toBe"
LParen 1203:1204
False 1204:1209
RParen 1209:1210
Newline 1210:1211
Newline 1211:1212
Newline 1269:1270
Ident 1274:1285 text="sem_release"
LParen 1285:1286
Ident 1286:1287 text="s"
Comma 1287:1288
Number 1289:1290 text="1" suf="" isf=0 int=1
RParen 1290:1291
Newline 1291:1292
Ident 1296:1302 text="expect"
LParen 1302:1303
Ident 1303:1318 text="sem_try_acquire"
LParen 1318:1319
Ident 1319:1320 text="s"
Comma 1320:1321
Number 1322:1323 text="1" suf="" isf=0 int=1
RParen 1323:1324
RParen 1324:1325
Dot 1325:1326
Ident 1326:1330 text="toBe"
LParen 1330:1331
True 1331:1335
RParen 1335:1336
Newline 1336:1337
Ident 1341:1347 text="expect"
LParen 1347:1348
Ident 1348:1363 text="sem_try_acquire"
LParen 1363:1364
Ident 1364:1365 text="s"
Comma 1365:1366
Number 1367:1368 text="1" suf="" isf=0 int=1
RParen 1368:1369
RParen 1369:1370
Dot 1370:1371
Ident 1371:1375 text="toBe"
LParen 1375:1376
False 1376:1381
RParen 1381:1382
Newline 1382:1383
Newline 1383:1384
Newline 1463:1464
Newline 1524:1525
Ident 1529:1540 text="sem_release"
LParen 1540:1541
Ident 1541:1542 text="s"
Comma 1542:1543
Number 1544:1545 text="2" suf="" isf=0 int=2
RParen 1545:1546
Newline 1546:1547
Ident 1551:1562 text="sem_acquire"
LParen 1562:1563
Ident 1563:1564 text="s"
Comma 1564:1565
Number 1566:1567 text="2" suf="" isf=0 int=2
RParen 1567:1568
Newline 1568:1569
Ident 1573:1579 text="expect"
LParen 1579:1580
Ident 1580:1595 text="sem_try_acquire"
LParen 1595:1596
Ident 1596:1597 text="s"
Comma 1597:1598
Number 1599:1600 text="1" suf="" isf=0 int=1
RParen 1600:1601
RParen 1601:1602
Dot 1602:1603
Ident 1603:1607 text="toBe"
LParen 1607:1608
False 1608:1613
RParen 1613:1614
Newline 1614:1615
Newline 1615:1616
Newline 1688:1689
Newline 1725:1726
Ident 1730:1741 text="sem_release"
LParen 1741:1742
Ident 1742:1743 text="s"
Comma 1743:1744
Number 1745:1746 text="5" suf="" isf=0 int=5
RParen 1746:1747
Newline 1747:1748
Ident 1752:1758 text="expect"
LParen 1758:1759
Ident 1759:1774 text="sem_try_acquire"
LParen 1774:1775
Ident 1775:1776 text="s"
Comma 1776:1777
Number 1778:1779 text="5" suf="" isf=0 int=5
RParen 1779:1780
RParen 1780:1781
Dot 1781:1782
Ident 1782:1786 text="toBe"
LParen 1786:1787
True 1787:1791
RParen 1791:1792
Newline 1792:1793
Ident 1797:1803 text="expect"
LParen 1803:1804
Ident 1804:1819 text="sem_try_acquire"
LParen 1819:1820
Ident 1820:1821 text="s"
Comma 1821:1822
Number 1823:1824 text="1" suf="" isf=0 int=1
RParen 1824:1825
RParen 1825:1826
Dot 1826:1827
Ident 1827:1831 text="toBe"
LParen 1831:1832
False 1832:1837
RParen 1837:1838
Newline 1838:1839
Newline 1839:1840
Newline 1917:1918
Let 1922:1925
Ident 1926:1927 text="c"
Assign 1928:1929
Ident 1930:1938 text="cond_new"
LParen 1938:1939
RParen 1939:1940
Newline 1940:1941
Newline 1941:1942
Newline 1996:1997
Ident 2001:2012 text="cond_signal"
LParen 2012:2013
Ident 2013:2014 text="c"
RParen 2014:2015
Newline 2015:2016
Ident 2020:2029 text="cond_wait"
LParen 2029:2030
Ident 2030:2031 text="c"
Comma 2031:2032
Number 2033:2034 text="0" suf="" isf=0 int=0
RParen 2034:2035
Newline 2035:2036
Newline 2036:2037
Newline 2114:2115
Newline 2190:2191
Newline 2268:2269
Newline 2312:2313
Ident 2317:2331 text="cond_broadcast"
LParen 2331:2332
Ident 2332:2333 text="c"
RParen 2333:2334
Newline 2334:2335
Newline 2335:2336
Newline 2403:2404
Ident 2408:2419 text="cond_signal"
LParen 2419:2420
Ident 2420:2421 text="c"
RParen 2421:2422
Newline 2422:2423
Ident 2427:2436 text="cond_wait"
LParen 2436:2437
Ident 2437:2438 text="c"
Comma 2438:2439
Number 2440:2441 text="0" suf="" isf=0 int=0
RParen 2441:2442
Newline 2442:2443
Newline 2443:2444
Newline 2520:2521
Let 2525:2528
Ident 2529:2530 text="d"
Assign 2531:2532
Ident 2533:2541 text="cond_new"
LParen 2541:2542
RParen 2542:2543
Newline 2543:2544
Ident 2548:2559 text="cond_signal"
LParen 2559:2560
Ident 2560:2561 text="d"
RParen 2561:2562
Newline 2562:2563
Ident 2567:2576 text="cond_wait"
LParen 2576:2577
Ident 2577:2578 text="d"
Comma 2578:2579
Number 2580:2581 text="0" suf="" isf=0 int=0
RParen 2581:2582
Newline 2582:2583
Newline 2583:2584
Newline 2661:2662
Newline 2737:2738
Newline 2812:2813
Newline 2853:2854
Let 2858:2861
Ident 2862:2863 text="m"
Assign 2864:2865
Ident 2866:2875 text="mutex_new"
LParen 2875:2876
RParen 2876:2877
Newline 2877:2878
Ident 2882:2893 text="cond_signal"
LParen 2893:2894
Ident 2894:2895 text="c"
RParen 2895:2896
Newline 2896:2897
Ident 2901:2910 text="cond_wait"
LParen 2910:2911
Ident 2911:2912 text="c"
Comma 2912:2913
Ident 2914:2915 text="m"
RParen 2915:2916
Newline 2916:2917
Ident 2921:2927 text="expect"
LParen 2927:2928
Ident 2928:2941 text="mutex_trylock"
LParen 2941:2942
Ident 2942:2943 text="m"
RParen 2943:2944
RParen 2944:2945
Dot 2945:2946
Ident 2946:2950 text="toBe"
LParen 2950:2951
False 2951:2956
RParen 2956:2957
Newline 2957:2958
Ident 2962:2974 text="mutex_unlock"
LParen 2974:2975
Ident 2975:2976 text="m"
RParen 2976:2977
Newline 2977:2978
Ident 2982:2988 text="expect"
LParen 2988:2989
Ident 2989:3002 text="mutex_trylock"
LParen 3002:3003
Ident 3003:3004 text="m"
RParen 3004:3005
RParen 3005:3006
Dot 3006:3007
Ident 3007:3011 text="toBe"
LParen 3011:3012
True 3012:3016
RParen 3016:3017
Newline 3017:3018
Ident 3022:3034 text="mutex_unlock"
LParen 3034:3035
Ident 3035:3036 text="m"
RParen 3036:3037
Newline 3037:3038
Newline 3038:3039
Ident 3043:3050 text="println"
LParen 3050:3051
Str 3051:3064 T("sem_cond ok")
RParen 3064:3065
Newline 3065:3066
RBrace 3066:3067
Newline 3067:3068
Eof 3068:3068
