Module 0:6
Ident 7:23 text="abi_console_main"
Newline 23:24
Newline 24:25
Newline 93:94
Newline 177:178
Newline 205:206
Newline 208:209
Newline 281:282
Newline 359:360
Newline 441:442
Newline 515:516
Newline 518:519
Newline 601:602
Newline 680:681
Newline 732:733
Newline 735:736
Newline 816:817
Newline 897:898
Newline 953:954
Newline 1034:1035
Newline 1090:1091
Newline 1170:1171
Newline 1248:1249
Newline 1328:1329
Newline 1370:1371
Newline 1452:1453
Newline 1535:1536
Newline 1598:1599
Newline 1601:1602
Newline 1682:1683
Newline 1759:1760
Newline 1835:1836
Newline 1917:1918
Newline 1965:1966
Newline 1966:1967
Fn 1967:1969
Ident 1970:1977 text="showI64"
LParen 1977:1978
Ident 1978:1979 text="v"
Colon 1979:1980
Ident 1981:1984 text="int"
RParen 1984:1985
LBrace 1986:1987
Newline 1987:1988
Ident 1992:1997 text="print"
LParen 1997:1998
Ident 1998:1999 text="v"
RParen 1999:2000
Newline 2000:2001
Ident 2005:2012 text="println"
LParen 2012:2013
Str 2013:2015
RParen 2015:2016
Newline 2016:2017
RBrace 2017:2018
Newline 2018:2019
Newline 2019:2020
Fn 2020:2022
Ident 2023:2031 text="showByte"
LParen 2031:2032
Ident 2032:2033 text="v"
Colon 2033:2034
Ident 2035:2038 text="int"
RParen 2038:2039
LBrace 2040:2041
Newline 2041:2042
Ident 2046:2051 text="print"
LParen 2051:2052
Ident 2052:2053 text="v"
As 2054:2056
Ident 2057:2061 text="byte"
RParen 2061:2062
Newline 2062:2063
Ident 2067:2074 text="println"
LParen 2074:2075
Str 2075:2077
RParen 2077:2078
Newline 2078:2079
RBrace 2079:2080
Newline 2080:2081
Newline 2081:2082
Fn 2082:2084
Ident 2085:2093 text="showChar"
LParen 2093:2094
Ident 2094:2095 text="v"
Colon 2095:2096
Ident 2097:2100 text="int"
RParen 2100:2101
LBrace 2102:2103
Newline 2103:2104
Ident 2108:2113 text="print"
LParen 2113:2114
Ident 2114:2115 text="v"
As 2116:2118
Ident 2119:2123 text="char"
RParen 2123:2124
Newline 2124:2125
Ident 2129:2136 text="println"
LParen 2136:2137
Str 2137:2139
RParen 2139:2140
Newline 2140:2141
RBrace 2141:2142
Newline 2142:2143
Newline 2143:2144
Fn 2144:2146
Ident 2147:2151 text="main"
LParen 2151:2152
RParen 2152:2153
LBrace 2154:2155
Newline 2155:2156
Ident 2160:2167 text="println"
LParen 2167:2168
Str 2168:2185 T("== print_i64 ==")
RParen 2185:2186
Newline 2186:2187
Ident 2191:2198 text="showI64"
LParen 2198:2199
Number 2199:2200 text="0" suf="" isf=0 int=0
RParen 2200:2201
Newline 2201:2202
Ident 2206:2213 text="showI64"
LParen 2213:2214
Number 2214:2215 text="1" suf="" isf=0 int=1
RParen 2215:2216
Newline 2216:2217
Ident 2221:2228 text="showI64"
LParen 2228:2229
Minus 2229:2230
Number 2230:2231 text="1" suf="" isf=0 int=1
RParen 2231:2232
Newline 2232:2233
Ident 2237:2244 text="showI64"
LParen 2244:2245
Number 2245:2264 text="9223372036854775807" suf="" isf=0 int=9223372036854775807
RParen 2264:2265
Newline 2265:2266
Ident 2270:2277 text="showI64"
LParen 2277:2278
Number 2278:2279 text="0" suf="" isf=0 int=0
Minus 2280:2281
Number 2282:2301 text="9223372036854775807" suf="" isf=0 int=9223372036854775807
RParen 2301:2302
Newline 2302:2303
Newline 2381:2382
Newline 2414:2415
Ident 2419:2426 text="showI64"
LParen 2426:2427
Number 2427:2428 text="0" suf="" isf=0 int=0
Minus 2429:2430
Number 2431:2450 text="9223372036854775807" suf="" isf=0 int=9223372036854775807
Minus 2451:2452
Number 2453:2454 text="1" suf="" isf=0 int=1
RParen 2454:2455
Newline 2455:2456
Ident 2460:2467 text="showI64"
LParen 2467:2468
Number 2468:2487 text="1234567890123456789" suf="" isf=0 int=1234567890123456789
RParen 2487:2488
Newline 2488:2489
Ident 2493:2500 text="showI64"
LParen 2500:2501
Number 2501:2502 text="0" suf="" isf=0 int=0
Minus 2503:2504
Number 2505:2524 text="1234567890123456789" suf="" isf=0 int=1234567890123456789
RParen 2524:2525
Newline 2525:2526
Newline 2526:2527
Ident 2531:2538 text="println"
LParen 2538:2539
Str 2539:2568 T("== print_i64 digit edges ==")
RParen 2568:2569
Newline 2569:2570
Var 2574:2577
Ident 2578:2579 text="v"
Assign 2580:2581
Number 2582:2583 text="9" suf="" isf=0 int=9
Newline 2583:2584
Var 2588:2591
Ident 2592:2593 text="i"
Assign 2594:2595
Number 2596:2597 text="0" suf="" isf=0 int=0
Newline 2597:2598
While 2602:2607
LParen 2608:2609
Ident 2609:2610 text="i"
Lt 2611:2612
Number 2613:2615 text="20" suf="" isf=0 int=20
RParen 2615:2616
LBrace 2617:2618
Newline 2618:2619
Ident 2627:2634 text="showI64"
LParen 2634:2635
Ident 2635:2636 text="v"
RParen 2636:2637
Newline 2637:2638
Ident 2646:2647 text="v"
Assign 2648:2649
Ident 2650:2651 text="v"
Star 2652:2653
Number 2654:2656 text="10" suf="" isf=0 int=10
Newline 2656:2657
Ident 2665:2666 text="i"
Assign 2667:2668
Ident 2669:2670 text="i"
Plus 2671:2672
Number 2673:2674 text="1" suf="" isf=0 int=1
Newline 2674:2675
RBrace 2679:2680
Newline 2680:2681
Newline 2760:2761
Newline 2810:2811
Ident 2815:2822 text="showI64"
LParen 2822:2823
Number 2823:2824 text="0" suf="" isf=0 int=0
Minus 2825:2826
Number 2827:2845 text="999999999999999999" suf="" isf=0 int=999999999999999999
RParen 2845:2846
Newline 2846:2847
Ident 2851:2858 text="showI64"
LParen 2858:2859
Number 2859:2878 text="1000000000000000000" suf="" isf=0 int=1000000000000000000
RParen 2878:2879
Newline 2879:2880
Newline 2880:2881
Ident 2885:2892 text="println"
LParen 2892:2893
Str 2893:2911 T("== print_bool ==")
RParen 2911:2912
Newline 2912:2913
Ident 2917:2922 text="print"
LParen 2922:2923
True 2923:2927
RParen 2927:2928
Newline 2928:2929
Ident 2933:2940 text="println"
LParen 2940:2941
Str 2941:2943
RParen 2943:2944
Newline 2944:2945
Ident 2949:2954 text="print"
LParen 2954:2955
False 2955:2960
RParen 2960:2961
Newline 2961:2962
Ident 2966:2973 text="println"
LParen 2973:2974
Str 2974:2976
RParen 2976:2977
Newline 2977:2978
Newline 2978:2979
Ident 2983:2990 text="println"
LParen 2990:2991
Str 2991:3040 T("== print_byte truncates to u8 and writes raw ==")
RParen 3040:3041
Newline 3041:3042
Ident 3046:3054 text="showByte"
LParen 3054:3055
Number 3055:3056 text="0" suf="" isf=0 int=0
RParen 3056:3057
Newline 3057:3058
Ident 3062:3070 text="showByte"
LParen 3070:3071
Number 3071:3073 text="65" suf="" isf=0 int=65
RParen 3073:3074
Newline 3074:3075
Ident 3079:3087 text="showByte"
LParen 3087:3088
Number 3088:3091 text="255" suf="" isf=0 int=255
RParen 3091:3092
Newline 3092:3093
Newline 3127:3128
Ident 3132:3140 text="showByte"
LParen 3140:3141
Number 3141:3144 text="300" suf="" isf=0 int=300
RParen 3144:3145
Newline 3145:3146
Ident 3150:3158 text="showByte"
LParen 3158:3159
Number 3159:3160 text="0" suf="" isf=0 int=0
Minus 3161:3162
Number 3163:3164 text="1" suf="" isf=0 int=1
RParen 3164:3165
Newline 3165:3166
Ident 3170:3178 text="showByte"
LParen 3178:3179
Number 3179:3182 text="511" suf="" isf=0 int=511
RParen 3182:3183
Newline 3183:3184
Newline 3261:3262
Newline 3313:3314
Ident 3318:3326 text="showByte"
LParen 3326:3327
Number 3327:3330 text="195" suf="" isf=0 int=195
RParen 3330:3331
Newline 3331:3332
Ident 3336:3344 text="showByte"
LParen 3344:3345
Number 3345:3348 text="169" suf="" isf=0 int=169
RParen 3348:3349
Newline 3349:3350
Ident 3354:3362 text="showByte"
LParen 3362:3363
Number 3363:3365 text="10" suf="" isf=0 int=10
RParen 3365:3366
Newline 3366:3367
Newline 3367:3368
Ident 3372:3379 text="println"
LParen 3379:3380
Str 3380:3414 T("== print_char lowers to UTF-8 ==")
RParen 3414:3415
Newline 3415:3416
Ident 3420:3428 text="showChar"
LParen 3428:3429
Number 3429:3431 text="65" suf="" isf=0 int=65
RParen 3431:3432
Newline 3432:3433
Ident 3437:3445 text="showChar"
LParen 3445:3446
Number 3446:3447 text="0" suf="" isf=0 int=0
RParen 3447:3448
Newline 3448:3449
Ident 3453:3461 text="showChar"
LParen 3461:3462
Number 3462:3465 text="127" suf="" isf=0 int=127
RParen 3465:3466
Newline 3466:3467
Ident 3471:3479 text="showChar"
LParen 3479:3480
Number 3480:3483 text="128" suf="" isf=0 int=128
RParen 3483:3484
Newline 3484:3485
Ident 3489:3497 text="showChar"
LParen 3497:3498
Number 3498:3502 text="0xe9" suf="" isf=0 int=233
RParen 3502:3503
Newline 3503:3504
Ident 3508:3516 text="showChar"
LParen 3516:3517
Number 3517:3523 text="0x20ac" suf="" isf=0 int=8364
RParen 3523:3524
Newline 3524:3525
Ident 3529:3537 text="showChar"
LParen 3537:3538
Number 3538:3545 text="0x1F600" suf="" isf=0 int=128512
RParen 3545:3546
Newline 3546:3547
Newline 3579:3580
Ident 3584:3592 text="showChar"
LParen 3592:3593
Number 3593:3600 text="1114112" suf="" isf=0 int=1114112
RParen 3600:3601
Newline 3601:3602
Newline 3634:3635
Ident 3639:3647 text="showChar"
LParen 3647:3648
Number 3648:3653 text="55296" suf="" isf=0 int=55296
RParen 3653:3654
Newline 3654:3655
Ident 3659:3667 text="showChar"
LParen 3667:3668
Number 3668:3673 text="57343" suf="" isf=0 int=57343
RParen 3673:3674
Newline 3674:3675
Newline 3723:3724
Ident 3728:3736 text="showChar"
LParen 3736:3737
Number 3737:3738 text="0" suf="" isf=0 int=0
Minus 3739:3740
Number 3741:3742 text="1" suf="" isf=0 int=1
RParen 3742:3743
Newline 3743:3744
Ident 3748:3756 text="showChar"
LParen 3756:3757
Number 3757:3758 text="0" suf="" isf=0 int=0
Minus 3759:3760
Number 3761:3763 text="65" suf="" isf=0 int=65
RParen 3763:3764
Newline 3764:3765
Newline 3765:3766
Ident 3770:3777 text="println"
LParen 3777:3778
Str 3778:3811 T("== print and println compose ==")
RParen 3811:3812
Newline 3812:3813
Ident 3817:3822 text="print"
LParen 3822:3823
Number 3823:3824 text="1" suf="" isf=0 int=1
RParen 3824:3825
Newline 3825:3826
Ident 3830:3835 text="print"
LParen 3835:3836
Number 3836:3837 text="2" suf="" isf=0 int=2
RParen 3837:3838
Newline 3838:3839
Ident 3843:3848 text="print"
LParen 3848:3849
Number 3849:3850 text="3" suf="" isf=0 int=3
RParen 3850:3851
Newline 3851:3852
Ident 3856:3863 text="println"
LParen 3863:3864
Str 3864:3866
RParen 3866:3867
Newline 3867:3868
Ident 3872:3879 text="println"
LParen 3879:3880
Str 3880:3882
RParen 3882:3883
Newline 3883:3884
Newline 3884:3885
Ident 3889:3896 text="println"
LParen 3896:3897
Str 3897:3953 T("== values inside containers route through print_obj ==")
RParen 3953:3954
Newline 3954:3955
Newline 4036:4037
Newline 4112:4113
Var 4117:4120
Ident 4121:4123 text="xs"
Colon 4123:4124
Ident 4125:4129 text="List"
Lt 4129:4130
Ident 4130:4133 text="int"
Gt 4133:4134
Assign 4135:4136
LBracket 4137:4138
Number 4138:4139 text="1" suf="" isf=0 int=1
Comma 4139:4140
Number 4141:4142 text="2" suf="" isf=0 int=2
Comma 4142:4143
Number 4144:4145 text="3" suf="" isf=0 int=3
RBracket 4145:4146
Newline 4146:4147
Ident 4151:4156 text="print"
LParen 4156:4157
Ident 4157:4159 text="xs"
RParen 4159:4160
Newline 4160:4161
Ident 4165:4172 text="println"
LParen 4172:4173
Str 4173:4175
RParen 4175:4176
Newline 4176:4177
Newline 4259:4260
Newline 4315:4316
Var 4320:4323
Ident 4324:4332 text="boxedInt"
Colon 4332:4333
Ident 4334:4337 text="int"
Assign 4338:4339
Minus 4340:4341
Number 4341:4343 text="42" suf="" isf=0 int=42
Newline 4343:4344
Var 4348:4351
Ident 4352:4360 text="boxedMax"
Colon 4360:4361
Ident 4362:4365 text="int"
Assign 4366:4367
Number 4368:4387 text="9223372036854775807" suf="" isf=0 int=9223372036854775807
Newline 4387:4388
Var 4392:4395
Ident 4396:4405 text="boxedBool"
Colon 4405:4406
Ident 4407:4411 text="bool"
Assign 4412:4413
True 4414:4418
Newline 4418:4419
Var 4423:4426
Ident 4427:4436 text="boxedChar"
Colon 4436:4437
Ident 4438:4442 text="char"
Assign 4443:4444
Char 4445:4448 ch='q' int=113
Newline 4448:4449
Var 4453:4456
Ident 4457:4466 text="boxedWide"
Colon 4466:4467
Ident 4468:4472 text="char"
Assign 4473:4474
LParen 4475:4476
Number 4476:4483 text="0x1F600" suf="" isf=0 int=128512
RParen 4483:4484
As 4485:4487
Ident 4488:4492 text="char"
Newline 4492:4493
Ident 4497:4501 text="show"
LParen 4501:4502
Ident 4502:4510 text="boxedInt"
RParen 4510:4511
Newline 4511:4512
Ident 4516:4520 text="show"
LParen 4520:4521
Ident 4521:4529 text="boxedMax"
RParen 4529:4530
Newline 4530:4531
Ident 4535:4539 text="show"
LParen 4539:4540
Ident 4540:4549 text="boxedBool"
RParen 4549:4550
Newline 4550:4551
Ident 4555:4559 text="show"
LParen 4559:4560
Ident 4560:4569 text="boxedChar"
RParen 4569:4570
Newline 4570:4571
Ident 4575:4579 text="show"
LParen 4579:4580
Ident 4580:4589 text="boxedWide"
RParen 4589:4590
Newline 4590:4591
RBrace 4591:4592
Newline 4592:4593
Newline 4593:4594
Newline 4674:4675
Newline 4739:4740
Fn 4740:4742 doc="A generic parameter has no static rep, so the argument is boxed; that is the\nonly way to reach the BOX_* arms of `print_obj` from source."
Ident 4743:4747 text="show"
Lt 4747:4748
Ident 4748:4749 text="T"
Gt 4749:4750
LParen 4750:4751
Ident 4751:4752 text="x"
Colon 4752:4753
Ident 4754:4755 text="T"
RParen 4755:4756
LBrace 4757:4758
Newline 4758:4759
Ident 4763:4768 text="print"
LParen 4768:4769
Ident 4769:4770 text="x"
RParen 4770:4771
Newline 4771:4772
Ident 4776:4783 text="println"
LParen 4783:4784
Str 4784:4786
RParen 4786:4787
Newline 4787:4788
RBrace 4788:4789
Eof 4789:4789
