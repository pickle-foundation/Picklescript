Newline 74:75
Newline 151:152
Newline 229:230
Newline 297:298
Newline 374:375
Newline 427:428
Newline 430:431
Newline 506:507
Newline 586:587
Newline 666:667
Newline 718:719
Newline 721:722
Newline 800:801
Newline 879:880
Newline 956:957
Newline 1000:1001
Newline 1001:1002
Import 1002:1008
LBrace 1009:1010
Ident 1011:1034 text="abiGcAllocationsSinceGc"
Comma 1034:1035
Ident 1036:1053 text="abiGcBytesSinceGc"
Comma 1053:1054
Ident 1055:1075 text="abiGcCollectionCount"
Comma 1075:1076
Ident 1077:1089 text="abiGcCollect"
RBrace 1090:1091
From 1092:1096
Ident 1097:1104 text="runtime"
Dot 1104:1105
Ident 1105:1111 text="abi_gc"
Newline 1111:1112
Import 1112:1118
LBrace 1119:1120
Ident 1121:1128 text="listNew"
Comma 1128:1129
Ident 1130:1141 text="abiListPush"
RBrace 1142:1143
From 1144:1148
Ident 1149:1156 text="runtime"
Dot 1156:1157
Ident 1157:1165 text="abi_list"
Newline 1165:1166
Import 1166:1172
LBrace 1173:1174
Ident 1175:1184 text="abiBoxI64"
RBrace 1185:1186
From 1187:1191
Ident 1192:1199 text="runtime"
Dot 1199:1200
Ident 1200:1207 text="abi_box"
Newline 1207:1208
Newline 1208:1209
Fn 1209:1211
Ident 1212:1216 text="main"
LParen 1216:1217
RParen 1217:1218
LBrace 1219:1220
Newline 1220:1221
Newline 1297:1298
Newline 1354:1355
Var 1359:1362
Ident 1363:1365 text="a0"
Assign 1366:1367
Ident 1368:1391 text="abiGcAllocationsSinceGc"
LParen 1391:1392
RParen 1392:1393
Newline 1393:1394
Var 1398:1401
Ident 1402:1404 text="b0"
Assign 1405:1406
Ident 1407:1424 text="abiGcBytesSinceGc"
LParen 1424:1425
RParen 1425:1426
Newline 1426:1427
Var 1431:1434
Ident 1435:1438 text="all"
Assign 1439:1440
Ident 1441:1448 text="listNew"
LParen 1448:1449
Number 1449:1450 text="0" suf="" isf=0 int=0
RParen 1450:1451
Newline 1451:1452
Ident 1456:1467 text="abiListPush"
LParen 1467:1468
Ident 1468:1471 text="all"
Comma 1471:1472
Ident 1473:1482 text="abiBoxI64"
LParen 1482:1483
Number 1483:1485 text="42" suf="" isf=0 int=42
RParen 1485:1486
RParen 1486:1487
Newline 1487:1488
Ident 1492:1503 text="abiListPush"
LParen 1503:1504
Ident 1504:1507 text="all"
Comma 1507:1508
Ident 1509:1518 text="abiBoxI64"
LParen 1518:1519
Number 1519:1521 text="43" suf="" isf=0 int=43
RParen 1521:1522
RParen 1522:1523
Newline 1523:1524
Var 1528:1531
Ident 1532:1534 text="a1"
Assign 1535:1536
Ident 1537:1560 text="abiGcAllocationsSinceGc"
LParen 1560:1561
RParen 1561:1562
Newline 1562:1563
Var 1567:1570
Ident 1571:1573 text="b1"
Assign 1574:1575
Ident 1576:1593 text="abiGcBytesSinceGc"
LParen 1593:1594
RParen 1594:1595
Newline 1595:1596
Var 1600:1603
Ident 1604:1606 text="da"
Assign 1607:1608
Ident 1609:1611 text="a1"
Minus 1612:1613
Ident 1614:1616 text="a0"
Newline 1616:1617
Var 1621:1624
Ident 1625:1627 text="db"
Assign 1628:1629
Ident 1630:1632 text="b1"
Minus 1633:1634
Ident 1635:1637 text="b0"
Newline 1637:1638
Ident 1642:1649 text="println"
LParen 1649:1650
Str 1650:1667 T("allocated: ") E[Ident 1663:1665 text="da"; Eof 1666:1666]
RParen 1667:1668
Newline 1668:1669
Ident 1673:1680 text="println"
LParen 1680:1681
Str 1681:1694 T("bytes: ") E[Ident 1690:1692 text="db"; Eof 1693:1693]
RParen 1694:1695
Newline 1695:1696
Newline 1696:1697
Newline 1774:1775
Newline 1832:1833
Var 1837:1840
Ident 1841:1843 text="c0"
Assign 1844:1845
Ident 1846:1866 text="abiGcCollectionCount"
LParen 1866:1867
RParen 1867:1868
Newline 1868:1869
Ident 1873:1885 text="abiGcCollect"
LParen 1885:1886
True 1886:1890
RParen 1890:1891
Newline 1891:1892
Var 1896:1899
Ident 1900:1902 text="dc"
Assign 1903:1904
Ident 1905:1925 text="abiGcCollectionCount"
LParen 1925:1926
RParen 1926:1927
Minus 1928:1929
Ident 1930:1932 text="c0"
Newline 1932:1933
Var 1937:1940
Ident 1941:1943 text="pa"
Assign 1944:1945
Ident 1946:1969 text="abiGcAllocationsSinceGc"
LParen 1969:1970
RParen 1970:1971
Newline 1971:1972
Var 1976:1979
Ident 1980:1982 text="pb"
Assign 1983:1984
Ident 1985:2002 text="abiGcBytesSinceGc"
LParen 2002:2003
RParen 2003:2004
Newline 2004:2005
Ident 2009:2016 text="println"
LParen 2016:2017
Str 2017:2034 T("collected: ") E[Ident 2030:2032 text="dc"; Eof 2033:2033]
RParen 2034:2035
Newline 2035:2036
Ident 2040:2047 text="println"
LParen 2047:2048
Str 2048:2075 T("alloc after collect: ") E[Ident 2071:2073 text="pa"; Eof 2074:2074]
RParen 2075:2076
Newline 2076:2077
Ident 2081:2088 text="println"
LParen 2088:2089
Str 2089:2116 T("bytes after collect: ") E[Ident 2112:2114 text="pb"; Eof 2115:2115]
RParen 2116:2117
Newline 2117:2118
Newline 2118:2119
Newline 2187:2188
Var 2192:2195
Ident 2196:2201 text="fresh"
Assign 2202:2203
Ident 2204:2211 text="listNew"
LParen 2211:2212
Number 2212:2213 text="0" suf="" isf=0 int=0
RParen 2213:2214
Newline 2214:2215
Ident 2219:2230 text="abiListPush"
LParen 2230:2231
Ident 2231:2236 text="fresh"
Comma 2236:2237
Ident 2238:2247 text="abiBoxI64"
LParen 2247:2248
Number 2248:2249 text="7" suf="" isf=0 int=7
RParen 2249:2250
RParen 2250:2251
Newline 2251:2252
Var 2256:2259
Ident 2260:2262 text="fa"
Assign 2263:2264
Ident 2265:2288 text="abiGcAllocationsSinceGc"
LParen 2288:2289
RParen 2289:2290
Newline 2290:2291
Var 2295:2298
Ident 2299:2301 text="fb"
Assign 2302:2303
Ident 2304:2321 text="abiGcBytesSinceGc"
LParen 2321:2322
RParen 2322:2323
Newline 2323:2324
Ident 2328:2335 text="println"
LParen 2335:2336
Str 2336:2359 T("alloc count now: ") E[Ident 2355:2357 text="fa"; Eof 2358:2358]
RParen 2359:2360
Newline 2360:2361
Ident 2365:2372 text="println"
LParen 2372:2373
Str 2373:2395 T("byte count now: ") E[Ident 2391:2393 text="fb"; Eof 2394:2394]
RParen 2395:2396
Newline 2396:2397
Ident 2401:2408 text="println"
LParen 2408:2409
Str 2409:2421 T("gc seam ok")
RParen 2421:2422
Newline 2422:2423
RBrace 2423:2424
Eof 2424:2424
