Module 0:6
Ident 7:19 text="abi_map_main"
Newline 19:20
Newline 20:21
Newline 84:85
Newline 87:88
Newline 178:179
Newline 269:270
Newline 356:357
Newline 433:434
Newline 436:437
Newline 527:528
Newline 616:617
Newline 705:706
Newline 797:798
Newline 887:888
Newline 977:978
Newline 1037:1038
Newline 1038:1039
Import 1039:1045
LBrace 1046:1047
Ident 1048:1057 text="abiMapNew"
Comma 1057:1058
Ident 1059:1068 text="abiMapSet"
Comma 1068:1069
Ident 1070:1079 text="abiMapGet"
Comma 1079:1080
Ident 1081:1095 text="abiMapGetBoxed"
Comma 1095:1096
Ident 1097:1106 text="abiMapHas"
Comma 1106:1107
Ident 1108:1120 text="abiMapRemove"
Comma 1120:1121
Ident 1122:1131 text="abiMapLen"
Comma 1131:1132
Ident 1133:1143 text="abiMapKeys"
Comma 1143:1144
Ident 1145:1157 text="abiMapValues"
RBrace 1158:1159
From 1160:1164
Ident 1165:1172 text="runtime"
Dot 1172:1173
Ident 1173:1180 text="abi_map"
Newline 1180:1181
Import 1181:1187
LBrace 1188:1189
Ident 1190:1199 text="abiBoxI64"
Comma 1199:1200
Ident 1201:1212 text="abiUnboxI64"
Comma 1212:1213
Ident 1214:1224 text="abiBoxBool"
Comma 1224:1225
Ident 1226:1238 text="abiUnboxBool"
RBrace 1239:1240
From 1241:1245
Ident 1246:1253 text="runtime"
Dot 1253:1254
Ident 1254:1261 text="abi_box"
Newline 1261:1262
Import 1262:1268
LBrace 1269:1270
Ident 1271:1281 text="abiListLen"
Comma 1281:1282
Ident 1283:1293 text="abiListGet"
RBrace 1294:1295
From 1296:1300
Ident 1301:1308 text="runtime"
Dot 1308:1309
Ident 1309:1317 text="abi_list"
Newline 1317:1318
Import 1318:1324
LBrace 1325:1326
Ident 1327:1333 text="newStr"
Comma 1333:1334
Ident 1335:1343 text="byteInto"
Comma 1343:1344
Ident 1345:1358 text="abiStrFromI64"
RBrace 1359:1360
From 1361:1365
Ident 1366:1373 text="runtime"
Dot 1373:1374
Ident 1374:1384 text="abi_string"
Newline 1384:1385
Newline 1385:1386
Fn 1386:1388
Ident 1389:1395 text="isNull"
LParen 1395:1396
Ident 1396:1397 text="p"
Colon 1397:1398
Star 1399:1400
Ident 1400:1403 text="int"
RParen 1403:1404
Arrow 1405:1407
Ident 1408:1412 text="bool"
LBrace 1413:1414
Newline 1414:1415
Return 1419:1425
LParen 1426:1427
Ident 1427:1428 text="p"
As 1429:1431
Ident 1432:1435 text="int"
RParen 1435:1436
EqEq 1437:1439
Number 1440:1441 text="0" suf="" isf=0 int=0
Newline 1441:1442
RBrace 1442:1443
Newline 1443:1444
Newline 1444:1445
Newline 1533:1534
Newline 1592:1593
Fn 1593:1595 doc="A five-byte string built one byte at a time, so the table stores a pointer to a real\nstring object rather than reusing one global constant."
Ident 1596:1603 text="mkAlpha"
LParen 1603:1604
RParen 1604:1605
Arrow 1606:1608
Star 1609:1610
Ident 1610:1613 text="int"
LBrace 1614:1615
Newline 1615:1616
Var 1620:1623
Ident 1624:1625 text="s"
Assign 1626:1627
Ident 1628:1634 text="newStr"
LParen 1634:1635
Number 1635:1636 text="5" suf="" isf=0 int=5
RParen 1636:1637
Newline 1637:1638
Ident 1642:1650 text="byteInto"
LParen 1650:1651
Ident 1651:1652 text="s"
Comma 1652:1653
Number 1654:1655 text="0" suf="" isf=0 int=0
Comma 1655:1656
Number 1657:1659 text="97" suf="" isf=0 int=97
RParen 1659:1660
Newline 1660:1661
Ident 1665:1673 text="byteInto"
LParen 1673:1674
Ident 1674:1675 text="s"
Comma 1675:1676
Number 1677:1678 text="1" suf="" isf=0 int=1
Comma 1678:1679
Number 1680:1683 text="108" suf="" isf=0 int=108
RParen 1683:1684
Newline 1684:1685
Ident 1689:1697 text="byteInto"
LParen 1697:1698
Ident 1698:1699 text="s"
Comma 1699:1700
Number 1701:1702 text="2" suf="" isf=0 int=2
Comma 1702:1703
Number 1704:1707 text="112" suf="" isf=0 int=112
RParen 1707:1708
Newline 1708:1709
Ident 1713:1721 text="byteInto"
LParen 1721:1722
Ident 1722:1723 text="s"
Comma 1723:1724
Number 1725:1726 text="3" suf="" isf=0 int=3
Comma 1726:1727
Number 1728:1731 text="104" suf="" isf=0 int=104
RParen 1731:1732
Newline 1732:1733
Ident 1737:1745 text="byteInto"
LParen 1745:1746
Ident 1746:1747 text="s"
Comma 1747:1748
Number 1749:1750 text="4" suf="" isf=0 int=4
Comma 1750:1751
Number 1752:1754 text="97" suf="" isf=0 int=97
RParen 1754:1755
Newline 1755:1756
Return 1760:1766
Ident 1767:1768 text="s"
Newline 1768:1769
RBrace 1769:1770
Newline 1770:1771
Newline 1771:1772
Newline 1864:1865
Newline 1899:1900
Fn 1900:1902 doc="A structurally equal but distinct copy of `mkAlpha`, which is the whole point: these two\nmust collide on the same slot."
Ident 1903:1914 text="mkAlphaTwin"
LParen 1914:1915
RParen 1915:1916
Arrow 1917:1919
Star 1920:1921
Ident 1921:1924 text="int"
LBrace 1925:1926
Newline 1926:1927
Var 1931:1934
Ident 1935:1936 text="s"
Assign 1937:1938
Ident 1939:1945 text="newStr"
LParen 1945:1946
Number 1946:1947 text="5" suf="" isf=0 int=5
RParen 1947:1948
Newline 1948:1949
Ident 1953:1961 text="byteInto"
LParen 1961:1962
Ident 1962:1963 text="s"
Comma 1963:1964
Number 1965:1966 text="0" suf="" isf=0 int=0
Comma 1966:1967
Number 1968:1970 text="97" suf="" isf=0 int=97
RParen 1970:1971
Newline 1971:1972
Ident 1976:1984 text="byteInto"
LParen 1984:1985
Ident 1985:1986 text="s"
Comma 1986:1987
Number 1988:1989 text="1" suf="" isf=0 int=1
Comma 1989:1990
Number 1991:1994 text="108" suf="" isf=0 int=108
RParen 1994:1995
Newline 1995:1996
Ident 2000:2008 text="byteInto"
LParen 2008:2009
Ident 2009:2010 text="s"
Comma 2010:2011
Number 2012:2013 text="2" suf="" isf=0 int=2
Comma 2013:2014
Number 2015:2018 text="112" suf="" isf=0 int=112
RParen 2018:2019
Newline 2019:2020
Ident 2024:2032 text="byteInto"
LParen 2032:2033
Ident 2033:2034 text="s"
Comma 2034:2035
Number 2036:2037 text="3" suf="" isf=0 int=3
Comma 2037:2038
Number 2039:2042 text="104" suf="" isf=0 int=104
RParen 2042:2043
Newline 2043:2044
Ident 2048:2056 text="byteInto"
LParen 2056:2057
Ident 2057:2058 text="s"
Comma 2058:2059
Number 2060:2061 text="4" suf="" isf=0 int=4
Comma 2061:2062
Number 2063:2065 text="97" suf="" isf=0 int=97
RParen 2065:2066
Newline 2066:2067
Return 2071:2077
Ident 2078:2079 text="s"
Newline 2079:2080
RBrace 2080:2081
Newline 2081:2082
Newline 2082:2083
Fn 2083:2085
Ident 2086:2092 text="mkBeta"
LParen 2092:2093
RParen 2093:2094
Arrow 2095:2097
Star 2098:2099
Ident 2099:2102 text="int"
LBrace 2103:2104
Newline 2104:2105
Var 2109:2112
Ident 2113:2114 text="s"
Assign 2115:2116
Ident 2117:2123 text="newStr"
LParen 2123:2124
Number 2124:2125 text="5" suf="" isf=0 int=5
RParen 2125:2126
Newline 2126:2127
Ident 2131:2139 text="byteInto"
LParen 2139:2140
Ident 2140:2141 text="s"
Comma 2141:2142
Number 2143:2144 text="0" suf="" isf=0 int=0
Comma 2144:2145
Number 2146:2148 text="98" suf="" isf=0 int=98
RParen 2148:2149
Newline 2149:2150
Ident 2154:2162 text="byteInto"
LParen 2162:2163
Ident 2163:2164 text="s"
Comma 2164:2165
Number 2166:2167 text="1" suf="" isf=0 int=1
Comma 2167:2168
Number 2169:2172 text="101" suf="" isf=0 int=101
RParen 2172:2173
Newline 2173:2174
Ident 2178:2186 text="byteInto"
LParen 2186:2187
Ident 2187:2188 text="s"
Comma 2188:2189
Number 2190:2191 text="2" suf="" isf=0 int=2
Comma 2191:2192
Number 2193:2196 text="116" suf="" isf=0 int=116
RParen 2196:2197
Newline 2197:2198
Ident 2202:2210 text="byteInto"
LParen 2210:2211
Ident 2211:2212 text="s"
Comma 2212:2213
Number 2214:2215 text="3" suf="" isf=0 int=3
Comma 2215:2216
Number 2217:2219 text="97" suf="" isf=0 int=97
RParen 2219:2220
Newline 2220:2221
Ident 2225:2233 text="byteInto"
LParen 2233:2234
Ident 2234:2235 text="s"
Comma 2235:2236
Number 2237:2238 text="4" suf="" isf=0 int=4
Comma 2238:2239
Number 2240:2242 text="32" suf="" isf=0 int=32
RParen 2242:2243
Newline 2243:2244
Return 2248:2254
Ident 2255:2256 text="s"
Newline 2256:2257
RBrace 2257:2258
Newline 2258:2259
Newline 2259:2260
Newline 2313:2314
Fn 2314:2316 doc="The header words a native map object must expose."
Ident 2317:2327 text="dumpHeader"
LParen 2327:2328
Ident 2328:2329 text="m"
Colon 2329:2330
Star 2331:2332
Ident 2332:2335 text="int"
RParen 2335:2336
LBrace 2337:2338
Newline 2338:2339
Unsafe 2343:2349
LBrace 2350:2351
Newline 2351:2352
Ident 2360:2367 text="println"
LParen 2367:2368
Str 2368:2384 T("  hdr0: ") E[Ident 2378:2379 text="m"; LBracket 2379:2380; Number 2380:2381 text="0" suf="" isf=0 int=0; RBracket 2381:2382; Eof 2383:2383]
RParen 2384:2385
Newline 2385:2386
Ident 2394:2401 text="println"
LParen 2401:2402
Str 2402:2419 T("  class: ") E[Ident 2413:2414 text="m"; LBracket 2414:2415; Number 2415:2416 text="1" suf="" isf=0 int=1; RBracket 2416:2417; Eof 2418:2418]
RParen 2419:2420
Newline 2420:2421
Ident 2429:2436 text="println"
LParen 2436:2437
Str 2437:2453 T("  size: ") E[Ident 2447:2448 text="m"; LBracket 2448:2449; Number 2449:2450 text="2" suf="" isf=0 int=2; RBracket 2450:2451; Eof 2452:2452]
RParen 2453:2454
Newline 2454:2455
Ident 2463:2470 text="println"
LParen 2470:2471
Str 2471:2486 T("  len: ") E[Ident 2480:2481 text="m"; LBracket 2481:2482; Number 2482:2483 text="3" suf="" isf=0 int=3; RBracket 2483:2484; Eof 2485:2485]
RParen 2486:2487
Newline 2487:2488
Ident 2496:2503 text="println"
LParen 2503:2504
Str 2504:2519 T("  cap: ") E[Ident 2513:2514 text="m"; LBracket 2514:2515; Number 2515:2516 text="4" suf="" isf=0 int=4; RBracket 2516:2517; Eof 2518:2518]
RParen 2519:2520
Newline 2520:2521
Ident 2529:2536 text="println"
LParen 2536:2537
Str 2537:2579 T("  entries non-null: ") E[LParen 2559:2560; Ident 2560:2561 text="m"; LBracket 2561:2562; Number 2562:2563 text="5" suf="" isf=0 int=5; RBracket 2563:2564; As 2565:2567; Ident 2568:2571 text="int"; RParen 2571:2572; NotEq 2573:2575; Number 2576:2577 text="0" suf="" isf=0 int=0; Eof 2578:2578]
RParen 2579:2580
Newline 2580:2581
RBrace 2585:2586
Newline 2586:2587
RBrace 2587:2588
Newline 2588:2589
Newline 2589:2590
Fn 2590:2592
Ident 2593:2597 text="main"
LParen 2597:2598
RParen 2598:2599
LBrace 2600:2601
Newline 2601:2602
Newline 2687:2688
Var 2692:2695
Ident 2696:2697 text="m"
Assign 2698:2699
Ident 2700:2709 text="abiMapNew"
LParen 2709:2710
Number 2710:2711 text="0" suf="" isf=0 int=0
RParen 2711:2712
Newline 2712:2713
Ident 2717:2724 text="println"
LParen 2724:2725
Str 2725:2734 T("new(0):")
RParen 2734:2735
Newline 2735:2736
Ident 2740:2750 text="dumpHeader"
LParen 2750:2751
Ident 2751:2752 text="m"
RParen 2752:2753
Newline 2753:2754
Ident 2758:2765 text="println"
LParen 2765:2766
Str 2766:2789 T("  len: ") E[Ident 2775:2784 text="abiMapLen"; LParen 2784:2785; Ident 2785:2786 text="m"; RParen 2786:2787; Eof 2788:2788]
RParen 2789:2790
Newline 2790:2791
Newline 2791:2792
Newline 2874:2875
Newline 2928:2929
Var 2933:2936
Ident 2937:2942 text="small"
Assign 2943:2944
Ident 2945:2954 text="abiMapNew"
LParen 2954:2955
Number 2955:2956 text="4" suf="" isf=0 int=4
RParen 2956:2957
Newline 2957:2958
Var 2962:2965
Ident 2966:2969 text="mid"
Assign 2970:2971
Ident 2972:2981 text="abiMapNew"
LParen 2981:2982
Number 2982:2984 text="20" suf="" isf=0 int=20
RParen 2984:2985
Newline 2985:2986
Var 2990:2993
Ident 2994:2997 text="big"
Assign 2998:2999
Ident 3000:3009 text="abiMapNew"
LParen 3009:3010
Number 3010:3012 text="64" suf="" isf=0 int=64
RParen 3012:3013
Newline 3013:3014
Unsafe 3018:3024
LBrace 3025:3026
Newline 3026:3027
Ident 3035:3042 text="println"
LParen 3042:3043
Str 3043:3067 T("new(4) cap: ") E[Ident 3057:3062 text="small"; LBracket 3062:3063; Number 3063:3064 text="4" suf="" isf=0 int=4; RBracket 3064:3065; Eof 3066:3066]
RParen 3067:3068
Newline 3068:3069
Ident 3077:3084 text="println"
LParen 3084:3085
Str 3085:3108 T("new(20) cap: ") E[Ident 3100:3103 text="mid"; LBracket 3103:3104; Number 3104:3105 text="4" suf="" isf=0 int=4; RBracket 3105:3106; Eof 3107:3107]
RParen 3108:3109
Newline 3109:3110
Ident 3118:3125 text="println"
LParen 3125:3126
Str 3126:3149 T("new(64) cap: ") E[Ident 3141:3144 text="big"; LBracket 3144:3145; Number 3145:3146 text="4" suf="" isf=0 int=4; RBracket 3146:3147; Eof 3148:3148]
RParen 3149:3150
Newline 3150:3151
RBrace 3155:3156
Newline 3156:3157
Newline 3157:3158
Newline 3243:3244
Var 3248:3251
Ident 3252:3254 text="k1"
Assign 3255:3256
Ident 3257:3264 text="mkAlpha"
LParen 3264:3265
RParen 3265:3266
Newline 3266:3267
Var 3271:3274
Ident 3275:3277 text="k2"
Assign 3278:3279
Ident 3280:3291 text="mkAlphaTwin"
LParen 3291:3292
RParen 3292:3293
Newline 3293:3294
Var 3298:3301
Ident 3302:3304 text="k3"
Assign 3305:3306
Ident 3307:3313 text="mkBeta"
LParen 3313:3314
RParen 3314:3315
Newline 3315:3316
Var 3320:3323
Ident 3324:3326 text="v1"
Assign 3327:3328
Ident 3329:3338 text="abiBoxI64"
LParen 3338:3339
Number 3339:3341 text="11" suf="" isf=0 int=11
RParen 3341:3342
Newline 3342:3343
Var 3347:3350
Ident 3351:3353 text="v2"
Assign 3354:3355
Ident 3356:3365 text="abiBoxI64"
LParen 3365:3366
Number 3366:3368 text="22" suf="" isf=0 int=22
RParen 3368:3369
Newline 3369:3370
Ident 3374:3381 text="println"
LParen 3381:3382
Str 3382:3430 T("miss before insert: ") E[Ident 3404:3410 text="isNull"; LParen 3410:3411; Ident 3411:3420 text="abiMapGet"; LParen 3420:3421; Ident 3421:3422 text="m"; Comma 3422:3423; Ident 3424:3426 text="k1"; RParen 3426:3427; RParen 3427:3428; Eof 3429:3429]
RParen 3430:3431
Newline 3431:3432
Ident 3436:3445 text="abiMapSet"
LParen 3445:3446
Ident 3446:3447 text="m"
Comma 3447:3448
Ident 3449:3451 text="k1"
Comma 3451:3452
Ident 3453:3455 text="v1"
RParen 3455:3456
Newline 3456:3457
Newline 3519:3520
Ident 3524:3531 text="println"
LParen 3531:3532
Str 3532:3581 T("structural hit: ") E[Ident 3550:3561 text="abiUnboxI64"; LParen 3561:3562; Ident 3562:3571 text="abiMapGet"; LParen 3571:3572; Ident 3572:3573 text="m"; Comma 3573:3574; Ident 3575:3577 text="k2"; RParen 3577:3578; RParen 3578:3579; Eof 3580:3580]
RParen 3581:3582
Newline 3582:3583
Ident 3587:3596 text="abiMapSet"
LParen 3596:3597
Ident 3597:3598 text="m"
Comma 3598:3599
Ident 3600:3602 text="k3"
Comma 3602:3603
Ident 3604:3606 text="v2"
RParen 3606:3607
Newline 3607:3608
Ident 3612:3619 text="println"
LParen 3619:3620
Str 3620:3651 T("len after two: ") E[Ident 3637:3646 text="abiMapLen"; LParen 3646:3647; Ident 3647:3648 text="m"; RParen 3648:3649; Eof 3650:3650]
RParen 3651:3652
Newline 3652:3653
Ident 3657:3664 text="println"
LParen 3664:3665
Str 3665:3696 T("has alpha: ") E[Ident 3678:3687 text="abiMapHas"; LParen 3687:3688; Ident 3688:3689 text="m"; Comma 3689:3690; Ident 3691:3693 text="k1"; RParen 3693:3694; Eof 3695:3695]
RParen 3696:3697
Newline 3697:3698
Ident 3702:3709 text="println"
LParen 3709:3710
Str 3710:3740 T("has beta: ") E[Ident 3722:3731 text="abiMapHas"; LParen 3731:3732; Ident 3732:3733 text="m"; Comma 3733:3734; Ident 3735:3737 text="k3"; RParen 3737:3738; Eof 3739:3739]
RParen 3740:3741
Newline 3741:3742
Ident 3746:3753 text="println"
LParen 3753:3754
Str 3754:3804 T("has missing: ") E[Ident 3769:3778 text="abiMapHas"; LParen 3778:3779; Ident 3779:3780 text="m"; Comma 3780:3781; Ident 3782:3795 text="abiStrFromI64"; LParen 3795:3796; Number 3796:3800 text="9999" suf="" isf=0 int=9999; RParen 3800:3801; RParen 3801:3802; Eof 3803:3803]
RParen 3804:3805
Newline 3805:3806
Newline 3806:3807
Newline 3892:3893
Var 3897:3900
Ident 3901:3903 text="v3"
Assign 3904:3905
Ident 3906:3915 text="abiBoxI64"
LParen 3915:3916
Number 3916:3918 text="33" suf="" isf=0 int=33
RParen 3918:3919
Newline 3919:3920
Ident 3924:3933 text="abiMapSet"
LParen 3933:3934
Ident 3934:3935 text="m"
Comma 3935:3936
Ident 3937:3939 text="k2"
Comma 3939:3940
Ident 3941:3943 text="v3"
RParen 3943:3944
Newline 3944:3945
Ident 3949:3956 text="println"
LParen 3956:3957
Str 3957:4003 T("overwritten: ") E[Ident 3972:3983 text="abiUnboxI64"; LParen 3983:3984; Ident 3984:3993 text="abiMapGet"; LParen 3993:3994; Ident 3994:3995 text="m"; Comma 3995:3996; Ident 3997:3999 text="k1"; RParen 3999:4000; RParen 4000:4001; Eof 4002:4002]
RParen 4003:4004
Newline 4004:4005
Ident 4009:4016 text="println"
LParen 4016:4017
Str 4017:4054 T("len after overwrite: ") E[Ident 4040:4049 text="abiMapLen"; LParen 4049:4050; Ident 4050:4051 text="m"; RParen 4051:4052; Eof 4053:4053]
RParen 4054:4055
Newline 4055:4056
Newline 4056:4057
Newline 4144:4145
Ident 4149:4156 text="println"
LParen 4156:4157
Str 4157:4250 T("boxed default on miss: ") E[Ident 4182:4193 text="abiUnboxI64"; LParen 4193:4194; Ident 4194:4208 text="abiMapGetBoxed"; LParen 4208:4209; Ident 4209:4210 text="m"; Comma 4210:4211; Ident 4212:4225 text="abiStrFromI64"; LParen 4225:4226; Number 4226:4230 text="9999" suf="" isf=0 int=9999; RParen 4230:4231; Comma 4231:4232; Ident 4233:4242 text="abiBoxI64"; LParen 4242:4243; Minus 4243:4244; Number 4244:4245 text="1" suf="" isf=0 int=1; RParen 4245:4246; RParen 4246:4247; RParen 4247:4248; Eof 4249:4249]
RParen 4250:4251
Newline 4251:4252
Ident 4256:4263 text="println"
LParen 4263:4264
Str 4264:4328 T("boxed hit: ") E[Ident 4277:4288 text="abiUnboxI64"; LParen 4288:4289; Ident 4289:4303 text="abiMapGetBoxed"; LParen 4303:4304; Ident 4304:4305 text="m"; Comma 4305:4306; Ident 4307:4309 text="k1"; Comma 4309:4310; Ident 4311:4320 text="abiBoxI64"; LParen 4320:4321; Minus 4321:4322; Number 4322:4323 text="1" suf="" isf=0 int=1; RParen 4323:4324; RParen 4324:4325; RParen 4325:4326; Eof 4327:4327]
RParen 4328:4329
Newline 4329:4330
Newline 4330:4331
Newline 4418:4419
Newline 4502:4503
Newline 4592:4593
Newline 4679:4680
Newline 4767:4768
Var 4772:4775
Ident 4776:4780 text="bkey"
Assign 4781:4782
Ident 4783:4792 text="abiBoxI64"
LParen 4792:4793
Number 4793:4797 text="4242" suf="" isf=0 int=4242
RParen 4797:4798
Newline 4798:4799
Ident 4803:4812 text="abiMapSet"
LParen 4812:4813
Ident 4813:4814 text="m"
Comma 4814:4815
Ident 4816:4820 text="bkey"
Comma 4820:4821
Ident 4822:4831 text="abiBoxI64"
LParen 4831:4832
Number 4832:4833 text="7" suf="" isf=0 int=7
RParen 4833:4834
RParen 4834:4835
Newline 4835:4836
Ident 4840:4847 text="println"
LParen 4847:4848
Str 4848:4904 T("boxed key after set: ") E[Ident 4871:4882 text="abiUnboxI64"; LParen 4882:4883; Ident 4883:4892 text="abiMapGet"; LParen 4892:4893; Ident 4893:4894 text="m"; Comma 4894:4895; Ident 4896:4900 text="bkey"; RParen 4900:4901; RParen 4901:4902; Eof 4903:4903]
RParen 4904:4905
Newline 4905:4906
Newline 4990:4991
Ident 4995:5002 text="println"
LParen 5002:5003
Str 5003:5069 T("boxed key via twin: ") E[Ident 5025:5036 text="abiUnboxI64"; LParen 5036:5037; Ident 5037:5046 text="abiMapGet"; LParen 5046:5047; Ident 5047:5048 text="m"; Comma 5048:5049; Ident 5050:5059 text="abiBoxI64"; LParen 5059:5060; Number 5060:5064 text="4242" suf="" isf=0 int=4242; RParen 5064:5065; RParen 5065:5066; RParen 5066:5067; Eof 5068:5068]
RParen 5069:5070
Newline 5070:5071
Newline 5071:5072
Newline 5159:5160
Var 5164:5167
Ident 5168:5169 text="g"
Assign 5170:5171
Ident 5172:5181 text="abiMapNew"
LParen 5181:5182
Number 5182:5183 text="0" suf="" isf=0 int=0
RParen 5183:5184
Newline 5184:5185
Var 5189:5192
Ident 5193:5194 text="i"
Assign 5195:5196
Number 5197:5198 text="0" suf="" isf=0 int=0
Newline 5198:5199
While 5203:5208
LParen 5209:5210
Ident 5210:5211 text="i"
Lt 5212:5213
Number 5214:5217 text="200" suf="" isf=0 int=200
RParen 5217:5218
LBrace 5219:5220
Newline 5220:5221
Ident 5229:5238 text="abiMapSet"
LParen 5238:5239
Ident 5239:5240 text="g"
Comma 5240:5241
Ident 5242:5255 text="abiStrFromI64"
LParen 5255:5256
Ident 5256:5257 text="i"
RParen 5257:5258
Comma 5258:5259
Ident 5260:5269 text="abiBoxI64"
LParen 5269:5270
Ident 5270:5271 text="i"
Star 5272:5273
Number 5274:5275 text="3" suf="" isf=0 int=3
RParen 5275:5276
RParen 5276:5277
Newline 5277:5278
Ident 5286:5287 text="i"
Assign 5288:5289
Ident 5290:5291 text="i"
Plus 5292:5293
Number 5294:5295 text="1" suf="" isf=0 int=1
Newline 5295:5296
RBrace 5300:5301
Newline 5301:5302
Unsafe 5306:5312
LBrace 5313:5314
Newline 5314:5315
Ident 5323:5330 text="println"
LParen 5330:5331
Str 5331:5350 T("grown cap: ") E[Ident 5344:5345 text="g"; LBracket 5345:5346; Number 5346:5347 text="4" suf="" isf=0 int=4; RBracket 5347:5348; Eof 5349:5349]
RParen 5350:5351
Newline 5351:5352
Ident 5360:5367 text="println"
LParen 5367:5368
Str 5368:5395 T("grown len: ") E[Ident 5381:5390 text="abiMapLen"; LParen 5390:5391; Ident 5391:5392 text="g"; RParen 5392:5393; Eof 5394:5394]
RParen 5395:5396
Newline 5396:5397
RBrace 5401:5402
Newline 5402:5403
Newline 5487:5488
Var 5492:5495
Ident 5496:5499 text="bad"
Assign 5500:5501
Number 5502:5503 text="0" suf="" isf=0 int=0
Newline 5503:5504
Var 5508:5511
Ident 5512:5513 text="j"
Assign 5514:5515
Number 5516:5517 text="0" suf="" isf=0 int=0
Newline 5517:5518
While 5522:5527
LParen 5528:5529
Ident 5529:5530 text="j"
Lt 5531:5532
Number 5533:5536 text="200" suf="" isf=0 int=200
RParen 5536:5537
LBrace 5538:5539
Newline 5539:5540
If 5548:5550
LParen 5551:5552
Ident 5552:5558 text="isNull"
LParen 5558:5559
Ident 5559:5568 text="abiMapGet"
LParen 5568:5569
Ident 5569:5570 text="g"
Comma 5570:5571
Ident 5572:5585 text="abiStrFromI64"
LParen 5585:5586
Ident 5586:5587 text="j"
RParen 5587:5588
RParen 5588:5589
RParen 5589:5590
RParen 5590:5591
LBrace 5592:5593
Ident 5594:5597 text="bad"
Assign 5598:5599
Ident 5600:5603 text="bad"
Plus 5604:5605
Number 5606:5607 text="1" suf="" isf=0 int=1
RBrace 5608:5609
Newline 5609:5610
Else 5618:5622
LBrace 5623:5624
Newline 5624:5625
If 5637:5639
LParen 5640:5641
Ident 5641:5652 text="abiUnboxI64"
LParen 5652:5653
Ident 5653:5662 text="abiMapGet"
LParen 5662:5663
Ident 5663:5664 text="g"
Comma 5664:5665
Ident 5666:5679 text="abiStrFromI64"
LParen 5679:5680
Ident 5680:5681 text="j"
RParen 5681:5682
RParen 5682:5683
RParen 5683:5684
NotEq 5685:5687
Ident 5688:5689 text="j"
Star 5690:5691
Number 5692:5693 text="3" suf="" isf=0 int=3
RParen 5693:5694
LBrace 5695:5696
Ident 5697:5700 text="bad"
Assign 5701:5702
Ident 5703:5706 text="bad"
Plus 5707:5708
Number 5709:5710 text="1" suf="" isf=0 int=1
RBrace 5711:5712
Newline 5712:5713
RBrace 5721:5722
Newline 5722:5723
Ident 5731:5732 text="j"
Assign 5733:5734
Ident 5735:5736 text="j"
Plus 5737:5738
Number 5739:5740 text="1" suf="" isf=0 int=1
Newline 5740:5741
RBrace 5745:5746
Newline 5746:5747
Ident 5751:5758 text="println"
LParen 5758:5759
Str 5759:5787 T("misses after rehash: ") E[Ident 5782:5785 text="bad"; Eof 5786:5786]
RParen 5787:5788
Newline 5788:5789
Newline 5789:5790
Newline 5877:5878
Ident 5882:5889 text="println"
LParen 5889:5890
Str 5890:5956 T("remove present: ") E[Ident 5908:5919 text="abiUnboxI64"; LParen 5919:5920; Ident 5920:5932 text="abiMapRemove"; LParen 5932:5933; Ident 5933:5934 text="g"; Comma 5934:5935; Ident 5936:5949 text="abiStrFromI64"; LParen 5949:5950; Number 5950:5951 text="5" suf="" isf=0 int=5; RParen 5951:5952; RParen 5952:5953; RParen 5953:5954; Eof 5955:5955]
RParen 5956:5957
Newline 5957:5958
Ident 5962:5969 text="println"
LParen 5969:5970
Str 5970:6028 T("remove again: ") E[Ident 5986:5998 text="abiMapRemove"; LParen 5998:5999; Ident 5999:6000 text="g"; Comma 6000:6001; Ident 6002:6015 text="abiStrFromI64"; LParen 6015:6016; Number 6016:6017 text="5" suf="" isf=0 int=5; RParen 6017:6018; RParen 6018:6019; As 6020:6022; Ident 6023:6026 text="int"; Eof 6027:6027]
RParen 6028:6029
Newline 6029:6030
Ident 6034:6041 text="println"
LParen 6041:6042
Str 6042:6106 T("remove absent: ") E[Ident 6059:6071 text="abiMapRemove"; LParen 6071:6072; Ident 6072:6073 text="g"; Comma 6073:6074; Ident 6075:6088 text="abiStrFromI64"; LParen 6088:6089; Number 6089:6095 text="123456" suf="" isf=0 int=123456; RParen 6095:6096; RParen 6096:6097; As 6098:6100; Ident 6101:6104 text="int"; Eof 6105:6105]
RParen 6106:6107
Newline 6107:6108
Ident 6112:6119 text="println"
LParen 6119:6120
Str 6120:6154 T("len after remove: ") E[Ident 6140:6149 text="abiMapLen"; LParen 6149:6150; Ident 6150:6151 text="g"; RParen 6151:6152; Eof 6153:6153]
RParen 6154:6155
Newline 6155:6156
Ident 6160:6167 text="println"
LParen 6167:6168
Str 6168:6224 T("removed gone: ") E[Ident 6184:6190 text="isNull"; LParen 6190:6191; Ident 6191:6200 text="abiMapGet"; LParen 6200:6201; Ident 6201:6202 text="g"; Comma 6202:6203; Ident 6204:6217 text="abiStrFromI64"; LParen 6217:6218; Number 6218:6219 text="5" suf="" isf=0 int=5; RParen 6219:6220; RParen 6220:6221; RParen 6221:6222; Eof 6223:6223]
RParen 6224:6225
Newline 6225:6226
Newline 6286:6287
Ident 6291:6298 text="println"
LParen 6298:6299
Str 6299:6372 T("survivor after tombstone: ") E[Ident 6327:6338 text="abiUnboxI64"; LParen 6338:6339; Ident 6339:6348 text="abiMapGet"; LParen 6348:6349; Ident 6349:6350 text="g"; Comma 6350:6351; Ident 6352:6365 text="abiStrFromI64"; LParen 6365:6366; Number 6366:6367 text="7" suf="" isf=0 int=7; RParen 6367:6368; RParen 6368:6369; RParen 6369:6370; Eof 6371:6371]
RParen 6372:6373
Newline 6373:6374
Newline 6374:6375
Newline 6462:6463
Var 6467:6470
Ident 6471:6475 text="keys"
Assign 6476:6477
Ident 6478:6488 text="abiMapKeys"
LParen 6488:6489
Ident 6489:6490 text="m"
RParen 6490:6491
Newline 6491:6492
Var 6496:6499
Ident 6500:6504 text="vals"
Assign 6505:6506
Ident 6507:6519 text="abiMapValues"
LParen 6519:6520
Ident 6520:6521 text="m"
RParen 6521:6522
Newline 6522:6523
Ident 6527:6534 text="println"
LParen 6534:6535
Str 6535:6573 T("key snapshot len: ") E[Ident 6555:6565 text="abiListLen"; LParen 6565:6566; Ident 6566:6570 text="keys"; RParen 6570:6571; Eof 6572:6572]
RParen 6573:6574
Newline 6574:6575
Ident 6579:6586 text="println"
LParen 6586:6587
Str 6587:6627 T("value snapshot len: ") E[Ident 6609:6619 text="abiListLen"; LParen 6619:6620; Ident 6620:6624 text="vals"; RParen 6624:6625; Eof 6626:6626]
RParen 6627:6628
Newline 6628:6629
Ident 6633:6640 text="println"
LParen 6640:6641
Str 6641:6699 T("membership equal: ") E[Ident 6661:6671 text="abiListLen"; LParen 6671:6672; Ident 6672:6676 text="keys"; RParen 6676:6677; EqEq 6678:6680; Ident 6681:6691 text="abiListLen"; LParen 6691:6692; Ident 6692:6696 text="vals"; RParen 6696:6697; Eof 6698:6698]
RParen 6699:6700
Newline 6700:6701
Newline 6701:6702
Newline 6789:6790
Var 6794:6797
Ident 6798:6799 text="e"
Assign 6800:6801
Ident 6802:6811 text="abiMapNew"
LParen 6811:6812
Number 6812:6813 text="0" suf="" isf=0 int=0
RParen 6813:6814
Newline 6814:6815
Ident 6819:6826 text="println"
LParen 6826:6827
Str 6827:6854 T("empty len: ") E[Ident 6840:6849 text="abiMapLen"; LParen 6849:6850; Ident 6850:6851 text="e"; RParen 6851:6852; Eof 6853:6853]
RParen 6854:6855
Newline 6855:6856
Ident 6860:6867 text="println"
LParen 6867:6868
Str 6868:6906 T("empty get: ") E[Ident 6881:6890 text="abiMapGet"; LParen 6890:6891; Ident 6891:6892 text="e"; Comma 6892:6893; Ident 6894:6896 text="k1"; RParen 6896:6897; As 6898:6900; Ident 6901:6904 text="int"; Eof 6905:6905]
RParen 6906:6907
Newline 6907:6908
Ident 6912:6919 text="println"
LParen 6919:6920
Str 6920:6951 T("empty has: ") E[Ident 6933:6942 text="abiMapHas"; LParen 6942:6943; Ident 6943:6944 text="e"; Comma 6944:6945; Ident 6946:6948 text="k1"; RParen 6948:6949; Eof 6950:6950]
RParen 6951:6952
Newline 6952:6953
Ident 6957:6964 text="println"
LParen 6964:6965
Str 6965:7009 T("empty remove: ") E[Ident 6981:6993 text="abiMapRemove"; LParen 6993:6994; Ident 6994:6995 text="e"; Comma 6995:6996; Ident 6997:6999 text="k1"; RParen 6999:7000; As 7001:7003; Ident 7004:7007 text="int"; Eof 7008:7008]
RParen 7009:7010
Newline 7010:7011
Ident 7015:7022 text="println"
LParen 7022:7023
Str 7023:7064 T("empty keys: ") E[Ident 7037:7047 text="abiListLen"; LParen 7047:7048; Ident 7048:7058 text="abiMapKeys"; LParen 7058:7059; Ident 7059:7060 text="e"; RParen 7060:7061; RParen 7061:7062; Eof 7063:7063]
RParen 7064:7065
Newline 7065:7066
Ident 7070:7077 text="println"
LParen 7077:7078
Str 7078:7123 T("empty values: ") E[Ident 7094:7104 text="abiListLen"; LParen 7104:7105; Ident 7105:7117 text="abiMapValues"; LParen 7117:7118; Ident 7118:7119 text="e"; RParen 7119:7120; RParen 7120:7121; Eof 7122:7122]
RParen 7123:7124
Newline 7124:7125
RBrace 7125:7126
Eof 7126:7126
