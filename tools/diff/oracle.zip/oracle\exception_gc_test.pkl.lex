Newline 75:76
Newline 155:156
Newline 234:235
Newline 302:303
Newline 303:304
Class 304:309
Ident 310:313 text="Box"
LBrace 314:315
Newline 315:316
Var 320:323
Ident 324:331 text="payload"
Colon 331:332
Ident 333:339 text="string"
Newline 339:340
Constructor 344:355
LParen 355:356
Ident 356:357 text="p"
Colon 357:358
Ident 359:365 text="string"
RParen 365:366
LBrace 367:368
Newline 368:369
This 377:381
Dot 381:382
Ident 382:389 text="payload"
Assign 390:391
Ident 392:393 text="p"
Newline 393:394
RBrace 398:399
Newline 399:400
RBrace 400:401
Newline 401:402
Newline 402:403
Newline 482:483
Newline 562:563
Fn 563:565
Ident 566:571 text="churn"
LParen 571:572
Ident 572:573 text="n"
Colon 573:574
Ident 575:578 text="int"
RParen 578:579
Arrow 580:582
Ident 583:589 text="string"
LBrace 590:591
Newline 591:592
Var 596:599
Ident 600:604 text="keep"
Colon 604:605
Ident 606:612 text="string"
Assign 613:614
Str 615:617
Newline 617:618
Var 622:625
Ident 626:627 text="i"
Colon 627:628
Ident 629:632 text="int"
Assign 633:634
Number 635:636 text="0" suf="" isf=0 int=0
Newline 636:637
While 641:646
LParen 647:648
Ident 648:649 text="i"
Lt 650:651
Ident 652:653 text="n"
RParen 653:654
LBrace 655:656
Newline 656:657
Let 665:668
Ident 669:670 text="b"
Assign 671:672
Ident 673:676 text="Box"
LParen 676:677
Str 677:686 T("filler ")
Plus 687:688
Ident 689:693 text="keep"
RParen 693:694
Newline 694:695
Ident 703:707 text="keep"
Assign 708:709
Ident 710:711 text="b"
Dot 711:712
Ident 712:719 text="payload"
Newline 719:720
Ident 728:737 text="gcCollect"
LParen 737:738
True 738:742
RParen 742:743
Newline 743:744
Ident 752:753 text="i"
Assign 754:755
Ident 756:757 text="i"
Plus 758:759
Number 760:761 text="1" suf="" isf=0 int=1
Newline 761:762
RBrace 766:767
Newline 767:768
Ident 772:776 text="keep"
Newline 776:777
RBrace 777:778
Newline 778:779
Newline 779:780
Newline 860:861
Newline 884:885
Fn 885:887
Ident 888:892 text="deep"
LParen 892:893
Ident 893:894 text="n"
Colon 894:895
Ident 896:899 text="int"
RParen 899:900
Arrow 901:903
Ident 904:910 text="string"
LBrace 911:912
Newline 912:913
If 917:919
LParen 920:921
Ident 921:922 text="n"
EqEq 923:925
Number 926:927 text="0" suf="" isf=0 int=0
RParen 927:928
LBrace 929:930
Newline 930:931
Throw 939:944
Str 945:963 T("payload survives")
Newline 963:964
RBrace 968:969
Newline 969:970
Ident 974:979 text="churn"
LParen 979:980
Number 980:982 text="20" suf="" isf=0 int=20
RParen 982:983
Newline 983:984
Ident 988:992 text="deep"
LParen 992:993
Ident 993:994 text="n"
Minus 995:996
Number 997:998 text="1" suf="" isf=0 int=1
RParen 998:999
Newline 999:1000
RBrace 1000:1001
Newline 1001:1002
Newline 1002:1003
Fn 1003:1005
Ident 1006:1012 text="caught"
LParen 1012:1013
RParen 1013:1014
Arrow 1015:1017
Ident 1018:1024 text="string"
LBrace 1025:1026
Newline 1026:1027
Try 1031:1034
LBrace 1035:1036
Newline 1036:1037
Ident 1045:1049 text="deep"
LParen 1049:1050
Number 1050:1051 text="6" suf="" isf=0 int=6
RParen 1051:1052
Newline 1052:1053
Str 1061:1071 T("no throw")
Newline 1071:1072
RBrace 1076:1077
Catch 1078:1083
LParen 1084:1085
Ident 1085:1086 text="e"
RParen 1086:1087
LBrace 1088:1089
Newline 1089:1090
Newline 1167:1168
Newline 1239:1240
Ident 1248:1253 text="churn"
LParen 1253:1254
Number 1254:1256 text="20" suf="" isf=0 int=20
RParen 1256:1257
Newline 1257:1258
Str 1266:1272 T("got ")
Plus 1273:1274
Ident 1275:1276 text="e"
Newline 1276:1277
RBrace 1281:1282
Newline 1282:1283
RBrace 1283:1284
Newline 1284:1285
Newline 1285:1286
Ident 1286:1290 text="test"
Fn 1291:1293
Ident 1294:1337 text="a_pending_payload_survives_many_collections"
LParen 1337:1338
RParen 1338:1339
LBrace 1340:1341
Newline 1341:1342
Ident 1346:1352 text="expect"
LParen 1352:1353
Ident 1353:1359 text="caught"
LParen 1359:1360
RParen 1360:1361
RParen 1361:1362
Dot 1362:1363
Ident 1363:1367 text="toBe"
LParen 1367:1368
Str 1368:1390 T("got payload survives")
RParen 1390:1391
Newline 1391:1392
RBrace 1392:1393
Newline 1393:1394
Newline 1394:1395
Ident 1395:1399 text="test"
Fn 1400:1402
Ident 1403:1457 text="a_bound_payload_is_still_rooted_after_the_handler_runs"
LParen 1457:1458
RParen 1458:1459
LBrace 1460:1461
Newline 1461:1462
Ident 1466:1472 text="expect"
LParen 1472:1473
Ident 1473:1479 text="caught"
LParen 1479:1480
RParen 1480:1481
RParen 1481:1482
Dot 1482:1483
Ident 1483:1487 text="toBe"
LParen 1487:1488
Str 1488:1510 T("got payload survives")
RParen 1510:1511
Newline 1511:1512
RBrace 1512:1513
Newline 1513:1514
Newline 1514:1515
Newline 1593:1594
Newline 1670:1671
Fn 1671:1673
Ident 1674:1687 text="built_payload"
LParen 1687:1688
RParen 1688:1689
Arrow 1690:1692
Ident 1693:1699 text="string"
LBrace 1700:1701
Newline 1701:1702
Let 1706:1709
Ident 1710:1711 text="a"
Assign 1712:1713
Str 1714:1723 T("payload")
Newline 1723:1724
Let 1728:1731
Ident 1732:1733 text="b"
Assign 1734:1735
Str 1736:1747 T(" survives")
Newline 1747:1748
Ident 1752:1757 text="churn"
LParen 1757:1758
Number 1758:1760 text="10" suf="" isf=0 int=10
RParen 1760:1761
Newline 1761:1762
Throw 1766:1771
Ident 1772:1773 text="a"
Plus 1774:1775
Ident 1776:1777 text="b"
Newline 1777:1778
RBrace 1778:1779
Newline 1779:1780
Newline 1780:1781
Ident 1781:1785 text="test"
Fn 1786:1788
Ident 1789:1835 text="a_run_time_built_payload_survives_a_collection"
LParen 1835:1836
RParen 1836:1837
LBrace 1838:1839
Newline 1839:1840
Try 1844:1847
LBrace 1848:1849
Newline 1849:1850
Ident 1858:1871 text="built_payload"
LParen 1871:1872
RParen 1872:1873
Newline 1873:1874
Ident 1882:1888 text="expect"
LParen 1888:1889
Str 1889:1899 T("no throw")
RParen 1899:1900
Dot 1900:1901
Ident 1901:1905 text="toBe"
LParen 1905:1906
Str 1906:1919 T("unreachable")
RParen 1919:1920
Newline 1920:1921
RBrace 1925:1926
Catch 1927:1932
LParen 1933:1934
Ident 1934:1935 text="e"
RParen 1935:1936
LBrace 1937:1938
Newline 1938:1939
Ident 1947:1953 text="expect"
LParen 1953:1954
Ident 1954:1955 text="e"
RParen 1955:1956
Dot 1956:1957
Ident 1957:1961 text="toBe"
LParen 1961:1962
Str 1962:1980 T("payload survives")
RParen 1980:1981
Newline 1981:1982
RBrace 1986:1987
Newline 1987:1988
RBrace 1988:1989
Newline 1989:1990
Newline 1990:1991
Newline 2057:2058
Fn 2058:2060
Ident 2061:2079 text="touched_by_finally"
LParen 2079:2080
RParen 2080:2081
Arrow 2082:2084
Ident 2085:2091 text="string"
LBrace 2092:2093
Newline 2093:2094
Try 2098:2101
LBrace 2102:2103
Newline 2103:2104
Throw 2112:2117
Str 2118:2129 T("in flight")
Newline 2129:2130
RBrace 2134:2135
Finally 2136:2143
LBrace 2144:2145
Newline 2145:2146
Ident 2154:2159 text="churn"
LParen 2159:2160
Number 2160:2162 text="10" suf="" isf=0 int=10
RParen 2162:2163
Newline 2163:2164
RBrace 2168:2169
Newline 2169:2170
Str 2174:2187 T("unreachable")
Newline 2187:2188
RBrace 2188:2189
Newline 2189:2190
Newline 2190:2191
Ident 2191:2195 text="test"
Fn 2196:2198
Ident 2199:2251 text="a_finally_can_run_while_the_payload_is_still_pending"
LParen 2251:2252
RParen 2252:2253
LBrace 2254:2255
Newline 2255:2256
Try 2260:2263
LBrace 2264:2265
Newline 2265:2266
Ident 2274:2292 text="touched_by_finally"
LParen 2292:2293
RParen 2293:2294
Newline 2294:2295
Ident 2303:2309 text="expect"
LParen 2309:2310
Str 2310:2320 T("no throw")
RParen 2320:2321
Dot 2321:2322
Ident 2322:2326 text="toBe"
LParen 2326:2327
Str 2327:2340 T("unreachable")
RParen 2340:2341
Newline 2341:2342
RBrace 2346:2347
Catch 2348:2353
LParen 2354:2355
Ident 2355:2356 text="e"
RParen 2356:2357
LBrace 2358:2359
Newline 2359:2360
Ident 2368:2374 text="expect"
LParen 2374:2375
Ident 2375:2376 text="e"
RParen 2376:2377
Dot 2377:2378
Ident 2378:2382 text="toBe"
LParen 2382:2383
Str 2383:2394 T("in flight")
RParen 2394:2395
Newline 2395:2396
RBrace 2400:2401
Newline 2401:2402
RBrace 2402:2403
Newline 2403:2404
Newline 2404:2405
Newline 2482:2483
Newline 2543:2544
Ident 2544:2548 text="test"
Fn 2549:2551
Ident 2552:2596 text="a_handler_collects_before_reading_its_binder"
LParen 2596:2597
RParen 2597:2598
LBrace 2599:2600
Newline 2600:2601
Try 2605:2608
LBrace 2609:2610
Newline 2610:2611
Ident 2619:2624 text="churn"
LParen 2624:2625
Number 2625:2627 text="30" suf="" isf=0 int=30
RParen 2627:2628
Newline 2628:2629
Throw 2637:2642
Str 2643:2655 T("same frame")
Newline 2655:2656
RBrace 2660:2661
Catch 2662:2667
LParen 2668:2669
Ident 2669:2670 text="e"
RParen 2670:2671
LBrace 2672:2673
Newline 2673:2674
Ident 2682:2687 text="churn"
LParen 2687:2688
Number 2688:2690 text="30" suf="" isf=0 int=30
RParen 2690:2691
Newline 2691:2692
Ident 2700:2706 text="expect"
LParen 2706:2707
Ident 2707:2708 text="e"
RParen 2708:2709
Dot 2709:2710
Ident 2710:2714 text="toBe"
LParen 2714:2715
Str 2715:2727 T("same frame")
RParen 2727:2728
Newline 2728:2729
RBrace 2733:2734
Newline 2734:2735
RBrace 2735:2736
Newline 2736:2737
Eof 2737:2737
