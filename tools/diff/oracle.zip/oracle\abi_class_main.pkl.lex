Module 0:6
Ident 7:21 text="abi_class_main"
Newline 21:22
Newline 22:23
Newline 96:97
Newline 165:166
Newline 168:169
Newline 248:249
Newline 320:321
Newline 323:324
Newline 398:399
Newline 474:475
Newline 508:509
Newline 511:512
Newline 574:575
Newline 577:578
Newline 656:657
Newline 730:731
Newline 811:812
Newline 850:851
Newline 930:931
Newline 966:967
Newline 1046:1047
Newline 1112:1113
Newline 1190:1191
Newline 1213:1214
Newline 1216:1217
Newline 1289:1290
Newline 1366:1367
Newline 1405:1406
Newline 1408:1409
Newline 1485:1486
Newline 1565:1566
Newline 1646:1647
Newline 1715:1716
Newline 1796:1797
Import 1797:1803
LBrace 1804:1805
Ident 1806:1817 text="abiClassNew"
Comma 1817:1818
Ident 1819:1832 text="abiObjSlotGet"
Comma 1832:1833
Ident 1834:1847 text="abiObjSlotSet"
Comma 1847:1848
Ident 1849:1861 text="abiSizeWords"
Comma 1861:1862
Ident 1863:1880 text="slotCountFromSize"
Comma 1880:1881
Ident 1882:1895 text="CLASS_ID_WORD"
Comma 1895:1896
Ident 1897:1906 text="SIZE_WORD"
Comma 1906:1907
Ident 1908:1917 text="SLOT_WORD"
RBrace 1918:1919
From 1920:1924
Ident 1925:1932 text="runtime"
Dot 1932:1933
Ident 1933:1942 text="abi_class"
Newline 1942:1943
Import 1943:1949
LBrace 1950:1951
Ident 1952:1974 text="PICKLE_CLASS_USER_BASE"
RBrace 1975:1976
From 1977:1981
Ident 1982:1989 text="runtime"
Dot 1989:1990
Ident 1990:1996 text="object"
Newline 1996:1997
Import 1997:2003
LBrace 2004:2005
Ident 2006:2015 text="abiBoxI64"
Comma 2015:2016
Ident 2017:2027 text="abiBoxBool"
RBrace 2028:2029
From 2030:2034
Ident 2035:2042 text="runtime"
Dot 2042:2043
Ident 2043:2050 text="abi_box"
Newline 2050:2051
Import 2051:2057
LBrace 2058:2059
Ident 2060:2074 text="abiStrFromByte"
RBrace 2075:2076
From 2077:2081
Ident 2082:2089 text="runtime"
Dot 2089:2090
Ident 2090:2100 text="abi_string"
Newline 2100:2101
Newline 2101:2102
Fn 2102:2104
Ident 2105:2109 text="word"
LParen 2109:2110
Ident 2110:2113 text="obj"
Colon 2113:2114
Star 2115:2116
Ident 2116:2119 text="int"
Comma 2119:2120
Ident 2121:2122 text="w"
Colon 2122:2123
Ident 2124:2127 text="int"
RParen 2127:2128
Arrow 2129:2131
Ident 2132:2135 text="int"
LBrace 2136:2137
Newline 2137:2138
Unsafe 2142:2148
LBrace 2149:2150
Newline 2150:2151
Return 2159:2165
Ident 2166:2169 text="obj"
LBracket 2169:2170
Ident 2170:2171 text="w"
RBracket 2171:2172
Newline 2172:2173
RBrace 2177:2178
Newline 2178:2179
RBrace 2179:2180
Newline 2180:2181
Newline 2181:2182
Fn 2182:2184
Ident 2185:2189 text="main"
LParen 2189:2190
RParen 2190:2191
LBrace 2192:2193
Newline 2193:2194
Ident 2198:2205 text="println"
LParen 2205:2206
Str 2206:2247 T("== the size word is clamped, not raw ==")
RParen 2247:2248
Newline 2248:2249
Newline 2328:2329
Newline 2367:2368
Var 2372:2375
Ident 2376:2377 text="n"
Assign 2378:2379
Number 2380:2381 text="0" suf="" isf=0 int=0
Newline 2381:2382
While 2386:2391
LParen 2392:2393
Ident 2393:2394 text="n"
Le 2395:2397
Number 2398:2399 text="4" suf="" isf=0 int=4
RParen 2399:2400
LBrace 2401:2402
Newline 2402:2403
Ident 2411:2418 text="println"
LParen 2418:2419
Str 2419:2517 T("  n=") E[Ident 2425:2426 text="n"; Eof 2427:2427] T(" raw=") E[Ident 2433:2439 text="HEADER"; Plus 2440:2441; Number 2442:2443 text="8" suf="" isf=0 int=8; Star 2444:2445; Ident 2446:2447 text="n"; Eof 2448:2448] T(" stored=") E[Ident 2457:2469 text="abiSizeWords"; LParen 2469:2470; Ident 2470:2471 text="n"; RParen 2471:2472; Eof 2473:2473] T(" slots=") E[Ident 2481:2498 text="slotCountFromSize"; LParen 2498:2499; Ident 2499:2511 text="abiSizeWords"; LParen 2511:2512; Ident 2512:2513 text="n"; RParen 2513:2514; RParen 2514:2515; Eof 2516:2516]
RParen 2517:2518
Newline 2518:2519
Ident 2527:2528 text="n"
Assign 2529:2530
Ident 2531:2532 text="n"
Plus 2533:2534
Number 2535:2536 text="1" suf="" isf=0 int=1
Newline 2536:2537
RBrace 2541:2542
Newline 2542:2543
Newline 2543:2544
Ident 2548:2555 text="println"
LParen 2555:2556
Str 2556:2580 T("== class_new header ==")
RParen 2580:2581
Newline 2581:2582
Let 2586:2589
Ident 2590:2593 text="two"
Assign 2594:2595
Ident 2596:2607 text="abiClassNew"
LParen 2607:2608
Number 2608:2610 text="10" suf="" isf=0 int=10
Comma 2610:2611
Number 2612:2613 text="2" suf="" isf=0 int=2
RParen 2613:2614
Newline 2614:2615
Ident 2619:2626 text="println"
LParen 2626:2627
Str 2627:2709 T("  id=") E[Ident 2634:2638 text="word"; LParen 2638:2639; Ident 2639:2642 text="two"; Comma 2642:2643; Ident 2644:2657 text="CLASS_ID_WORD"; RParen 2657:2658; Eof 2659:2659] T(" size=") E[Ident 2666:2670 text="word"; LParen 2670:2671; Ident 2671:2674 text="two"; Comma 2674:2675; Ident 2676:2685 text="SIZE_WORD"; RParen 2685:2686; Eof 2687:2687] T(" word0=") E[Ident 2695:2699 text="word"; LParen 2699:2700; Ident 2700:2703 text="two"; Comma 2703:2704; Number 2705:2706 text="0" suf="" isf=0 int=0; RParen 2706:2707; Eof 2708:2708]
RParen 2709:2710
Newline 2710:2711
Ident 2715:2722 text="println"
LParen 2722:2723
Str 2723:2768 T("  eight-aligned: ") E[Ident 2742:2754 text="abiSizeWords"; LParen 2754:2755; Number 2755:2756 text="3" suf="" isf=0 int=3; RParen 2756:2757; Percent 2758:2759; Number 2760:2761 text="8" suf="" isf=0 int=8; EqEq 2762:2764; Number 2765:2766 text="0" suf="" isf=0 int=0; Eof 2767:2767]
RParen 2768:2769
Newline 2769:2770
Ident 2774:2781 text="println"
LParen 2781:2782
Str 2782:2830 T("  at least MIN_OBJECT: ") E[Ident 2807:2819 text="abiSizeWords"; LParen 2819:2820; Number 2820:2821 text="0" suf="" isf=0 int=0; RParen 2821:2822; EqEq 2823:2825; Number 2826:2828 text="32" suf="" isf=0 int=32; Eof 2829:2829]
RParen 2830:2831
Newline 2831:2832
Newline 2832:2833
Ident 2837:2844 text="println"
LParen 2844:2845
Str 2845:2884 T("== class_new clamps a low class id ==")
RParen 2884:2885
Newline 2885:2886
Var 2890:2893
Ident 2894:2899 text="probe"
Assign 2900:2901
Number 2902:2903 text="0" suf="" isf=0 int=0
Newline 2903:2904
While 2908:2913
LParen 2914:2915
Ident 2915:2920 text="probe"
Le 2921:2923
Number 2924:2926 text="11" suf="" isf=0 int=11
RParen 2926:2927
LBrace 2928:2929
Newline 2929:2930
Ident 2938:2945 text="println"
LParen 2945:2946
Str 2946:3009 T("  ask=") E[Ident 2954:2959 text="probe"; Eof 2960:2960] T(" -> ") E[Ident 2965:2969 text="word"; LParen 2969:2970; Ident 2970:2981 text="abiClassNew"; LParen 2981:2982; Ident 2982:2987 text="probe"; Comma 2987:2988; Number 2989:2990 text="1" suf="" isf=0 int=1; RParen 2990:2991; Comma 2991:2992; Ident 2993:3006 text="CLASS_ID_WORD"; RParen 3006:3007; Eof 3008:3008]
RParen 3009:3010
Newline 3010:3011
Ident 3019:3024 text="probe"
Assign 3025:3026
Ident 3027:3032 text="probe"
Plus 3033:3034
Number 3035:3036 text="1" suf="" isf=0 int=1
Newline 3036:3037
RBrace 3041:3042
Newline 3042:3043
Ident 3047:3054 text="println"
LParen 3054:3055
Str 3055:3112 T("  ask=300 -> ") E[Ident 3070:3074 text="word"; LParen 3074:3075; Ident 3075:3086 text="abiClassNew"; LParen 3086:3087; Number 3087:3090 text="300" suf="" isf=0 int=300; Comma 3090:3091; Number 3092:3093 text="1" suf="" isf=0 int=1; RParen 3093:3094; Comma 3094:3095; Ident 3096:3109 text="CLASS_ID_WORD"; RParen 3109:3110; Eof 3111:3111]
RParen 3112:3113
Newline 3113:3114
Ident 3118:3125 text="println"
LParen 3125:3126
Str 3126:3164 T("  user base=") E[Ident 3140:3162 text="PICKLE_CLASS_USER_BASE"; Eof 3163:3163]
RParen 3164:3165
Newline 3165:3166
Newline 3166:3167
Ident 3171:3178 text="println"
LParen 3178:3179
Str 3179:3225 T("== class_new clamps a negative slot count ==")
RParen 3225:3226
Newline 3226:3227
Let 3231:3234
Ident 3235:3238 text="neg"
Assign 3239:3240
Ident 3241:3252 text="abiClassNew"
LParen 3252:3253
Number 3253:3255 text="10" suf="" isf=0 int=10
Comma 3255:3256
Number 3257:3258 text="0" suf="" isf=0 int=0
Minus 3259:3260
Number 3261:3262 text="1" suf="" isf=0 int=1
RParen 3262:3263
Newline 3263:3264
Ident 3268:3275 text="println"
LParen 3275:3276
Str 3276:3337 T("  size=") E[Ident 3285:3289 text="word"; LParen 3289:3290; Ident 3290:3293 text="neg"; Comma 3293:3294; Ident 3295:3304 text="SIZE_WORD"; RParen 3304:3305; Eof 3306:3306] T(" id=") E[Ident 3311:3315 text="word"; LParen 3315:3316; Ident 3316:3319 text="neg"; Comma 3319:3320; Ident 3321:3334 text="CLASS_ID_WORD"; RParen 3334:3335; Eof 3336:3336]
RParen 3337:3338
Newline 3338:3339
Newline 3339:3340
Ident 3344:3351 text="println"
LParen 3351:3352
Str 3352:3408 T("== fields are zeroed, not left as allocator garbage ==")
RParen 3408:3409
Newline 3409:3410
Let 3414:3417
Ident 3418:3422 text="four"
Assign 3423:3424
Ident 3425:3436 text="abiClassNew"
LParen 3436:3437
Number 3437:3439 text="10" suf="" isf=0 int=10
Comma 3439:3440
Number 3441:3442 text="4" suf="" isf=0 int=4
RParen 3442:3443
Newline 3443:3444
Var 3448:3451
Ident 3452:3453 text="i"
Assign 3454:3455
Number 3456:3457 text="0" suf="" isf=0 int=0
Newline 3457:3458
While 3462:3467
LParen 3468:3469
Ident 3469:3470 text="i"
Lt 3471:3472
Number 3473:3474 text="4" suf="" isf=0 int=4
RParen 3474:3475
LBrace 3476:3477
Newline 3477:3478
Ident 3486:3493 text="println"
LParen 3493:3494
Str 3494:3533 T("  slot") E[Ident 3502:3503 text="i"; Eof 3504:3504] T("=") E[Ident 3506:3510 text="word"; LParen 3510:3511; Ident 3511:3515 text="four"; Comma 3515:3516; Ident 3517:3526 text="SLOT_WORD"; Plus 3527:3528; Ident 3529:3530 text="i"; RParen 3530:3531; Eof 3532:3532]
RParen 3533:3534
Newline 3534:3535
Ident 3543:3544 text="i"
Assign 3545:3546
Ident 3547:3548 text="i"
Plus 3549:3550
Number 3551:3552 text="1" suf="" isf=0 int=1
Newline 3552:3553
RBrace 3557:3558
Newline 3558:3559
Newline 3559:3560
Ident 3564:3571 text="println"
LParen 3571:3572
Str 3572:3605 T("== slot set / get round-trip ==")
RParen 3605:3606
Newline 3606:3607
Let 3611:3614
Ident 3615:3618 text="obj"
Assign 3619:3620
Ident 3621:3632 text="abiClassNew"
LParen 3632:3633
Number 3633:3635 text="10" suf="" isf=0 int=10
Comma 3635:3636
Number 3637:3638 text="3" suf="" isf=0 int=3
RParen 3638:3639
Newline 3639:3640
Let 3644:3647
Ident 3648:3650 text="v7"
Assign 3651:3652
Ident 3653:3662 text="abiBoxI64"
LParen 3662:3663
Number 3663:3664 text="7" suf="" isf=0 int=7
RParen 3664:3665
Newline 3665:3666
Let 3670:3673
Ident 3674:3676 text="vs"
Assign 3677:3678
Ident 3679:3693 text="abiStrFromByte"
LParen 3693:3694
Number 3694:3696 text="65" suf="" isf=0 int=65
RParen 3696:3697
Newline 3697:3698
Ident 3702:3715 text="abiObjSlotSet"
LParen 3715:3716
Ident 3716:3719 text="obj"
Comma 3719:3720
Number 3721:3722 text="0" suf="" isf=0 int=0
Comma 3722:3723
Ident 3724:3726 text="v7"
RParen 3726:3727
Newline 3727:3728
Ident 3732:3745 text="abiObjSlotSet"
LParen 3745:3746
Ident 3746:3749 text="obj"
Comma 3749:3750
Number 3751:3752 text="2" suf="" isf=0 int=2
Comma 3752:3753
Ident 3754:3756 text="vs"
RParen 3756:3757
Newline 3757:3758
Ident 3762:3769 text="println"
LParen 3769:3770
Str 3770:3841 T("  slot0 same address: ") E[LParen 3794:3795; Ident 3795:3808 text="abiObjSlotGet"; LParen 3808:3809; Ident 3809:3812 text="obj"; Comma 3812:3813; Number 3814:3815 text="0" suf="" isf=0 int=0; RParen 3815:3816; As 3817:3819; Ident 3820:3823 text="int"; RParen 3823:3824; EqEq 3825:3827; LParen 3828:3829; Ident 3829:3831 text="v7"; As 3832:3834; Ident 3835:3838 text="int"; RParen 3838:3839; Eof 3840:3840]
RParen 3841:3842
Newline 3842:3843
Ident 3847:3854 text="println"
LParen 3854:3855
Str 3855:3908 T("  slot1 null: ") E[LParen 3871:3872; Ident 3872:3885 text="abiObjSlotGet"; LParen 3885:3886; Ident 3886:3889 text="obj"; Comma 3889:3890; Number 3891:3892 text="1" suf="" isf=0 int=1; RParen 3892:3893; As 3894:3896; Ident 3897:3900 text="int"; RParen 3900:3901; EqEq 3902:3904; Number 3905:3906 text="0" suf="" isf=0 int=0; Eof 3907:3907]
RParen 3908:3909
Newline 3909:3910
Ident 3914:3921 text="println"
LParen 3921:3922
Str 3922:3993 T("  slot2 same address: ") E[LParen 3946:3947; Ident 3947:3960 text="abiObjSlotGet"; LParen 3960:3961; Ident 3961:3964 text="obj"; Comma 3964:3965; Number 3966:3967 text="2" suf="" isf=0 int=2; RParen 3967:3968; As 3969:3971; Ident 3972:3975 text="int"; RParen 3975:3976; EqEq 3977:3979; LParen 3980:3981; Ident 3981:3983 text="vs"; As 3984:3986; Ident 3987:3990 text="int"; RParen 3990:3991; Eof 3992:3992]
RParen 3993:3994
Newline 3994:3995
Ident 3999:4006 text="println"
LParen 4006:4007
Str 4007:4075 T("  slot2 points at a string of len ") E[Ident 4043:4047 text="word"; LParen 4047:4048; Ident 4048:4061 text="abiObjSlotGet"; LParen 4061:4062; Ident 4062:4065 text="obj"; Comma 4065:4066; Number 4067:4068 text="2" suf="" isf=0 int=2; RParen 4068:4069; Comma 4069:4070; Number 4071:4072 text="3" suf="" isf=0 int=3; RParen 4072:4073; Eof 4074:4074]
RParen 4075:4076
Newline 4076:4077
Newline 4077:4078
Ident 4082:4089 text="println"
LParen 4089:4090
Str 4090:4139 T("== the bound is derived from the stored size ==")
RParen 4139:4140
Newline 4140:4141
Newline 4219:4220
Ident 4224:4231 text="println"
LParen 4231:4232
Str 4232:4296 T("  index 2 ok:  ") E[LParen 4249:4250; Ident 4250:4263 text="abiObjSlotGet"; LParen 4263:4264; Ident 4264:4267 text="obj"; Comma 4267:4268; Number 4269:4270 text="2" suf="" isf=0 int=2; RParen 4270:4271; As 4272:4274; Ident 4275:4278 text="int"; RParen 4278:4279; EqEq 4280:4282; LParen 4283:4284; Ident 4284:4286 text="vs"; As 4287:4289; Ident 4290:4293 text="int"; RParen 4293:4294; Eof 4295:4295]
RParen 4296:4297
Newline 4297:4298
Ident 4302:4309 text="println"
LParen 4309:4310
Str 4310:4365 T("  index 3 null: ") E[LParen 4328:4329; Ident 4329:4342 text="abiObjSlotGet"; LParen 4342:4343; Ident 4343:4346 text="obj"; Comma 4346:4347; Number 4348:4349 text="3" suf="" isf=0 int=3; RParen 4349:4350; As 4351:4353; Ident 4354:4357 text="int"; RParen 4357:4358; EqEq 4359:4361; Number 4362:4363 text="0" suf="" isf=0 int=0; Eof 4364:4364]
RParen 4365:4366
Newline 4366:4367
Ident 4371:4378 text="println"
LParen 4378:4379
Str 4379:4438 T("  index 100 null: ") E[LParen 4399:4400; Ident 4400:4413 text="abiObjSlotGet"; LParen 4413:4414; Ident 4414:4417 text="obj"; Comma 4417:4418; Number 4419:4422 text="100" suf="" isf=0 int=100; RParen 4422:4423; As 4424:4426; Ident 4427:4430 text="int"; RParen 4430:4431; EqEq 4432:4434; Number 4435:4436 text="0" suf="" isf=0 int=0; Eof 4437:4437]
RParen 4438:4439
Newline 4439:4440
Ident 4444:4451 text="println"
LParen 4451:4452
Str 4452:4512 T("  index -1 null: ") E[LParen 4471:4472; Ident 4472:4485 text="abiObjSlotGet"; LParen 4485:4486; Ident 4486:4489 text="obj"; Comma 4489:4490; Number 4491:4492 text="0" suf="" isf=0 int=0; Minus 4493:4494; Number 4495:4496 text="1" suf="" isf=0 int=1; RParen 4496:4497; As 4498:4500; Ident 4501:4504 text="int"; RParen 4504:4505; EqEq 4506:4508; Number 4509:4510 text="0" suf="" isf=0 int=0; Eof 4511:4511]
RParen 4512:4513
Newline 4513:4514
Newline 4514:4515
Ident 4519:4526 text="println"
LParen 4526:4527
Str 4527:4572 T("== out-of-range writes are silent no-ops ==")
RParen 4572:4573
Newline 4573:4574
Let 4578:4581
Ident 4582:4587 text="guard"
Assign 4588:4589
Ident 4590:4601 text="abiClassNew"
LParen 4601:4602
Number 4602:4604 text="10" suf="" isf=0 int=10
Comma 4604:4605
Number 4606:4607 text="2" suf="" isf=0 int=2
RParen 4607:4608
Newline 4608:4609
Ident 4613:4626 text="abiObjSlotSet"
LParen 4626:4627
Ident 4627:4632 text="guard"
Comma 4632:4633
Number 4634:4636 text="99" suf="" isf=0 int=99
Comma 4636:4637
Ident 4638:4640 text="v7"
RParen 4640:4641
Newline 4641:4642
Ident 4646:4659 text="abiObjSlotSet"
LParen 4659:4660
Ident 4660:4665 text="guard"
Comma 4665:4666
Number 4667:4668 text="0" suf="" isf=0 int=0
Minus 4669:4670
Number 4671:4672 text="1" suf="" isf=0 int=1
Comma 4672:4673
Ident 4674:4676 text="v7"
RParen 4676:4677
Newline 4677:4678
Ident 4682:4689 text="println"
LParen 4689:4690
Str 4690:4751 T("  slot0 still null: ") E[LParen 4712:4713; Ident 4713:4726 text="abiObjSlotGet"; LParen 4726:4727; Ident 4727:4732 text="guard"; Comma 4732:4733; Number 4734:4735 text="0" suf="" isf=0 int=0; RParen 4735:4736; As 4737:4739; Ident 4740:4743 text="int"; RParen 4743:4744; EqEq 4745:4747; Number 4748:4749 text="0" suf="" isf=0 int=0; Eof 4750:4750]
RParen 4751:4752
Newline 4752:4753
Newline 4753:4754
Ident 4758:4765 text="println"
LParen 4765:4766
Str 4766:4812 T("== a zero-field class still admits slot 0 ==")
RParen 4812:4813
Newline 4813:4814
Newline 4892:4893
Newline 4967:4968
Newline 5013:5014
Newline 5020:5021
Newline 5100:5101
Newline 5176:5177
Newline 5254:5255
Newline 5332:5333
Newline 5414:5415
Let 5419:5422
Ident 5423:5427 text="zero"
Assign 5428:5429
Ident 5430:5441 text="abiClassNew"
LParen 5441:5442
Number 5442:5444 text="10" suf="" isf=0 int=10
Comma 5444:5445
Number 5446:5447 text="0" suf="" isf=0 int=0
RParen 5447:5448
Newline 5448:5449
Ident 5453:5460 text="println"
LParen 5460:5461
Str 5461:5493 T("  size=") E[Ident 5470:5474 text="word"; LParen 5474:5475; Ident 5475:5479 text="zero"; Comma 5479:5480; Ident 5481:5490 text="SIZE_WORD"; RParen 5490:5491; Eof 5492:5492]
RParen 5493:5494
Newline 5494:5495
Ident 5499:5506 text="println"
LParen 5506:5507
Str 5507:5574 T("  slots from that size=") E[Ident 5532:5549 text="slotCountFromSize"; LParen 5549:5550; Ident 5550:5554 text="word"; LParen 5554:5555; Ident 5555:5559 text="zero"; Comma 5559:5560; Ident 5561:5570 text="SIZE_WORD"; RParen 5570:5571; RParen 5571:5572; Eof 5573:5573]
RParen 5574:5575
Newline 5575:5576
Let 5580:5583
Ident 5584:5586 text="vz"
Assign 5587:5588
Ident 5589:5598 text="abiBoxI64"
LParen 5598:5599
Number 5599:5601 text="11" suf="" isf=0 int=11
RParen 5601:5602
Newline 5602:5603
Ident 5607:5620 text="abiObjSlotSet"
LParen 5620:5621
Ident 5621:5625 text="zero"
Comma 5625:5626
Number 5627:5628 text="0" suf="" isf=0 int=0
Comma 5628:5629
Ident 5630:5632 text="vz"
RParen 5632:5633
Newline 5633:5634
Ident 5638:5645 text="println"
LParen 5645:5646
Str 5646:5727 T("  slot0 writable and readable: ") E[LParen 5679:5680; Ident 5680:5693 text="abiObjSlotGet"; LParen 5693:5694; Ident 5694:5698 text="zero"; Comma 5698:5699; Number 5700:5701 text="0" suf="" isf=0 int=0; RParen 5701:5702; As 5703:5705; Ident 5706:5709 text="int"; RParen 5709:5710; EqEq 5711:5713; LParen 5714:5715; Ident 5715:5717 text="vz"; As 5718:5720; Ident 5721:5724 text="int"; RParen 5724:5725; Eof 5726:5726]
RParen 5727:5728
Newline 5728:5729
Ident 5733:5740 text="println"
LParen 5740:5741
Str 5741:5795 T("  slot1 null: ") E[LParen 5757:5758; Ident 5758:5771 text="abiObjSlotGet"; LParen 5771:5772; Ident 5772:5776 text="zero"; Comma 5776:5777; Number 5778:5779 text="1" suf="" isf=0 int=1; RParen 5779:5780; As 5781:5783; Ident 5784:5787 text="int"; RParen 5787:5788; EqEq 5789:5791; Number 5792:5793 text="0" suf="" isf=0 int=0; Eof 5794:5794]
RParen 5795:5796
Newline 5796:5797
Ident 5801:5814 text="abiObjSlotSet"
LParen 5814:5815
Ident 5815:5819 text="zero"
Comma 5819:5820
Number 5821:5822 text="1" suf="" isf=0 int=1
Comma 5822:5823
Ident 5824:5826 text="vz"
RParen 5826:5827
Newline 5827:5828
Ident 5832:5839 text="println"
LParen 5839:5840
Str 5840:5909 T("  slot1 write still ignored: ") E[LParen 5871:5872; Ident 5872:5885 text="abiObjSlotGet"; LParen 5885:5886; Ident 5886:5890 text="zero"; Comma 5890:5891; Number 5892:5893 text="1" suf="" isf=0 int=1; RParen 5893:5894; As 5895:5897; Ident 5898:5901 text="int"; RParen 5901:5902; EqEq 5903:5905; Number 5906:5907 text="0" suf="" isf=0 int=0; Eof 5908:5908]
RParen 5909:5910
Newline 5910:5911
Newline 5911:5912
Ident 5916:5923 text="println"
LParen 5923:5924
Str 5924:5986 T("== zero- and one-field classes are size-indistinguishable ==")
RParen 5986:5987
Newline 5987:5988
Ident 5992:5999 text="println"
LParen 5999:6000
Str 6000:6097 T("  size(0)=") E[Ident 6012:6024 text="abiSizeWords"; LParen 6024:6025; Number 6025:6026 text="0" suf="" isf=0 int=0; RParen 6026:6027; Eof 6028:6028] T(" size(1)=") E[Ident 6038:6050 text="abiSizeWords"; LParen 6050:6051; Number 6051:6052 text="1" suf="" isf=0 int=1; RParen 6052:6053; Eof 6054:6054] T(" same=") E[Ident 6061:6073 text="abiSizeWords"; LParen 6073:6074; Number 6074:6075 text="0" suf="" isf=0 int=0; RParen 6075:6076; EqEq 6077:6079; Ident 6080:6092 text="abiSizeWords"; LParen 6092:6093; Number 6093:6094 text="1" suf="" isf=0 int=1; RParen 6094:6095; Eof 6096:6096]
RParen 6097:6098
Newline 6098:6099
Newline 6099:6100
Ident 6104:6111 text="println"
LParen 6111:6112
Str 6112:6142 T("== a null object is inert ==")
RParen 6142:6143
Newline 6143:6144
Let 6148:6151
Ident 6152:6155 text="nil"
Assign 6156:6157
Number 6158:6159 text="0" suf="" isf=0 int=0
As 6160:6162
Star 6163:6164
Ident 6164:6167 text="int"
Newline 6167:6168
Ident 6172:6185 text="abiObjSlotSet"
LParen 6185:6186
Ident 6186:6189 text="nil"
Comma 6189:6190
Number 6191:6192 text="0" suf="" isf=0 int=0
Comma 6192:6193
Ident 6194:6196 text="v7"
RParen 6196:6197
Newline 6197:6198
Ident 6202:6209 text="println"
LParen 6209:6210
Str 6210:6267 T("  read from null: ") E[LParen 6230:6231; Ident 6231:6244 text="abiObjSlotGet"; LParen 6244:6245; Ident 6245:6248 text="nil"; Comma 6248:6249; Number 6250:6251 text="0" suf="" isf=0 int=0; RParen 6251:6252; As 6253:6255; Ident 6256:6259 text="int"; RParen 6259:6260; EqEq 6261:6263; Number 6264:6265 text="0" suf="" isf=0 int=0; Eof 6266:6266]
RParen 6267:6268
Newline 6268:6269
Ident 6273:6280 text="println"
LParen 6280:6281
Str 6281:6346 T("  read index 5 from null: ") E[LParen 6309:6310; Ident 6310:6323 text="abiObjSlotGet"; LParen 6323:6324; Ident 6324:6327 text="nil"; Comma 6327:6328; Number 6329:6330 text="5" suf="" isf=0 int=5; RParen 6330:6331; As 6332:6334; Ident 6335:6338 text="int"; RParen 6338:6339; EqEq 6340:6342; Number 6343:6344 text="0" suf="" isf=0 int=0; Eof 6345:6345]
RParen 6346:6347
Newline 6347:6348
Newline 6348:6349
Ident 6353:6360 text="println"
LParen 6360:6361
Str 6361:6397 T("== instances do not share slots ==")
RParen 6397:6398
Newline 6398:6399
Let 6403:6406
Ident 6407:6408 text="a"
Assign 6409:6410
Ident 6411:6422 text="abiClassNew"
LParen 6422:6423
Number 6423:6425 text="10" suf="" isf=0 int=10
Comma 6425:6426
Number 6427:6428 text="2" suf="" isf=0 int=2
RParen 6428:6429
Newline 6429:6430
Let 6434:6437
Ident 6438:6439 text="b"
Assign 6440:6441
Ident 6442:6453 text="abiClassNew"
LParen 6453:6454
Number 6454:6456 text="10" suf="" isf=0 int=10
Comma 6456:6457
Number 6458:6459 text="2" suf="" isf=0 int=2
RParen 6459:6460
Newline 6460:6461
Let 6465:6468
Ident 6469:6471 text="vb"
Assign 6472:6473
Ident 6474:6484 text="abiBoxBool"
LParen 6484:6485
True 6485:6489
RParen 6489:6490
Newline 6490:6491
Ident 6495:6508 text="abiObjSlotSet"
LParen 6508:6509
Ident 6509:6510 text="a"
Comma 6510:6511
Number 6512:6513 text="0" suf="" isf=0 int=0
Comma 6513:6514
Ident 6515:6517 text="vb"
RParen 6517:6518
Newline 6518:6519
Ident 6523:6530 text="println"
LParen 6530:6531
Str 6531:6592 T("  a holds it: ") E[LParen 6547:6548; Ident 6548:6561 text="abiObjSlotGet"; LParen 6561:6562; Ident 6562:6563 text="a"; Comma 6563:6564; Number 6565:6566 text="0" suf="" isf=0 int=0; RParen 6566:6567; As 6568:6570; Ident 6571:6574 text="int"; RParen 6574:6575; EqEq 6576:6578; LParen 6579:6580; Ident 6580:6582 text="vb"; As 6583:6585; Ident 6586:6589 text="int"; RParen 6589:6590; Eof 6591:6591]
RParen 6592:6593
Newline 6593:6594
Ident 6598:6605 text="println"
LParen 6605:6606
Str 6606:6657 T("  b does not: ") E[LParen 6622:6623; Ident 6623:6636 text="abiObjSlotGet"; LParen 6636:6637; Ident 6637:6638 text="b"; Comma 6638:6639; Number 6640:6641 text="0" suf="" isf=0 int=0; RParen 6641:6642; As 6643:6645; Ident 6646:6649 text="int"; RParen 6649:6650; EqEq 6651:6653; Number 6654:6655 text="0" suf="" isf=0 int=0; Eof 6656:6656]
RParen 6657:6658
Newline 6658:6659
Ident 6663:6670 text="println"
LParen 6670:6671
Str 6671:6719 T("  distinct objects: ") E[LParen 6693:6694; Ident 6694:6695 text="a"; As 6696:6698; Ident 6699:6702 text="int"; RParen 6702:6703; NotEq 6704:6706; LParen 6707:6708; Ident 6708:6709 text="b"; As 6710:6712; Ident 6713:6716 text="int"; RParen 6716:6717; Eof 6718:6718]
RParen 6719:6720
Newline 6720:6721
Newline 6721:6722
Ident 6726:6733 text="println"
LParen 6733:6734
Str 6734:6781 T("== overwriting a slot replaces the pointer ==")
RParen 6781:6782
Newline 6782:6783
Newline 6862:6863
Newline 6894:6895
Let 6899:6902
Ident 6903:6905 text="ow"
Assign 6906:6907
Ident 6908:6919 text="abiClassNew"
LParen 6919:6920
Number 6920:6922 text="10" suf="" isf=0 int=10
Comma 6922:6923
Number 6924:6925 text="1" suf="" isf=0 int=1
RParen 6925:6926
Newline 6926:6927
Let 6931:6934
Ident 6935:6938 text="vm1"
Assign 6939:6940
Ident 6941:6950 text="abiBoxI64"
LParen 6950:6951
Number 6951:6952 text="0" suf="" isf=0 int=0
Minus 6953:6954
Number 6955:6956 text="1" suf="" isf=0 int=1
RParen 6956:6957
Newline 6957:6958
Let 6962:6965
Ident 6966:6969 text="vp1"
Assign 6970:6971
Ident 6972:6981 text="abiBoxI64"
LParen 6981:6982
Number 6982:6983 text="1" suf="" isf=0 int=1
RParen 6983:6984
Newline 6984:6985
Ident 6989:7002 text="abiObjSlotSet"
LParen 7002:7003
Ident 7003:7005 text="ow"
Comma 7005:7006
Number 7007:7008 text="0" suf="" isf=0 int=0
Comma 7008:7009
Ident 7010:7013 text="vm1"
RParen 7013:7014
Newline 7014:7015
Ident 7019:7032 text="abiObjSlotSet"
LParen 7032:7033
Ident 7033:7035 text="ow"
Comma 7035:7036
Number 7037:7038 text="0" suf="" isf=0 int=0
Comma 7038:7039
Ident 7040:7043 text="vp1"
RParen 7043:7044
Newline 7044:7045
Ident 7049:7056 text="println"
LParen 7056:7057
Str 7057:7124 T("  now the second: ") E[LParen 7077:7078; Ident 7078:7091 text="abiObjSlotGet"; LParen 7091:7092; Ident 7092:7094 text="ow"; Comma 7094:7095; Number 7096:7097 text="0" suf="" isf=0 int=0; RParen 7097:7098; As 7099:7101; Ident 7102:7105 text="int"; RParen 7105:7106; EqEq 7107:7109; LParen 7110:7111; Ident 7111:7114 text="vp1"; As 7115:7117; Ident 7118:7121 text="int"; RParen 7121:7122; Eof 7123:7123]
RParen 7124:7125
Newline 7125:7126
Ident 7130:7137 text="println"
LParen 7137:7138
Str 7138:7204 T("  not the first: ") E[LParen 7157:7158; Ident 7158:7171 text="abiObjSlotGet"; LParen 7171:7172; Ident 7172:7174 text="ow"; Comma 7174:7175; Number 7176:7177 text="0" suf="" isf=0 int=0; RParen 7177:7178; As 7179:7181; Ident 7182:7185 text="int"; RParen 7185:7186; EqEq 7187:7189; LParen 7190:7191; Ident 7191:7194 text="vm1"; As 7195:7197; Ident 7198:7201 text="int"; RParen 7201:7202; Eof 7203:7203]
RParen 7204:7205
Newline 7205:7206
Newline 7206:7207
Ident 7211:7218 text="println"
LParen 7218:7219
Str 7219:7253 T("== storing null clears a slot ==")
RParen 7253:7254
Newline 7254:7255
Let 7259:7262
Ident 7263:7266 text="clr"
Assign 7267:7268
Ident 7269:7280 text="abiClassNew"
LParen 7280:7281
Number 7281:7283 text="10" suf="" isf=0 int=10
Comma 7283:7284
Number 7285:7286 text="1" suf="" isf=0 int=1
RParen 7286:7287
Newline 7287:7288
Ident 7292:7305 text="abiObjSlotSet"
LParen 7305:7306
Ident 7306:7309 text="clr"
Comma 7309:7310
Number 7311:7312 text="0" suf="" isf=0 int=0
Comma 7312:7313
Ident 7314:7316 text="vb"
RParen 7316:7317
Newline 7317:7318
Ident 7322:7335 text="abiObjSlotSet"
LParen 7335:7336
Ident 7336:7339 text="clr"
Comma 7339:7340
Number 7341:7342 text="0" suf="" isf=0 int=0
Comma 7342:7343
Number 7344:7345 text="0" suf="" isf=0 int=0
As 7346:7348
Star 7349:7350
Ident 7350:7353 text="int"
RParen 7353:7354
Newline 7354:7355
Ident 7359:7366 text="println"
LParen 7366:7367
Str 7367:7417 T("  cleared: ") E[LParen 7380:7381; Ident 7381:7394 text="abiObjSlotGet"; LParen 7394:7395; Ident 7395:7398 text="clr"; Comma 7398:7399; Number 7400:7401 text="0" suf="" isf=0 int=0; RParen 7401:7402; As 7403:7405; Ident 7406:7409 text="int"; RParen 7409:7410; EqEq 7411:7413; Number 7414:7415 text="0" suf="" isf=0 int=0; Eof 7416:7416]
RParen 7417:7418
Newline 7418:7419
Newline 7419:7420
Ident 7424:7431 text="println"
LParen 7431:7432
Str 7432:7455 T("== a wide instance ==")
RParen 7455:7456
Newline 7456:7457
Let 7461:7464
Ident 7465:7469 text="wide"
Assign 7470:7471
Ident 7472:7483 text="abiClassNew"
LParen 7483:7484
Number 7484:7486 text="10" suf="" isf=0 int=10
Comma 7486:7487
Number 7488:7489 text="8" suf="" isf=0 int=8
RParen 7489:7490
Newline 7490:7491
Ident 7495:7502 text="println"
LParen 7502:7503
Str 7503:7584 T("  size=") E[Ident 7512:7516 text="word"; LParen 7516:7517; Ident 7517:7521 text="wide"; Comma 7521:7522; Ident 7523:7532 text="SIZE_WORD"; RParen 7532:7533; Eof 7534:7534] T(" slots=") E[Ident 7542:7559 text="slotCountFromSize"; LParen 7559:7560; Ident 7560:7564 text="word"; LParen 7564:7565; Ident 7565:7569 text="wide"; Comma 7569:7570; Ident 7571:7580 text="SIZE_WORD"; RParen 7580:7581; RParen 7581:7582; Eof 7583:7583]
RParen 7584:7585
Newline 7585:7586
Ident 7590:7603 text="abiObjSlotSet"
LParen 7603:7604
Ident 7604:7608 text="wide"
Comma 7608:7609
Number 7610:7611 text="7" suf="" isf=0 int=7
Comma 7611:7612
Ident 7613:7615 text="vb"
RParen 7615:7616
Newline 7616:7617
Ident 7621:7628 text="println"
LParen 7628:7629
Str 7629:7692 T("  slot7 set: ") E[LParen 7644:7645; Ident 7645:7658 text="abiObjSlotGet"; LParen 7658:7659; Ident 7659:7663 text="wide"; Comma 7663:7664; Number 7665:7666 text="7" suf="" isf=0 int=7; RParen 7666:7667; As 7668:7670; Ident 7671:7674 text="int"; RParen 7674:7675; EqEq 7676:7678; LParen 7679:7680; Ident 7680:7682 text="vb"; As 7683:7685; Ident 7686:7689 text="int"; RParen 7689:7690; Eof 7691:7691]
RParen 7692:7693
Newline 7693:7694
Ident 7698:7705 text="println"
LParen 7705:7706
Str 7706:7760 T("  slot8 null: ") E[LParen 7722:7723; Ident 7723:7736 text="abiObjSlotGet"; LParen 7736:7737; Ident 7737:7741 text="wide"; Comma 7741:7742; Number 7743:7744 text="8" suf="" isf=0 int=8; RParen 7744:7745; As 7746:7748; Ident 7749:7752 text="int"; RParen 7752:7753; EqEq 7754:7756; Number 7757:7758 text="0" suf="" isf=0 int=0; Eof 7759:7759]
RParen 7760:7761
Newline 7761:7762
RBrace 7762:7763
Eof 7763:7763
