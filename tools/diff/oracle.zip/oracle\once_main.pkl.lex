Newline 76:77
Newline 154:155
Newline 228:229
Newline 304:305
Newline 377:378
Newline 380:381
Newline 459:460
Newline 506:507
Newline 507:508
Fn 508:510
Ident 511:515 text="bump"
LParen 515:516
RParen 516:517
LBrace 518:519
Newline 519:520
Ident 524:531 text="println"
LParen 531:532
Str 532:542 T("init ran")
RParen 542:543
Newline 543:544
RBrace 544:545
Newline 545:546
Newline 546:547
Fn 547:549
Ident 550:554 text="main"
LParen 554:555
RParen 555:556
LBrace 557:558
Newline 558:559
Let 563:566
Ident 567:568 text="o"
Assign 569:570
Ident 571:579 text="once_new"
LParen 579:580
RParen 580:581
Newline 581:582
Newline 582:583
Newline 618:619
Ident 623:629 text="expect"
LParen 629:630
Ident 630:639 text="once_done"
LParen 639:640
Ident 640:641 text="o"
RParen 641:642
RParen 642:643
Dot 643:644
Ident 644:648 text="toBe"
LParen 648:649
False 649:654
RParen 654:655
Newline 655:656
Newline 656:657
Newline 706:707
Ident 711:717 text="expect"
LParen 717:718
Ident 718:726 text="once_run"
LParen 726:727
Ident 727:728 text="o"
Comma 728:729
Ident 730:734 text="bump"
RParen 734:735
RParen 735:736
Dot 736:737
Ident 737:741 text="toBe"
LParen 741:742
True 742:746
RParen 746:747
Newline 747:748
Ident 752:758 text="expect"
LParen 758:759
Ident 759:768 text="once_done"
LParen 768:769
Ident 769:770 text="o"
RParen 770:771
RParen 771:772
Dot 772:773
Ident 773:777 text="toBe"
LParen 777:778
True 778:782
RParen 782:783
Newline 783:784
Newline 784:785
Newline 857:858
Ident 862:868 text="expect"
LParen 868:869
Ident 869:877 text="once_run"
LParen 877:878
Ident 878:879 text="o"
Comma 879:880
Ident 881:885 text="bump"
RParen 885:886
RParen 886:887
Dot 887:888
Ident 888:892 text="toBe"
LParen 892:893
False 893:898
RParen 898:899
Newline 899:900
Ident 904:910 text="expect"
LParen 910:911
Ident 911:919 text="once_run"
LParen 919:920
Ident 920:921 text="o"
Comma 921:922
Ident 923:927 text="bump"
RParen 927:928
RParen 928:929
Dot 929:930
Ident 930:934 text="toBe"
LParen 934:935
False 935:940
RParen 940:941
Newline 941:942
Ident 946:952 text="expect"
LParen 952:953
Ident 953:962 text="once_done"
LParen 962:963
Ident 963:964 text="o"
RParen 964:965
RParen 965:966
Dot 966:967
Ident 967:971 text="toBe"
LParen 971:972
True 972:976
RParen 976:977
Newline 977:978
Newline 978:979
Newline 1027:1028
Let 1032:1035
Ident 1036:1037 text="p"
Assign 1038:1039
Ident 1040:1048 text="once_new"
LParen 1048:1049
RParen 1049:1050
Newline 1050:1051
Ident 1055:1061 text="expect"
LParen 1061:1062
Ident 1062:1071 text="once_done"
LParen 1071:1072
Ident 1072:1073 text="p"
RParen 1073:1074
RParen 1074:1075
Dot 1075:1076
Ident 1076:1080 text="toBe"
LParen 1080:1081
False 1081:1086
RParen 1086:1087
Newline 1087:1088
Ident 1092:1098 text="expect"
LParen 1098:1099
Ident 1099:1107 text="once_run"
LParen 1107:1108
Ident 1108:1109 text="p"
Comma 1109:1110
Ident 1111:1115 text="bump"
RParen 1115:1116
RParen 1116:1117
Dot 1117:1118
Ident 1118:1122 text="toBe"
LParen 1122:1123
True 1123:1127
RParen 1127:1128
Newline 1128:1129
Ident 1133:1139 text="expect"
LParen 1139:1140
Ident 1140:1149 text="once_done"
LParen 1149:1150
Ident 1150:1151 text="p"
RParen 1151:1152
RParen 1152:1153
Dot 1153:1154
Ident 1154:1158 text="toBe"
LParen 1158:1159
True 1159:1163
RParen 1163:1164
Newline 1164:1165
Ident 1169:1175 text="expect"
LParen 1175:1176
Ident 1176:1185 text="once_done"
LParen 1185:1186
Ident 1186:1187 text="o"
RParen 1187:1188
RParen 1188:1189
Dot 1189:1190
Ident 1190:1194 text="toBe"
LParen 1194:1195
True 1195:1199
RParen 1199:1200
Newline 1200:1201
Newline 1201:1202
Ident 1206:1213 text="println"
LParen 1213:1214
Str 1214:1223 T("once ok")
RParen 1223:1224
Newline 1224:1225
RBrace 1225:1226
Newline 1226:1227
Eof 1227:1227
