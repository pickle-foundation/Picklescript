Module 0:6
Ident 7:22 text="abi_expect_main"
Newline 22:23
Newline 23:24
Newline 92:93
Newline 144:145
Newline 196:197
Newline 199:200
Newline 279:280
Newline 352:353
Newline 428:429
Newline 507:508
Newline 578:579
Newline 581:582
Newline 660:661
Newline 739:740
Newline 817:818
Newline 898:899
Newline 977:978
Newline 1059:1060
Newline 1137:1138
Newline 1160:1161
Newline 1163:1164
Newline 1229:1230
Newline 1232:1233
Newline 1315:1316
Newline 1395:1396
Newline 1467:1468
Newline 1531:1532
Newline 1612:1613
Newline 1684:1685
Newline 1752:1753
Newline 1833:1834
Newline 1888:1889
Newline 1966:1967
Newline 1969:1970
Newline 2042:2043
Newline 2119:2120
Newline 2158:2159
Import 2159:2165
LBrace 2166:2167
Ident 2168:2182 text="abiExpectObjEq"
Comma 2182:2183
Ident 2184:2204 text="abiExpectStrContains"
RBrace 2205:2206
From 2207:2211
Ident 2212:2219 text="runtime"
Dot 2219:2220
Ident 2220:2230 text="abi_expect"
Newline 2230:2231
Import 2231:2237
LBrace 2238:2239
Ident 2240:2254 text="abiStrFromByte"
Comma 2254:2255
Ident 2256:2268 text="abiStrConcat"
Comma 2268:2269
Ident 2270:2284 text="abiStrFromList"
RBrace 2285:2286
From 2287:2291
Ident 2292:2299 text="runtime"
Dot 2299:2300
Ident 2300:2310 text="abi_string"
Newline 2310:2311
Import 2311:2317
LBrace 2318:2319
Ident 2320:2330 text="abiListNew"
Comma 2330:2331
Ident 2332:2343 text="abiListPush"
RBrace 2344:2345
From 2346:2350
Ident 2351:2358 text="runtime"
Dot 2358:2359
Ident 2359:2367 text="abi_list"
Newline 2367:2368
Import 2368:2374
LBrace 2375:2376
Ident 2377:2386 text="abiBoxI64"
Comma 2386:2387
Ident 2388:2398 text="abiBoxBool"
Comma 2398:2399
Ident 2400:2410 text="abiBoxChar"
RBrace 2411:2412
From 2413:2417
Ident 2418:2425 text="runtime"
Dot 2425:2426
Ident 2426:2433 text="abi_box"
Newline 2433:2434
Newline 2434:2435
Fn 2435:2437
Ident 2438:2440 text="b1"
LParen 2440:2441
Ident 2441:2442 text="a"
Colon 2442:2443
Ident 2444:2447 text="int"
RParen 2447:2448
Arrow 2449:2451
Star 2452:2453
Ident 2453:2456 text="int"
LBrace 2457:2458
Newline 2458:2459
Return 2463:2469
Ident 2470:2484 text="abiStrFromByte"
LParen 2484:2485
Ident 2485:2486 text="a"
RParen 2486:2487
Newline 2487:2488
RBrace 2488:2489
Newline 2489:2490
Newline 2490:2491
Fn 2491:2493
Ident 2494:2496 text="b2"
LParen 2496:2497
Ident 2497:2498 text="a"
Colon 2498:2499
Ident 2500:2503 text="int"
Comma 2503:2504
Ident 2505:2506 text="c"
Colon 2506:2507
Ident 2508:2511 text="int"
RParen 2511:2512
Arrow 2513:2515
Star 2516:2517
Ident 2517:2520 text="int"
LBrace 2521:2522
Newline 2522:2523
Return 2527:2533
Ident 2534:2546 text="abiStrConcat"
LParen 2546:2547
Ident 2547:2561 text="abiStrFromByte"
LParen 2561:2562
Ident 2562:2563 text="a"
RParen 2563:2564
Comma 2564:2565
Ident 2566:2580 text="abiStrFromByte"
LParen 2580:2581
Ident 2581:2582 text="c"
RParen 2582:2583
RParen 2583:2584
Newline 2584:2585
RBrace 2585:2586
Newline 2586:2587
Newline 2587:2588
Fn 2588:2590
Ident 2591:2593 text="b3"
LParen 2593:2594
Ident 2594:2595 text="a"
Colon 2595:2596
Ident 2597:2600 text="int"
Comma 2600:2601
Ident 2602:2603 text="c"
Colon 2603:2604
Ident 2605:2608 text="int"
Comma 2608:2609
Ident 2610:2611 text="d"
Colon 2611:2612
Ident 2613:2616 text="int"
RParen 2616:2617
Arrow 2618:2620
Star 2621:2622
Ident 2622:2625 text="int"
LBrace 2626:2627
Newline 2627:2628
Return 2632:2638
Ident 2639:2651 text="abiStrConcat"
LParen 2651:2652
Ident 2652:2654 text="b2"
LParen 2654:2655
Ident 2655:2656 text="a"
Comma 2656:2657
Ident 2658:2659 text="c"
RParen 2659:2660
Comma 2660:2661
Ident 2662:2676 text="abiStrFromByte"
LParen 2676:2677
Ident 2677:2678 text="d"
RParen 2678:2679
RParen 2679:2680
Newline 2680:2681
RBrace 2681:2682
Newline 2682:2683
Newline 2683:2684
Fn 2684:2686
Ident 2687:2689 text="b0"
LParen 2689:2690
RParen 2690:2691
Arrow 2692:2694
Star 2695:2696
Ident 2696:2699 text="int"
LBrace 2700:2701
Newline 2701:2702
Return 2706:2712
Ident 2713:2727 text="abiStrFromList"
LParen 2727:2728
Ident 2728:2738 text="abiListNew"
LParen 2738:2739
Number 2739:2740 text="0" suf="" isf=0 int=0
RParen 2740:2741
RParen 2741:2742
Newline 2742:2743
RBrace 2743:2744
Newline 2744:2745
Newline 2745:2746
Fn 2746:2748
Ident 2749:2754 text="list2"
LParen 2754:2755
Ident 2755:2756 text="x"
Colon 2756:2757
Star 2758:2759
Ident 2759:2762 text="int"
Comma 2762:2763
Ident 2764:2765 text="y"
Colon 2765:2766
Star 2767:2768
Ident 2768:2771 text="int"
RParen 2771:2772
Arrow 2773:2775
Star 2776:2777
Ident 2777:2780 text="int"
LBrace 2781:2782
Newline 2782:2783
Let 2787:2790
Ident 2791:2792 text="l"
Assign 2793:2794
Ident 2795:2805 text="abiListNew"
LParen 2805:2806
Number 2806:2807 text="2" suf="" isf=0 int=2
RParen 2807:2808
Newline 2808:2809
Ident 2813:2824 text="abiListPush"
LParen 2824:2825
Ident 2825:2826 text="l"
Comma 2826:2827
Ident 2828:2829 text="x"
RParen 2829:2830
Newline 2830:2831
Ident 2835:2846 text="abiListPush"
LParen 2846:2847
Ident 2847:2848 text="l"
Comma 2848:2849
Ident 2850:2851 text="y"
RParen 2851:2852
Newline 2852:2853
Return 2857:2863
Ident 2864:2865 text="l"
Newline 2865:2866
RBrace 2866:2867
Newline 2867:2868
Newline 2868:2869
Fn 2869:2871
Ident 2872:2876 text="main"
LParen 2876:2877
RParen 2877:2878
LBrace 2879:2880
Newline 2880:2881
Ident 2885:2892 text="println"
LParen 2892:2893
Str 2893:2924 T("== obj_eq: null is a value ==")
RParen 2924:2925
Newline 2925:2926
Ident 2930:2937 text="println"
LParen 2937:2938
Str 2938:2996 T("  null == null -> ") E[Ident 2958:2972 text="abiExpectObjEq"; LParen 2972:2973; Number 2973:2974 text="0" suf="" isf=0 int=0; As 2975:2977; Star 2978:2979; Ident 2979:2982 text="int"; Comma 2982:2983; Number 2984:2985 text="0" suf="" isf=0 int=0; As 2986:2988; Star 2989:2990; Ident 2990:2993 text="int"; RParen 2993:2994; Eof 2995:2995]
RParen 2996:2997
Newline 2997:2998
Ident 3002:3009 text="println"
LParen 3009:3010
Str 3010:3065 T("  null == str  -> ") E[Ident 3030:3044 text="abiExpectObjEq"; LParen 3044:3045; Number 3045:3046 text="0" suf="" isf=0 int=0; As 3047:3049; Star 3050:3051; Ident 3051:3054 text="int"; Comma 3054:3055; Ident 3056:3058 text="b1"; LParen 3058:3059; Number 3059:3061 text="97" suf="" isf=0 int=97; RParen 3061:3062; RParen 3062:3063; Eof 3064:3064]
RParen 3065:3066
Newline 3066:3067
Ident 3071:3078 text="println"
LParen 3078:3079
Str 3079:3134 T("  str == null  -> ") E[Ident 3099:3113 text="abiExpectObjEq"; LParen 3113:3114; Ident 3114:3116 text="b1"; LParen 3116:3117; Number 3117:3119 text="97" suf="" isf=0 int=97; RParen 3119:3120; Comma 3120:3121; Number 3122:3123 text="0" suf="" isf=0 int=0; As 3124:3126; Star 3127:3128; Ident 3128:3131 text="int"; RParen 3131:3132; Eof 3133:3133]
RParen 3134:3135
Newline 3135:3136
Newline 3136:3137
Ident 3141:3148 text="println"
LParen 3148:3149
Str 3149:3173 T("== obj_eq: identity ==")
RParen 3173:3174
Newline 3174:3175
Let 3179:3182
Ident 3183:3184 text="s"
Assign 3185:3186
Ident 3187:3189 text="b3"
LParen 3189:3190
Number 3190:3192 text="97" suf="" isf=0 int=97
Comma 3192:3193
Number 3194:3196 text="98" suf="" isf=0 int=98
Comma 3196:3197
Number 3198:3200 text="99" suf="" isf=0 int=99
RParen 3200:3201
Newline 3201:3202
Ident 3206:3213 text="println"
LParen 3213:3214
Str 3214:3257 T("  self == self  -> ") E[Ident 3235:3249 text="abiExpectObjEq"; LParen 3249:3250; Ident 3250:3251 text="s"; Comma 3251:3252; Ident 3253:3254 text="s"; RParen 3254:3255; Eof 3256:3256]
RParen 3257:3258
Newline 3258:3259
Let 3263:3266
Ident 3267:3268 text="t"
Assign 3269:3270
Ident 3271:3273 text="b3"
LParen 3273:3274
Number 3274:3276 text="97" suf="" isf=0 int=97
Comma 3276:3277
Number 3278:3280 text="98" suf="" isf=0 int=98
Comma 3280:3281
Number 3282:3284 text="99" suf="" isf=0 int=99
RParen 3284:3285
Newline 3285:3286
Ident 3290:3297 text="println"
LParen 3297:3298
Str 3298:3360 T("  equal contents, distinct objects -> ") E[Ident 3338:3352 text="abiExpectObjEq"; LParen 3352:3353; Ident 3353:3354 text="s"; Comma 3354:3355; Ident 3356:3357 text="t"; RParen 3357:3358; Eof 3359:3359]
RParen 3360:3361
Newline 3361:3362
Ident 3366:3373 text="println"
LParen 3373:3374
Str 3374:3418 T("  same address? ") E[LParen 3392:3393; Ident 3393:3394 text="s"; As 3395:3397; Ident 3398:3401 text="int"; RParen 3401:3402; EqEq 3403:3405; LParen 3406:3407; Ident 3407:3408 text="t"; As 3409:3411; Ident 3412:3415 text="int"; RParen 3415:3416; Eof 3417:3417]
RParen 3418:3419
Newline 3419:3420
Newline 3420:3421
Ident 3425:3432 text="println"
LParen 3432:3433
Str 3433:3467 T("== obj_eq: strings by content ==")
RParen 3467:3468
Newline 3468:3469
Ident 3473:3480 text="println"
LParen 3480:3481
Str 3481:3547 T("  abc == abc -> ") E[Ident 3499:3513 text="abiExpectObjEq"; LParen 3513:3514; Ident 3514:3516 text="b3"; LParen 3516:3517; Number 3517:3519 text="97" suf="" isf=0 int=97; Comma 3519:3520; Number 3521:3523 text="98" suf="" isf=0 int=98; Comma 3523:3524; Number 3525:3527 text="99" suf="" isf=0 int=99; RParen 3527:3528; Comma 3528:3529; Ident 3530:3532 text="b3"; LParen 3532:3533; Number 3533:3535 text="97" suf="" isf=0 int=97; Comma 3535:3536; Number 3537:3539 text="98" suf="" isf=0 int=98; Comma 3539:3540; Number 3541:3543 text="99" suf="" isf=0 int=99; RParen 3543:3544; RParen 3544:3545; Eof 3546:3546]
RParen 3547:3548
Newline 3548:3549
Let 3553:3556
Ident 3557:3560 text="abc"
Assign 3561:3562
Ident 3563:3565 text="b3"
LParen 3565:3566
Number 3566:3568 text="97" suf="" isf=0 int=97
Comma 3568:3569
Number 3570:3572 text="98" suf="" isf=0 int=98
Comma 3572:3573
Number 3574:3576 text="99" suf="" isf=0 int=99
RParen 3576:3577
Newline 3577:3578
Let 3582:3585
Ident 3586:3590 text="abcd"
Assign 3591:3592
Ident 3593:3605 text="abiStrConcat"
LParen 3605:3606
Ident 3606:3609 text="abc"
Comma 3609:3610
Ident 3611:3613 text="b1"
LParen 3613:3614
Number 3614:3617 text="100" suf="" isf=0 int=100
RParen 3617:3618
RParen 3618:3619
Newline 3619:3620
Ident 3624:3631 text="println"
LParen 3631:3632
Str 3632:3678 T("  abc vs abcd -> ") E[Ident 3651:3665 text="abiExpectObjEq"; LParen 3665:3666; Ident 3666:3669 text="abc"; Comma 3669:3670; Ident 3671:3675 text="abcd"; RParen 3675:3676; Eof 3677:3677]
RParen 3678:3679
Newline 3679:3680
Let 3684:3687
Ident 3688:3691 text="abz"
Assign 3692:3693
Ident 3694:3696 text="b3"
LParen 3696:3697
Number 3697:3699 text="97" suf="" isf=0 int=97
Comma 3699:3700
Number 3701:3703 text="98" suf="" isf=0 int=98
Comma 3703:3704
Number 3705:3708 text="122" suf="" isf=0 int=122
RParen 3708:3709
Newline 3709:3710
Ident 3714:3721 text="println"
LParen 3721:3722
Str 3722:3767 T("  abc vs abz  -> ") E[Ident 3741:3755 text="abiExpectObjEq"; LParen 3755:3756; Ident 3756:3759 text="abc"; Comma 3759:3760; Ident 3761:3764 text="abz"; RParen 3764:3765; Eof 3766:3766]
RParen 3767:3768
Newline 3768:3769
Ident 3773:3780 text="println"
LParen 3780:3781
Str 3781:3831 T("  empty == empty -> ") E[Ident 3803:3817 text="abiExpectObjEq"; LParen 3817:3818; Ident 3818:3820 text="b0"; LParen 3820:3821; RParen 3821:3822; Comma 3822:3823; Ident 3824:3826 text="b0"; LParen 3826:3827; RParen 3827:3828; RParen 3828:3829; Eof 3830:3830]
RParen 3831:3832
Newline 3832:3833
Newline 3833:3834
Ident 3838:3845 text="println"
LParen 3845:3846
Str 3846:3880 T("== obj_eq: lists element-wise ==")
RParen 3880:3881
Newline 3881:3882
Let 3886:3889
Ident 3890:3892 text="l1"
Assign 3893:3894
Ident 3895:3900 text="list2"
LParen 3900:3901
Ident 3901:3903 text="b1"
LParen 3903:3904
Number 3904:3906 text="97" suf="" isf=0 int=97
RParen 3906:3907
Comma 3907:3908
Ident 3909:3911 text="b1"
LParen 3911:3912
Number 3912:3914 text="98" suf="" isf=0 int=98
RParen 3914:3915
RParen 3915:3916
Newline 3916:3917
Let 3921:3924
Ident 3925:3927 text="l2"
Assign 3928:3929
Ident 3930:3935 text="list2"
LParen 3935:3936
Ident 3936:3938 text="b1"
LParen 3938:3939
Number 3939:3941 text="97" suf="" isf=0 int=97
RParen 3941:3942
Comma 3942:3943
Ident 3944:3946 text="b1"
LParen 3946:3947
Number 3947:3949 text="98" suf="" isf=0 int=98
RParen 3949:3950
RParen 3950:3951
Newline 3951:3952
Let 3956:3959
Ident 3960:3962 text="l3"
Assign 3963:3964
Ident 3965:3970 text="list2"
LParen 3970:3971
Ident 3971:3973 text="b1"
LParen 3973:3974
Number 3974:3976 text="97" suf="" isf=0 int=97
RParen 3976:3977
Comma 3977:3978
Ident 3979:3981 text="b1"
LParen 3981:3982
Number 3982:3984 text="99" suf="" isf=0 int=99
RParen 3984:3985
RParen 3985:3986
Newline 3986:3987
Ident 3991:3998 text="println"
LParen 3998:3999
Str 3999:4045 T("  [a b] == [a b] -> ") E[Ident 4021:4035 text="abiExpectObjEq"; LParen 4035:4036; Ident 4036:4038 text="l1"; Comma 4038:4039; Ident 4040:4042 text="l2"; RParen 4042:4043; Eof 4044:4044]
RParen 4045:4046
Newline 4046:4047
Ident 4051:4058 text="println"
LParen 4058:4059
Str 4059:4105 T("  [a b] == [a c] -> ") E[Ident 4081:4095 text="abiExpectObjEq"; LParen 4095:4096; Ident 4096:4098 text="l1"; Comma 4098:4099; Ident 4100:4102 text="l3"; RParen 4102:4103; Eof 4104:4104]
RParen 4105:4106
Newline 4106:4107
Let 4111:4114
Ident 4115:4117 text="l4"
Assign 4118:4119
Ident 4120:4125 text="list2"
LParen 4125:4126
Ident 4126:4128 text="b1"
LParen 4128:4129
Number 4129:4131 text="97" suf="" isf=0 int=97
RParen 4131:4132
Comma 4132:4133
Ident 4134:4136 text="b1"
LParen 4136:4137
Number 4137:4139 text="98" suf="" isf=0 int=98
RParen 4139:4140
RParen 4140:4141
Newline 4141:4142
Ident 4146:4157 text="abiListPush"
LParen 4157:4158
Ident 4158:4160 text="l4"
Comma 4160:4161
Ident 4162:4164 text="b1"
LParen 4164:4165
Number 4165:4167 text="99" suf="" isf=0 int=99
RParen 4167:4168
RParen 4168:4169
Newline 4169:4170
Ident 4174:4181 text="println"
LParen 4181:4182
Str 4182:4228 T("  len 2 vs len 3 -> ") E[Ident 4204:4218 text="abiExpectObjEq"; LParen 4218:4219; Ident 4219:4221 text="l1"; Comma 4221:4222; Ident 4223:4225 text="l4"; RParen 4225:4226; Eof 4227:4227]
RParen 4228:4229
Newline 4229:4230
Newline 4230:4231
Ident 4235:4242 text="println"
LParen 4242:4243
Str 4243:4288 T("== obj_eq: recurses through nested lists ==")
RParen 4288:4289
Newline 4289:4290
Let 4294:4297
Ident 4298:4300 text="n1"
Assign 4301:4302
Ident 4303:4308 text="list2"
LParen 4308:4309
Ident 4309:4314 text="list2"
LParen 4314:4315
Ident 4315:4317 text="b1"
LParen 4317:4318
Number 4318:4320 text="97" suf="" isf=0 int=97
RParen 4320:4321
Comma 4321:4322
Ident 4323:4325 text="b1"
LParen 4325:4326
Number 4326:4328 text="98" suf="" isf=0 int=98
RParen 4328:4329
RParen 4329:4330
Comma 4330:4331
Ident 4332:4334 text="b1"
LParen 4334:4335
Number 4335:4337 text="90" suf="" isf=0 int=90
RParen 4337:4338
RParen 4338:4339
Newline 4339:4340
Let 4344:4347
Ident 4348:4350 text="n2"
Assign 4351:4352
Ident 4353:4358 text="list2"
LParen 4358:4359
Ident 4359:4364 text="list2"
LParen 4364:4365
Ident 4365:4367 text="b1"
LParen 4367:4368
Number 4368:4370 text="97" suf="" isf=0 int=97
RParen 4370:4371
Comma 4371:4372
Ident 4373:4375 text="b1"
LParen 4375:4376
Number 4376:4378 text="98" suf="" isf=0 int=98
RParen 4378:4379
RParen 4379:4380
Comma 4380:4381
Ident 4382:4384 text="b1"
LParen 4384:4385
Number 4385:4387 text="90" suf="" isf=0 int=90
RParen 4387:4388
RParen 4388:4389
Newline 4389:4390
Let 4394:4397
Ident 4398:4400 text="n3"
Assign 4401:4402
Ident 4403:4408 text="list2"
LParen 4408:4409
Ident 4409:4414 text="list2"
LParen 4414:4415
Ident 4415:4417 text="b1"
LParen 4417:4418
Number 4418:4420 text="97" suf="" isf=0 int=97
RParen 4420:4421
Comma 4421:4422
Ident 4423:4425 text="b1"
LParen 4425:4426
Number 4426:4428 text="99" suf="" isf=0 int=99
RParen 4428:4429
RParen 4429:4430
Comma 4430:4431
Ident 4432:4434 text="b1"
LParen 4434:4435
Number 4435:4437 text="90" suf="" isf=0 int=90
RParen 4437:4438
RParen 4438:4439
Newline 4439:4440
Ident 4444:4451 text="println"
LParen 4451:4452
Str 4452:4501 T("  nested equal      -> ") E[Ident 4477:4491 text="abiExpectObjEq"; LParen 4491:4492; Ident 4492:4494 text="n1"; Comma 4494:4495; Ident 4496:4498 text="n2"; RParen 4498:4499; Eof 4500:4500]
RParen 4501:4502
Newline 4502:4503
Ident 4507:4514 text="println"
LParen 4514:4515
Str 4515:4572 T("  nested differs at depth 2 -> ") E[Ident 4548:4562 text="abiExpectObjEq"; LParen 4562:4563; Ident 4563:4565 text="n1"; Comma 4565:4566; Ident 4567:4569 text="n3"; RParen 4569:4570; Eof 4571:4571]
RParen 4572:4573
Newline 4573:4574
Let 4578:4581
Ident 4582:4586 text="deep"
Assign 4587:4588
Ident 4589:4594 text="list2"
LParen 4594:4595
Ident 4595:4600 text="list2"
LParen 4600:4601
Ident 4601:4606 text="list2"
LParen 4606:4607
Ident 4607:4609 text="b1"
LParen 4609:4610
Number 4610:4612 text="97" suf="" isf=0 int=97
RParen 4612:4613
Comma 4613:4614
Ident 4615:4617 text="b1"
LParen 4617:4618
Number 4618:4620 text="98" suf="" isf=0 int=98
RParen 4620:4621
RParen 4621:4622
Comma 4622:4623
Ident 4624:4626 text="b1"
LParen 4626:4627
Number 4627:4629 text="90" suf="" isf=0 int=90
RParen 4629:4630
RParen 4630:4631
Comma 4631:4632
Ident 4633:4635 text="b1"
LParen 4635:4636
Number 4636:4638 text="33" suf="" isf=0 int=33
RParen 4638:4639
RParen 4639:4640
Newline 4640:4641
Let 4645:4648
Ident 4649:4654 text="deep2"
Assign 4655:4656
Ident 4657:4662 text="list2"
LParen 4662:4663
Ident 4663:4668 text="list2"
LParen 4668:4669
Ident 4669:4674 text="list2"
LParen 4674:4675
Ident 4675:4677 text="b1"
LParen 4677:4678
Number 4678:4680 text="97" suf="" isf=0 int=97
RParen 4680:4681
Comma 4681:4682
Ident 4683:4685 text="b1"
LParen 4685:4686
Number 4686:4688 text="98" suf="" isf=0 int=98
RParen 4688:4689
RParen 4689:4690
Comma 4690:4691
Ident 4692:4694 text="b1"
LParen 4694:4695
Number 4695:4697 text="90" suf="" isf=0 int=90
RParen 4697:4698
RParen 4698:4699
Comma 4699:4700
Ident 4701:4703 text="b1"
LParen 4703:4704
Number 4704:4706 text="33" suf="" isf=0 int=33
RParen 4706:4707
RParen 4707:4708
Newline 4708:4709
Ident 4713:4720 text="println"
LParen 4720:4721
Str 4721:4776 T("  three levels equal -> ") E[Ident 4747:4761 text="abiExpectObjEq"; LParen 4761:4762; Ident 4762:4766 text="deep"; Comma 4766:4767; Ident 4768:4773 text="deep2"; RParen 4773:4774; Eof 4775:4775]
RParen 4776:4777
Newline 4777:4778
Newline 4778:4779
Ident 4783:4790 text="println"
LParen 4790:4791
Str 4791:4818 T("== obj_eq: empty lists ==")
RParen 4818:4819
Newline 4819:4820
Let 4824:4827
Ident 4828:4830 text="e1"
Assign 4831:4832
Ident 4833:4843 text="abiListNew"
LParen 4843:4844
Number 4844:4845 text="0" suf="" isf=0 int=0
RParen 4845:4846
Newline 4846:4847
Let 4851:4854
Ident 4855:4857 text="e2"
Assign 4858:4859
Ident 4860:4870 text="abiListNew"
LParen 4870:4871
Number 4871:4872 text="0" suf="" isf=0 int=0
RParen 4872:4873
Newline 4873:4874
Ident 4878:4885 text="println"
LParen 4885:4886
Str 4886:4926 T("  [] == [] -> ") E[Ident 4902:4916 text="abiExpectObjEq"; LParen 4916:4917; Ident 4917:4919 text="e1"; Comma 4919:4920; Ident 4921:4923 text="e2"; RParen 4923:4924; Eof 4925:4925]
RParen 4926:4927
Newline 4927:4928
Ident 4932:4943 text="abiListPush"
LParen 4943:4944
Ident 4944:4946 text="e2"
Comma 4946:4947
Ident 4948:4950 text="b1"
LParen 4950:4951
Number 4951:4953 text="97" suf="" isf=0 int=97
RParen 4953:4954
RParen 4954:4955
Newline 4955:4956
Ident 4960:4967 text="println"
LParen 4967:4968
Str 4968:5009 T("  [] vs [a] -> ") E[Ident 4985:4999 text="abiExpectObjEq"; LParen 4999:5000; Ident 5000:5002 text="e1"; Comma 5002:5003; Ident 5004:5006 text="e2"; RParen 5006:5007; Eof 5008:5008]
RParen 5009:5010
Newline 5010:5011
Newline 5011:5012
Ident 5016:5023 text="println"
LParen 5023:5024
Str 5024:5061 T("== obj_eq: boxes by payload bits ==")
RParen 5061:5062
Newline 5062:5063
Ident 5067:5074 text="println"
LParen 5074:5075
Str 5075:5141 T("  i64 7 == i64 7 -> ") E[Ident 5097:5111 text="abiExpectObjEq"; LParen 5111:5112; Ident 5112:5121 text="abiBoxI64"; LParen 5121:5122; Number 5122:5123 text="7" suf="" isf=0 int=7; RParen 5123:5124; Comma 5124:5125; Ident 5126:5135 text="abiBoxI64"; LParen 5135:5136; Number 5136:5137 text="7" suf="" isf=0 int=7; RParen 5137:5138; RParen 5138:5139; Eof 5140:5140]
RParen 5141:5142
Newline 5142:5143
Ident 5147:5154 text="println"
LParen 5154:5155
Str 5155:5221 T("  i64 7 == i64 8 -> ") E[Ident 5177:5191 text="abiExpectObjEq"; LParen 5191:5192; Ident 5192:5201 text="abiBoxI64"; LParen 5201:5202; Number 5202:5203 text="7" suf="" isf=0 int=7; RParen 5203:5204; Comma 5204:5205; Ident 5206:5215 text="abiBoxI64"; LParen 5215:5216; Number 5216:5217 text="8" suf="" isf=0 int=8; RParen 5217:5218; RParen 5218:5219; Eof 5220:5220]
RParen 5221:5222
Newline 5222:5223
Ident 5227:5234 text="println"
LParen 5234:5235
Str 5235:5312 T("  bool true == true -> ") E[Ident 5260:5274 text="abiExpectObjEq"; LParen 5274:5275; Ident 5275:5285 text="abiBoxBool"; LParen 5285:5286; True 5286:5290; RParen 5290:5291; Comma 5291:5292; Ident 5293:5303 text="abiBoxBool"; LParen 5303:5304; True 5304:5308; RParen 5308:5309; RParen 5309:5310; Eof 5311:5311]
RParen 5312:5313
Newline 5313:5314
Ident 5318:5325 text="println"
LParen 5325:5326
Str 5326:5405 T("  bool true == false -> ") E[Ident 5352:5366 text="abiExpectObjEq"; LParen 5366:5367; Ident 5367:5377 text="abiBoxBool"; LParen 5377:5378; True 5378:5382; RParen 5382:5383; Comma 5383:5384; Ident 5385:5395 text="abiBoxBool"; LParen 5395:5396; False 5396:5401; RParen 5401:5402; RParen 5402:5403; Eof 5404:5404]
RParen 5405:5406
Newline 5406:5407
Ident 5411:5418 text="println"
LParen 5418:5419
Str 5419:5488 T("  char x == x -> ") E[Ident 5438:5452 text="abiExpectObjEq"; LParen 5452:5453; Ident 5453:5463 text="abiBoxChar"; LParen 5463:5464; Number 5464:5467 text="120" suf="" isf=0 int=120; RParen 5467:5468; Comma 5468:5469; Ident 5470:5480 text="abiBoxChar"; LParen 5480:5481; Number 5481:5484 text="120" suf="" isf=0 int=120; RParen 5484:5485; RParen 5485:5486; Eof 5487:5487]
RParen 5488:5489
Newline 5489:5490
Ident 5494:5501 text="println"
LParen 5501:5502
Str 5502:5571 T("  char x == y -> ") E[Ident 5521:5535 text="abiExpectObjEq"; LParen 5535:5536; Ident 5536:5546 text="abiBoxChar"; LParen 5546:5547; Number 5547:5550 text="120" suf="" isf=0 int=120; RParen 5550:5551; Comma 5551:5552; Ident 5553:5563 text="abiBoxChar"; LParen 5563:5564; Number 5564:5567 text="121" suf="" isf=0 int=121; RParen 5567:5568; RParen 5568:5569; Eof 5570:5570]
RParen 5571:5572
Newline 5572:5573
Newline 5573:5574
Ident 5578:5585 text="println"
LParen 5585:5586
Str 5586:5635 T("== obj_eq: box flavours pair with themselves ==")
RParen 5635:5636
Newline 5636:5637
Newline 5716:5717
Newline 5771:5772
Ident 5776:5783 text="println"
LParen 5783:5784
Str 5784:5862 T("  i64(120) vs char(120) -> ") E[Ident 5813:5827 text="abiExpectObjEq"; LParen 5827:5828; Ident 5828:5837 text="abiBoxI64"; LParen 5837:5838; Number 5838:5841 text="120" suf="" isf=0 int=120; RParen 5841:5842; Comma 5842:5843; Ident 5844:5854 text="abiBoxChar"; LParen 5854:5855; Number 5855:5858 text="120" suf="" isf=0 int=120; RParen 5858:5859; RParen 5859:5860; Eof 5861:5861]
RParen 5862:5863
Newline 5863:5864
Ident 5868:5875 text="println"
LParen 5875:5876
Str 5876:5954 T("  char(120) vs i64(120) -> ") E[Ident 5905:5919 text="abiExpectObjEq"; LParen 5919:5920; Ident 5920:5930 text="abiBoxChar"; LParen 5930:5931; Number 5931:5934 text="120" suf="" isf=0 int=120; RParen 5934:5935; Comma 5935:5936; Ident 5937:5946 text="abiBoxI64"; LParen 5946:5947; Number 5947:5950 text="120" suf="" isf=0 int=120; RParen 5950:5951; RParen 5951:5952; Eof 5953:5953]
RParen 5954:5955
Newline 5955:5956
Newline 5956:5957
Ident 5961:5968 text="println"
LParen 5968:5969
Str 5969:6001 T("== obj_eq: mismatched kinds ==")
RParen 6001:6002
Newline 6002:6003
Ident 6007:6014 text="println"
LParen 6014:6015
Str 6015:6078 T("  string vs i64box -> ") E[Ident 6039:6053 text="abiExpectObjEq"; LParen 6053:6054; Ident 6054:6056 text="b1"; LParen 6056:6057; Number 6057:6059 text="97" suf="" isf=0 int=97; RParen 6059:6060; Comma 6060:6061; Ident 6062:6071 text="abiBoxI64"; LParen 6071:6072; Number 6072:6074 text="97" suf="" isf=0 int=97; RParen 6074:6075; RParen 6075:6076; Eof 6077:6077]
RParen 6078:6079
Newline 6079:6080
Ident 6084:6091 text="println"
LParen 6091:6092
Str 6092:6163 T("  string vs list   -> ") E[Ident 6116:6130 text="abiExpectObjEq"; LParen 6130:6131; Ident 6131:6133 text="b1"; LParen 6133:6134; Number 6134:6136 text="97" suf="" isf=0 int=97; RParen 6136:6137; Comma 6137:6138; Ident 6139:6144 text="list2"; LParen 6144:6145; Ident 6145:6147 text="b1"; LParen 6147:6148; Number 6148:6150 text="97" suf="" isf=0 int=97; RParen 6150:6151; Comma 6151:6152; Ident 6153:6155 text="b1"; LParen 6155:6156; Number 6156:6158 text="98" suf="" isf=0 int=98; RParen 6158:6159; RParen 6159:6160; RParen 6160:6161; Eof 6162:6162]
RParen 6163:6164
Newline 6164:6165
Ident 6169:6176 text="println"
LParen 6176:6177
Str 6177:6248 T("  list vs string   -> ") E[Ident 6201:6215 text="abiExpectObjEq"; LParen 6215:6216; Ident 6216:6221 text="list2"; LParen 6221:6222; Ident 6222:6224 text="b1"; LParen 6224:6225; Number 6225:6227 text="97" suf="" isf=0 int=97; RParen 6227:6228; Comma 6228:6229; Ident 6230:6232 text="b1"; LParen 6232:6233; Number 6233:6235 text="98" suf="" isf=0 int=98; RParen 6235:6236; RParen 6236:6237; Comma 6237:6238; Ident 6239:6241 text="b1"; LParen 6241:6242; Number 6242:6244 text="97" suf="" isf=0 int=97; RParen 6244:6245; RParen 6245:6246; Eof 6247:6247]
RParen 6248:6249
Newline 6249:6250
Newline 6250:6251
Ident 6255:6262 text="println"
LParen 6262:6263
Str 6263:6294 T("== str_contains: substring ==")
RParen 6294:6295
Newline 6295:6296
Let 6300:6303
Ident 6304:6309 text="hello"
Assign 6310:6311
Ident 6312:6314 text="b3"
LParen 6314:6315
Number 6315:6318 text="104" suf="" isf=0 int=104
Comma 6318:6319
Number 6320:6323 text="101" suf="" isf=0 int=101
Comma 6323:6324
Number 6325:6328 text="108" suf="" isf=0 int=108
RParen 6328:6329
Newline 6329:6330
Let 6334:6337
Ident 6338:6343 text="hell4"
Assign 6344:6345
Ident 6346:6358 text="abiStrConcat"
LParen 6358:6359
Ident 6359:6364 text="hello"
Comma 6364:6365
Ident 6366:6368 text="b1"
LParen 6368:6369
Number 6369:6372 text="108" suf="" isf=0 int=108
RParen 6372:6373
RParen 6373:6374
Newline 6374:6375
Ident 6379:6386 text="println"
LParen 6386:6387
Str 6387:6458 T("  'ell' in 'hell' -> ") E[Ident 6410:6430 text="abiExpectStrContains"; LParen 6430:6431; Ident 6431:6436 text="hell4"; Comma 6436:6437; Ident 6438:6440 text="b3"; LParen 6440:6441; Number 6441:6444 text="101" suf="" isf=0 int=101; Comma 6444:6445; Number 6446:6449 text="108" suf="" isf=0 int=108; Comma 6449:6450; Number 6451:6454 text="108" suf="" isf=0 int=108; RParen 6454:6455; RParen 6455:6456; Eof 6457:6457]
RParen 6458:6459
Newline 6459:6460
Ident 6464:6471 text="println"
LParen 6471:6472
Str 6472:6533 T("  'e' in 'hell'   -> ") E[Ident 6495:6515 text="abiExpectStrContains"; LParen 6515:6516; Ident 6516:6521 text="hell4"; Comma 6521:6522; Ident 6523:6525 text="b1"; LParen 6525:6526; Number 6526:6529 text="101" suf="" isf=0 int=101; RParen 6529:6530; RParen 6530:6531; Eof 6532:6532]
RParen 6533:6534
Newline 6534:6535
Ident 6539:6546 text="println"
LParen 6546:6547
Str 6547:6618 T("  'xyz' in 'hell' -> ") E[Ident 6570:6590 text="abiExpectStrContains"; LParen 6590:6591; Ident 6591:6596 text="hell4"; Comma 6596:6597; Ident 6598:6600 text="b3"; LParen 6600:6601; Number 6601:6604 text="120" suf="" isf=0 int=120; Comma 6604:6605; Number 6606:6609 text="121" suf="" isf=0 int=121; Comma 6609:6610; Number 6611:6614 text="122" suf="" isf=0 int=122; RParen 6614:6615; RParen 6615:6616; Eof 6617:6617]
RParen 6618:6619
Newline 6619:6620
Newline 6620:6621
Ident 6625:6632 text="println"
LParen 6632:6633
Str 6633:6665 T("== str_contains: positional ==")
RParen 6665:6666
Newline 6666:6667
Let 6671:6674
Ident 6675:6678 text="abc"
Assign 6679:6680
Ident 6681:6683 text="b3"
LParen 6683:6684
Number 6684:6686 text="97" suf="" isf=0 int=97
Comma 6686:6687
Number 6688:6690 text="98" suf="" isf=0 int=98
Comma 6690:6691
Number 6692:6694 text="99" suf="" isf=0 int=99
RParen 6694:6695
Newline 6695:6696
Ident 6700:6707 text="println"
LParen 6707:6708
Str 6708:6768 T("  'ab' in 'abc' -> ") E[Ident 6729:6749 text="abiExpectStrContains"; LParen 6749:6750; Ident 6750:6753 text="abc"; Comma 6753:6754; Ident 6755:6757 text="b2"; LParen 6757:6758; Number 6758:6760 text="97" suf="" isf=0 int=97; Comma 6760:6761; Number 6762:6764 text="98" suf="" isf=0 int=98; RParen 6764:6765; RParen 6765:6766; Eof 6767:6767]
RParen 6768:6769
Newline 6769:6770
Ident 6774:6781 text="println"
LParen 6781:6782
Str 6782:6842 T("  'bc' in 'abc' -> ") E[Ident 6803:6823 text="abiExpectStrContains"; LParen 6823:6824; Ident 6824:6827 text="abc"; Comma 6827:6828; Ident 6829:6831 text="b2"; LParen 6831:6832; Number 6832:6834 text="98" suf="" isf=0 int=98; Comma 6834:6835; Number 6836:6838 text="99" suf="" isf=0 int=99; RParen 6838:6839; RParen 6839:6840; Eof 6841:6841]
RParen 6842:6843
Newline 6843:6844
Ident 6848:6855 text="println"
LParen 6855:6856
Str 6856:6916 T("  'ba' in 'abc' -> ") E[Ident 6877:6897 text="abiExpectStrContains"; LParen 6897:6898; Ident 6898:6901 text="abc"; Comma 6901:6902; Ident 6903:6905 text="b2"; LParen 6905:6906; Number 6906:6908 text="98" suf="" isf=0 int=98; Comma 6908:6909; Number 6910:6912 text="97" suf="" isf=0 int=97; RParen 6912:6913; RParen 6913:6914; Eof 6915:6915]
RParen 6916:6917
Newline 6917:6918
Newline 6918:6919
Ident 6923:6930 text="println"
LParen 6930:6931
Str 6931:6991 T("  'bc' in 'abc' -> ") E[Ident 6952:6972 text="abiExpectStrContains"; LParen 6972:6973; Ident 6973:6976 text="abc"; Comma 6976:6977; Ident 6978:6980 text="b2"; LParen 6980:6981; Number 6981:6983 text="98" suf="" isf=0 int=98; Comma 6983:6984; Number 6985:6987 text="99" suf="" isf=0 int=99; RParen 6987:6988; RParen 6988:6989; Eof 6990:6990]
RParen 6991:6992
Newline 6992:6993
Ident 6997:7004 text="println"
LParen 7004:7005
Str 7005:7056 T("== str_contains: length guard and empty needle ==")
RParen 7056:7057
Newline 7057:7058
Ident 7062:7069 text="println"
LParen 7069:7070
Str 7070:7132 T("  'ab' in 'a'  -> ") E[Ident 7090:7110 text="abiExpectStrContains"; LParen 7110:7111; Ident 7111:7113 text="b1"; LParen 7113:7114; Number 7114:7116 text="97" suf="" isf=0 int=97; RParen 7116:7117; Comma 7117:7118; Ident 7119:7121 text="b2"; LParen 7121:7122; Number 7122:7124 text="97" suf="" isf=0 int=97; Comma 7124:7125; Number 7126:7128 text="98" suf="" isf=0 int=98; RParen 7128:7129; RParen 7129:7130; Eof 7131:7131]
RParen 7132:7133
Newline 7133:7134
Ident 7138:7145 text="println"
LParen 7145:7146
Str 7146:7212 T("  'abc' in 'a' -> ") E[Ident 7166:7186 text="abiExpectStrContains"; LParen 7186:7187; Ident 7187:7189 text="b1"; LParen 7189:7190; Number 7190:7192 text="97" suf="" isf=0 int=97; RParen 7192:7193; Comma 7193:7194; Ident 7195:7197 text="b3"; LParen 7197:7198; Number 7198:7200 text="97" suf="" isf=0 int=97; Comma 7200:7201; Number 7202:7204 text="98" suf="" isf=0 int=98; Comma 7204:7205; Number 7206:7208 text="99" suf="" isf=0 int=99; RParen 7208:7209; RParen 7209:7210; Eof 7211:7211]
RParen 7212:7213
Newline 7213:7214
Ident 7218:7225 text="println"
LParen 7225:7226
Str 7226:7279 T("  '' in 'abc'  -> ") E[Ident 7246:7266 text="abiExpectStrContains"; LParen 7266:7267; Ident 7267:7270 text="abc"; Comma 7270:7271; Ident 7272:7274 text="b0"; LParen 7274:7275; RParen 7275:7276; RParen 7276:7277; Eof 7278:7278]
RParen 7279:7280
Newline 7280:7281
Ident 7285:7292 text="println"
LParen 7292:7293
Str 7293:7347 T("  '' in ''     -> ") E[Ident 7313:7333 text="abiExpectStrContains"; LParen 7333:7334; Ident 7334:7336 text="b0"; LParen 7336:7337; RParen 7337:7338; Comma 7338:7339; Ident 7340:7342 text="b0"; LParen 7342:7343; RParen 7343:7344; RParen 7344:7345; Eof 7346:7346]
RParen 7347:7348
Newline 7348:7349
Ident 7353:7360 text="println"
LParen 7360:7361
Str 7361:7417 T("  'a' in ''    -> ") E[Ident 7381:7401 text="abiExpectStrContains"; LParen 7401:7402; Ident 7402:7404 text="b0"; LParen 7404:7405; RParen 7405:7406; Comma 7406:7407; Ident 7408:7410 text="b1"; LParen 7410:7411; Number 7411:7413 text="97" suf="" isf=0 int=97; RParen 7413:7414; RParen 7414:7415; Eof 7416:7416]
RParen 7417:7418
Newline 7418:7419
Ident 7423:7430 text="println"
LParen 7430:7431
Str 7431:7493 T("  whole string in itself -> ") E[Ident 7461:7481 text="abiExpectStrContains"; LParen 7481:7482; Ident 7482:7485 text="abc"; Comma 7485:7486; Ident 7487:7490 text="abc"; RParen 7490:7491; Eof 7492:7492]
RParen 7493:7494
Newline 7494:7495
Newline 7495:7496
Ident 7500:7507 text="println"
LParen 7507:7508
Str 7508:7556 T("== str_contains: raw bytes, not code points ==")
RParen 7556:7557
Newline 7557:7558
Newline 7639:7640
Let 7644:7647
Ident 7648:7654 text="eacute"
Assign 7655:7656
Ident 7657:7659 text="b2"
LParen 7659:7660
Number 7660:7663 text="195" suf="" isf=0 int=195
Comma 7663:7664
Number 7665:7668 text="169" suf="" isf=0 int=169
RParen 7668:7669
Newline 7669:7670
Ident 7674:7681 text="println"
LParen 7681:7682
Str 7682:7741 T("  len=") E[Ident 7690:7710 text="abiExpectStrContains"; LParen 7710:7711; Ident 7711:7717 text="eacute"; Comma 7717:7718; Ident 7719:7721 text="b1"; LParen 7721:7722; Number 7722:7725 text="195" suf="" isf=0 int=195; RParen 7725:7726; RParen 7726:7727; Eof 7728:7728] T(" for lone C3")
RParen 7741:7742
Newline 7742:7743
Ident 7747:7754 text="println"
LParen 7754:7755
Str 7755:7817 T("  len=") E[Ident 7763:7783 text="abiExpectStrContains"; LParen 7783:7784; Ident 7784:7790 text="eacute"; Comma 7790:7791; Ident 7792:7794 text="b2"; LParen 7794:7795; Number 7795:7798 text="195" suf="" isf=0 int=195; Comma 7798:7799; Number 7800:7803 text="169" suf="" isf=0 int=169; RParen 7803:7804; RParen 7804:7805; Eof 7806:7806] T(" for C3 A9")
RParen 7817:7818
Newline 7818:7819
Ident 7823:7830 text="println"
LParen 7830:7831
Str 7831:7890 T("  len=") E[Ident 7839:7859 text="abiExpectStrContains"; LParen 7859:7860; Ident 7860:7866 text="eacute"; Comma 7866:7867; Ident 7868:7870 text="b1"; LParen 7870:7871; Number 7871:7874 text="169" suf="" isf=0 int=169; RParen 7874:7875; RParen 7875:7876; Eof 7877:7877] T(" for lone A9")
RParen 7890:7891
Newline 7891:7892
Let 7896:7899
Ident 7900:7905 text="mixed"
Assign 7906:7907
Ident 7908:7910 text="b3"
LParen 7910:7911
Number 7911:7914 text="195" suf="" isf=0 int=195
Comma 7914:7915
Number 7916:7919 text="169" suf="" isf=0 int=169
Comma 7919:7920
Number 7921:7924 text="122" suf="" isf=0 int=122
RParen 7924:7925
Newline 7925:7926
Ident 7930:7937 text="println"
LParen 7937:7938
Str 7938:8010 T("  C3 at offset 0 of C3 A9 7A -> ") E[Ident 7972:7992 text="abiExpectStrContains"; LParen 7992:7993; Ident 7993:7998 text="mixed"; Comma 7998:7999; Ident 8000:8002 text="b1"; LParen 8002:8003; Number 8003:8006 text="195" suf="" isf=0 int=195; RParen 8006:8007; RParen 8007:8008; Eof 8009:8009]
RParen 8010:8011
Newline 8011:8012
Ident 8016:8023 text="println"
LParen 8023:8024
Str 8024:8100 T("  A9 7A at offset 1         -> ") E[Ident 8057:8077 text="abiExpectStrContains"; LParen 8077:8078; Ident 8078:8083 text="mixed"; Comma 8083:8084; Ident 8085:8087 text="b2"; LParen 8087:8088; Number 8088:8091 text="169" suf="" isf=0 int=169; Comma 8091:8092; Number 8093:8096 text="122" suf="" isf=0 int=122; RParen 8096:8097; RParen 8097:8098; Eof 8099:8099]
RParen 8100:8101
Newline 8101:8102
RBrace 8102:8103
Eof 8103:8103
