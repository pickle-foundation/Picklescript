Module 0:6
Ident 7:20 text="abi_list_main"
Newline 20:21
Newline 21:22
Newline 87:88
Newline 90:91
Newline 171:172
Newline 241:242
Newline 324:325
Newline 410:411
Newline 413:414
Newline 503:504
Newline 586:587
Newline 677:678
Newline 766:767
Newline 856:857
Newline 943:944
Newline 973:974
Newline 974:975
Import 975:981
LBrace 982:983
Ident 984:991 text="listNew"
Comma 991:992
Ident 993:1003 text="abiListLen"
Comma 1003:1004
Ident 1005:1015 text="abiListGet"
Comma 1015:1016
Ident 1017:1028 text="abiListPush"
Comma 1028:1029
Ident 1030:1040 text="abiListPop"
Comma 1040:1041
Ident 1042:1055 text="abiListRemove"
Comma 1055:1056
Ident 1057:1070 text="abiListInsert"
Comma 1070:1071
Ident 1072:1083 text="abiListSort"
Comma 1083:1084
Ident 1085:1093 text="abiRange"
RBrace 1094:1095
From 1096:1100
Ident 1101:1108 text="runtime"
Dot 1108:1109
Ident 1109:1117 text="abi_list"
Newline 1117:1118
Import 1118:1124
LBrace 1125:1126
Ident 1127:1136 text="abiBoxI64"
Comma 1136:1137
Ident 1138:1149 text="abiUnboxI64"
RBrace 1150:1151
From 1152:1156
Ident 1157:1164 text="runtime"
Dot 1164:1165
Ident 1165:1172 text="abi_box"
Newline 1172:1173
Newline 1173:1174
Newline 1255:1256
Fn 1256:1258 doc="Read element `i` back through the exported `pickle_list_get` ABI entry point."
Ident 1259:1261 text="at"
LParen 1261:1262
Ident 1262:1263 text="l"
Colon 1263:1264
Star 1265:1266
Ident 1266:1269 text="int"
Comma 1269:1270
Ident 1271:1272 text="i"
Colon 1272:1273
Ident 1274:1277 text="int"
RParen 1277:1278
Arrow 1279:1281
Ident 1282:1285 text="int"
LBrace 1286:1287
Newline 1287:1288
Return 1292:1298
Ident 1299:1310 text="abiUnboxI64"
LParen 1310:1311
Ident 1311:1321 text="abiListGet"
LParen 1321:1322
Ident 1322:1323 text="l"
Comma 1323:1324
Ident 1325:1326 text="i"
RParen 1326:1327
RParen 1327:1328
Newline 1328:1329
RBrace 1329:1330
Newline 1330:1331
Newline 1331:1332
Fn 1332:1334
Ident 1335:1339 text="main"
LParen 1339:1340
RParen 1340:1341
LBrace 1342:1343
Newline 1343:1344
Newline 1425:1426
Newline 1496:1497
Var 1501:1504
Ident 1505:1506 text="l"
Assign 1507:1508
Ident 1509:1516 text="listNew"
LParen 1516:1517
Number 1517:1518 text="0" suf="" isf=0 int=0
RParen 1518:1519
Newline 1519:1520
Unsafe 1524:1530
LBrace 1531:1532
Newline 1532:1533
Ident 1541:1548 text="println"
LParen 1548:1549
Str 1549:1564 T("class: ") E[Ident 1558:1559 text="l"; LBracket 1559:1560; Number 1560:1561 text="1" suf="" isf=0 int=1; RBracket 1561:1562; Eof 1563:1563]
RParen 1564:1565
Newline 1565:1566
Ident 1574:1581 text="println"
LParen 1581:1582
Str 1582:1596 T("size: ") E[Ident 1590:1591 text="l"; LBracket 1591:1592; Number 1592:1593 text="2" suf="" isf=0 int=2; RBracket 1593:1594; Eof 1595:1595]
RParen 1596:1597
Newline 1597:1598
Ident 1606:1613 text="println"
LParen 1613:1614
Str 1614:1627 T("len: ") E[Ident 1621:1622 text="l"; LBracket 1622:1623; Number 1623:1624 text="3" suf="" isf=0 int=3; RBracket 1624:1625; Eof 1626:1626]
RParen 1627:1628
Newline 1628:1629
Ident 1637:1644 text="println"
LParen 1644:1645
Str 1645:1658 T("cap: ") E[Ident 1652:1653 text="l"; LBracket 1653:1654; Number 1654:1655 text="4" suf="" isf=0 int=4; RBracket 1655:1656; Eof 1657:1657]
RParen 1658:1659
Newline 1659:1660
RBrace 1664:1665
Newline 1665:1666
Newline 1666:1667
Newline 1753:1754
Newline 1840:1841
Newline 1877:1878
Var 1882:1885
Ident 1886:1887 text="i"
Assign 1888:1889
Number 1890:1891 text="0" suf="" isf=0 int=0
Newline 1891:1892
While 1896:1901
LParen 1902:1903
Ident 1903:1904 text="i"
Lt 1905:1906
Number 1907:1909 text="20" suf="" isf=0 int=20
RParen 1909:1910
LBrace 1911:1912
Newline 1912:1913
Ident 1921:1932 text="abiListPush"
LParen 1932:1933
Ident 1933:1934 text="l"
Comma 1934:1935
Ident 1936:1945 text="abiBoxI64"
LParen 1945:1946
Ident 1946:1947 text="i"
Star 1948:1949
Number 1950:1951 text="3" suf="" isf=0 int=3
RParen 1951:1952
RParen 1952:1953
Newline 1953:1954
Ident 1962:1963 text="i"
Assign 1964:1965
Ident 1966:1967 text="i"
Plus 1968:1969
Number 1970:1971 text="1" suf="" isf=0 int=1
Newline 1971:1972
RBrace 1976:1977
Newline 1977:1978
Ident 1982:1989 text="println"
LParen 1989:1990
Str 1990:2018 T("grown len: ") E[Ident 2003:2013 text="abiListLen"; LParen 2013:2014; Ident 2014:2015 text="l"; RParen 2015:2016; Eof 2017:2017]
RParen 2018:2019
Newline 2019:2020
Var 2024:2027
Ident 2028:2031 text="sum"
Assign 2032:2033
Number 2034:2035 text="0" suf="" isf=0 int=0
Newline 2035:2036
Var 2040:2043
Ident 2044:2045 text="k"
Assign 2046:2047
Number 2048:2049 text="0" suf="" isf=0 int=0
Newline 2049:2050
While 2054:2059
LParen 2060:2061
Ident 2061:2062 text="k"
Lt 2063:2064
Number 2065:2067 text="20" suf="" isf=0 int=20
RParen 2067:2068
LBrace 2069:2070
Newline 2070:2071
Ident 2079:2082 text="sum"
Assign 2083:2084
Ident 2085:2088 text="sum"
Plus 2089:2090
Ident 2091:2093 text="at"
LParen 2093:2094
Ident 2094:2095 text="l"
Comma 2095:2096
Ident 2097:2098 text="k"
RParen 2098:2099
Newline 2099:2100
Ident 2108:2109 text="k"
Assign 2110:2111
Ident 2112:2113 text="k"
Plus 2114:2115
Number 2116:2117 text="1" suf="" isf=0 int=1
Newline 2117:2118
RBrace 2122:2123
Newline 2123:2124
Ident 2128:2135 text="println"
LParen 2135:2136
Str 2136:2154 T("grown sum: ") E[Ident 2149:2152 text="sum"; Eof 2153:2153]
RParen 2154:2155
Newline 2155:2156
Unsafe 2160:2166
LBrace 2167:2168
Newline 2168:2169
Ident 2177:2184 text="println"
LParen 2184:2185
Str 2185:2204 T("grown cap: ") E[Ident 2198:2199 text="l"; LBracket 2199:2200; Number 2200:2201 text="4" suf="" isf=0 int=4; RBracket 2201:2202; Eof 2203:2203]
RParen 2204:2205
Newline 2205:2206
RBrace 2210:2211
Newline 2211:2212
Newline 2212:2213
Newline 2289:2290
Ident 2294:2301 text="println"
LParen 2301:2302
Str 2302:2339 T("get oob: ") E[Ident 2313:2323 text="abiListGet"; LParen 2323:2324; Ident 2324:2325 text="l"; Comma 2325:2326; Number 2327:2329 text="20" suf="" isf=0 int=20; RParen 2329:2330; As 2331:2333; Ident 2334:2337 text="int"; Eof 2338:2338]
RParen 2339:2340
Newline 2340:2341
Ident 2345:2352 text="println"
LParen 2352:2353
Str 2353:2396 T("get far oob: ") E[Ident 2368:2378 text="abiListGet"; LParen 2378:2379; Ident 2379:2380 text="l"; Comma 2380:2381; Number 2382:2386 text="9999" suf="" isf=0 int=9999; RParen 2386:2387; As 2388:2390; Ident 2391:2394 text="int"; Eof 2395:2395]
RParen 2396:2397
Newline 2397:2398
Newline 2398:2399
Newline 2439:2440
Ident 2444:2451 text="println"
LParen 2451:2452
Str 2452:2492 T("pop last: ") E[Ident 2464:2475 text="abiUnboxI64"; LParen 2475:2476; Ident 2476:2486 text="abiListPop"; LParen 2486:2487; Ident 2487:2488 text="l"; RParen 2488:2489; RParen 2489:2490; Eof 2491:2491]
RParen 2492:2493
Newline 2493:2494
Ident 2498:2505 text="println"
LParen 2505:2506
Str 2506:2538 T("after pop len: ") E[Ident 2523:2533 text="abiListLen"; LParen 2533:2534; Ident 2534:2535 text="l"; RParen 2535:2536; Eof 2537:2537]
RParen 2538:2539
Newline 2539:2540
Newline 2540:2541
Newline 2600:2601
Var 2605:2608
Ident 2609:2610 text="r"
Assign 2611:2612
Ident 2613:2620 text="listNew"
LParen 2620:2621
Number 2621:2622 text="0" suf="" isf=0 int=0
RParen 2622:2623
Newline 2623:2624
Ident 2628:2639 text="abiListPush"
LParen 2639:2640
Ident 2640:2641 text="r"
Comma 2641:2642
Ident 2643:2652 text="abiBoxI64"
LParen 2652:2653
Number 2653:2655 text="10" suf="" isf=0 int=10
RParen 2655:2656
RParen 2656:2657
Newline 2657:2658
Ident 2662:2673 text="abiListPush"
LParen 2673:2674
Ident 2674:2675 text="r"
Comma 2675:2676
Ident 2677:2686 text="abiBoxI64"
LParen 2686:2687
Number 2687:2689 text="30" suf="" isf=0 int=30
RParen 2689:2690
RParen 2690:2691
Newline 2691:2692
Ident 2696:2709 text="abiListInsert"
LParen 2709:2710
Ident 2710:2711 text="r"
Comma 2711:2712
Number 2713:2714 text="1" suf="" isf=0 int=1
Comma 2714:2715
Ident 2716:2725 text="abiBoxI64"
LParen 2725:2726
Number 2726:2728 text="20" suf="" isf=0 int=20
RParen 2728:2729
RParen 2729:2730
Newline 2730:2731
Ident 2735:2742 text="println"
LParen 2742:2743
Str 2743:2774 T("inserted len: ") E[Ident 2759:2769 text="abiListLen"; LParen 2769:2770; Ident 2770:2771 text="r"; RParen 2771:2772; Eof 2773:2773]
RParen 2774:2775
Newline 2775:2776
Ident 2780:2787 text="println"
LParen 2787:2788
Str 2788:2813 T("inserted[1]: ") E[Ident 2803:2805 text="at"; LParen 2805:2806; Ident 2806:2807 text="r"; Comma 2807:2808; Number 2809:2810 text="1" suf="" isf=0 int=1; RParen 2810:2811; Eof 2812:2812]
RParen 2813:2814
Newline 2814:2815
Ident 2819:2826 text="println"
LParen 2826:2827
Str 2827:2872 T("removed: ") E[Ident 2838:2849 text="abiUnboxI64"; LParen 2849:2850; Ident 2850:2863 text="abiListRemove"; LParen 2863:2864; Ident 2864:2865 text="r"; Comma 2865:2866; Number 2867:2868 text="0" suf="" isf=0 int=0; RParen 2868:2869; RParen 2869:2870; Eof 2871:2871]
RParen 2872:2873
Newline 2873:2874
Ident 2878:2885 text="println"
LParen 2885:2886
Str 2886:2921 T("after remove len: ") E[Ident 2906:2916 text="abiListLen"; LParen 2916:2917; Ident 2917:2918 text="r"; RParen 2918:2919; Eof 2920:2920]
RParen 2921:2922
Newline 2922:2923
Ident 2927:2934 text="println"
LParen 2934:2935
Str 2935:2964 T("after remove[0]: ") E[Ident 2954:2956 text="at"; LParen 2956:2957; Ident 2957:2958 text="r"; Comma 2958:2959; Number 2960:2961 text="0" suf="" isf=0 int=0; RParen 2961:2962; Eof 2963:2963]
RParen 2964:2965
Newline 2965:2966
Newline 2966:2967
Newline 3056:3057
Var 3061:3064
Ident 3065:3066 text="s"
Assign 3067:3068
Ident 3069:3076 text="listNew"
LParen 3076:3077
Number 3077:3078 text="0" suf="" isf=0 int=0
RParen 3078:3079
Newline 3079:3080
Ident 3084:3095 text="abiListPush"
LParen 3095:3096
Ident 3096:3097 text="s"
Comma 3097:3098
Ident 3099:3108 text="abiBoxI64"
LParen 3108:3109
Number 3109:3110 text="5" suf="" isf=0 int=5
RParen 3110:3111
RParen 3111:3112
Newline 3112:3113
Ident 3117:3128 text="abiListPush"
LParen 3128:3129
Ident 3129:3130 text="s"
Comma 3130:3131
Ident 3132:3141 text="abiBoxI64"
LParen 3141:3142
Minus 3142:3143
Number 3143:3144 text="3" suf="" isf=0 int=3
RParen 3144:3145
RParen 3145:3146
Newline 3146:3147
Ident 3151:3162 text="abiListPush"
LParen 3162:3163
Ident 3163:3164 text="s"
Comma 3164:3165
Ident 3166:3175 text="abiBoxI64"
LParen 3175:3176
Number 3176:3177 text="5" suf="" isf=0 int=5
RParen 3177:3178
RParen 3178:3179
Newline 3179:3180
Ident 3184:3195 text="abiListPush"
LParen 3195:3196
Ident 3196:3197 text="s"
Comma 3197:3198
Ident 3199:3208 text="abiBoxI64"
LParen 3208:3209
Number 3209:3210 text="0" suf="" isf=0 int=0
RParen 3210:3211
RParen 3211:3212
Newline 3212:3213
Ident 3217:3228 text="abiListSort"
LParen 3228:3229
Ident 3229:3230 text="s"
Comma 3230:3231
Number 3232:3233 text="0" suf="" isf=0 int=0
RParen 3233:3234
Newline 3234:3235
Var 3239:3242
Ident 3243:3249 text="sorted"
Assign 3250:3251
Str 3252:3254
Newline 3254:3255
Var 3259:3262
Ident 3263:3264 text="m"
Assign 3265:3266
Number 3267:3268 text="0" suf="" isf=0 int=0
Newline 3268:3269
While 3273:3278
LParen 3279:3280
Ident 3280:3281 text="m"
Lt 3282:3283
Number 3284:3285 text="4" suf="" isf=0 int=4
RParen 3285:3286
LBrace 3287:3288
Newline 3288:3289
Ident 3297:3303 text="sorted"
Assign 3304:3305
Ident 3306:3312 text="sorted"
Plus 3313:3314
Str 3315:3328 E[Ident 3317:3319 text="at"; LParen 3319:3320; Ident 3320:3321 text="s"; Comma 3321:3322; Ident 3323:3324 text="m"; RParen 3324:3325; Eof 3326:3326] T(" ")
Newline 3328:3329
Ident 3337:3338 text="m"
Assign 3339:3340
Ident 3341:3342 text="m"
Plus 3343:3344
Number 3345:3346 text="1" suf="" isf=0 int=1
Newline 3346:3347
RBrace 3351:3352
Newline 3352:3353
Ident 3357:3364 text="println"
LParen 3364:3365
Str 3365:3383 T("sorted: ") E[Ident 3375:3381 text="sorted"; Eof 3382:3382]
RParen 3383:3384
Newline 3384:3385
Newline 3385:3386
Newline 3446:3447
Var 3451:3454
Ident 3455:3457 text="up"
Assign 3458:3459
Ident 3460:3468 text="abiRange"
LParen 3468:3469
Number 3469:3470 text="0" suf="" isf=0 int=0
Comma 3470:3471
Number 3472:3473 text="5" suf="" isf=0 int=5
Comma 3473:3474
Number 3475:3476 text="1" suf="" isf=0 int=1
RParen 3476:3477
Newline 3477:3478
Var 3482:3485
Ident 3486:3491 text="step3"
Assign 3492:3493
Ident 3494:3502 text="abiRange"
LParen 3502:3503
Number 3503:3504 text="2" suf="" isf=0 int=2
Comma 3504:3505
Number 3506:3508 text="11" suf="" isf=0 int=11
Comma 3508:3509
Number 3510:3511 text="3" suf="" isf=0 int=3
RParen 3511:3512
Newline 3512:3513
Var 3517:3520
Ident 3521:3525 text="down"
Assign 3526:3527
Ident 3528:3536 text="abiRange"
LParen 3536:3537
Number 3537:3538 text="5" suf="" isf=0 int=5
Comma 3538:3539
Number 3540:3541 text="0" suf="" isf=0 int=0
Comma 3541:3542
Minus 3543:3544
Number 3544:3545 text="2" suf="" isf=0 int=2
RParen 3545:3546
Newline 3546:3547
Var 3551:3554
Ident 3555:3563 text="zeroStep"
Assign 3564:3565
Ident 3566:3574 text="abiRange"
LParen 3574:3575
Number 3575:3576 text="0" suf="" isf=0 int=0
Comma 3576:3577
Number 3578:3580 text="10" suf="" isf=0 int=10
Comma 3580:3581
Number 3582:3583 text="0" suf="" isf=0 int=0
RParen 3583:3584
Newline 3584:3585
Ident 3589:3596 text="println"
LParen 3596:3597
Str 3597:3639 T("range 0..5: ") E[Ident 3611:3621 text="abiListLen"; LParen 3621:3622; Ident 3622:3624 text="up"; RParen 3624:3625; Eof 3626:3626] T(" ") E[Ident 3628:3630 text="at"; LParen 3630:3631; Ident 3631:3633 text="up"; Comma 3633:3634; Number 3635:3636 text="4" suf="" isf=0 int=4; RParen 3636:3637; Eof 3638:3638]
RParen 3639:3640
Newline 3640:3641
Ident 3645:3652 text="println"
LParen 3652:3653
Str 3653:3704 T("range 2..11/3: ") E[Ident 3670:3680 text="abiListLen"; LParen 3680:3681; Ident 3681:3686 text="step3"; RParen 3686:3687; Eof 3688:3688] T(" ") E[Ident 3690:3692 text="at"; LParen 3692:3693; Ident 3693:3698 text="step3"; Comma 3698:3699; Number 3700:3701 text="2" suf="" isf=0 int=2; RParen 3701:3702; Eof 3703:3703]
RParen 3704:3705
Newline 3705:3706
Ident 3710:3717 text="println"
LParen 3717:3718
Str 3718:3767 T("range 5..0/-2: ") E[Ident 3735:3745 text="abiListLen"; LParen 3745:3746; Ident 3746:3750 text="down"; RParen 3750:3751; Eof 3752:3752] T(" ") E[Ident 3754:3756 text="at"; LParen 3756:3757; Ident 3757:3761 text="down"; Comma 3761:3762; Number 3763:3764 text="2" suf="" isf=0 int=2; RParen 3764:3765; Eof 3766:3766]
RParen 3767:3768
Newline 3768:3769
Ident 3773:3780 text="println"
LParen 3780:3781
Str 3781:3819 T("range step 0: ") E[Ident 3797:3807 text="abiListLen"; LParen 3807:3808; Ident 3808:3816 text="zeroStep"; RParen 3816:3817; Eof 3818:3818]
RParen 3819:3820
Newline 3820:3821
Newline 3821:3822
Newline 3901:3902
Newline 3953:3954
Var 3958:3961
Ident 3962:3964 text="xs"
Assign 3965:3966
LBracket 3967:3968
Number 3968:3969 text="5" suf="" isf=0 int=5
Comma 3969:3970
Number 3971:3972 text="3" suf="" isf=0 int=3
Comma 3972:3973
Number 3974:3975 text="9" suf="" isf=0 int=9
Comma 3975:3976
Number 3977:3978 text="1" suf="" isf=0 int=1
RBracket 3978:3979
Newline 3979:3980
Ident 3984:3986 text="xs"
Dot 3986:3987
Ident 3987:3991 text="push"
LParen 3991:3992
Number 3992:3993 text="7" suf="" isf=0 int=7
RParen 3993:3994
Newline 3994:3995
Var 3999:4002
Ident 4003:4008 text="total"
Assign 4009:4010
Number 4011:4012 text="0" suf="" isf=0 int=0
Newline 4012:4013
Var 4017:4020
Ident 4021:4022 text="n"
Assign 4023:4024
Number 4025:4026 text="0" suf="" isf=0 int=0
Newline 4026:4027
While 4031:4036
LParen 4037:4038
Ident 4038:4039 text="n"
Lt 4040:4041
Ident 4042:4045 text="len"
LParen 4045:4046
Ident 4046:4048 text="xs"
RParen 4048:4049
RParen 4049:4050
LBrace 4051:4052
Newline 4052:4053
Ident 4061:4066 text="total"
Assign 4067:4068
Ident 4069:4074 text="total"
Plus 4075:4076
Ident 4077:4079 text="xs"
LBracket 4079:4080
Ident 4080:4081 text="n"
RBracket 4081:4082
Newline 4082:4083
Ident 4091:4092 text="n"
Assign 4093:4094
Ident 4095:4096 text="n"
Plus 4097:4098
Number 4099:4100 text="1" suf="" isf=0 int=1
Newline 4100:4101
RBrace 4105:4106
Newline 4106:4107
Ident 4111:4118 text="println"
LParen 4118:4119
Str 4119:4148 T("builtin list len: ") E[Ident 4139:4142 text="len"; LParen 4142:4143; Ident 4143:4145 text="xs"; RParen 4145:4146; Eof 4147:4147]
RParen 4148:4149
Newline 4149:4150
Ident 4154:4161 text="println"
LParen 4161:4162
Str 4162:4189 T("builtin list sum: ") E[Ident 4182:4187 text="total"; Eof 4188:4188]
RParen 4189:4190
Newline 4190:4191
RBrace 4191:4192
Newline 4192:4193
Eof 4193:4193
