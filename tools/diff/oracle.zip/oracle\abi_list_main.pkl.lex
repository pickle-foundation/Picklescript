Module 0:6
Ident 7:20 text="abi_list_main"
Newline 21:22
Newline 23:24
Newline 90:91
Newline 94:95
Newline 176:177
Newline 247:248
Newline 331:332
Newline 418:419
Newline 422:423
Newline 513:514
Newline 597:598
Newline 689:690
Newline 779:780
Newline 870:871
Newline 958:959
Newline 989:990
Newline 991:992
Import 992:998
LBrace 999:1000
Ident 1001:1008 text="listNew"
Comma 1008:1009
Ident 1010:1020 text="abiListLen"
Comma 1020:1021
Ident 1022:1032 text="abiListGet"
Comma 1032:1033
Ident 1034:1045 text="abiListPush"
Comma 1045:1046
Ident 1047:1057 text="abiListPop"
Comma 1057:1058
Ident 1059:1072 text="abiListRemove"
Comma 1072:1073
Ident 1074:1087 text="abiListInsert"
Comma 1087:1088
Ident 1089:1100 text="abiListSort"
Comma 1100:1101
Ident 1102:1110 text="abiRange"
RBrace 1111:1112
From 1113:1117
Ident 1118:1125 text="runtime"
Dot 1125:1126
Ident 1126:1134 text="abi_list"
Newline 1135:1136
Import 1136:1142
LBrace 1143:1144
Ident 1145:1154 text="abiBoxI64"
Comma 1154:1155
Ident 1156:1167 text="abiUnboxI64"
RBrace 1168:1169
From 1170:1174
Ident 1175:1182 text="runtime"
Dot 1182:1183
Ident 1183:1190 text="abi_box"
Newline 1191:1192
Newline 1193:1194
Newline 1276:1277
Fn 1277:1279 doc="Read element `i` back through the exported `pickle_list_get` ABI entry point."
Ident 1280:1282 text="at"
LParen 1282:1283
Ident 1283:1284 text="l"
Colon 1284:1285
Star 1286:1287
Ident 1287:1290 text="int"
Comma 1290:1291
Ident 1292:1293 text="i"
Colon 1293:1294
Ident 1295:1298 text="int"
RParen 1298:1299
Arrow 1300:1302
Ident 1303:1306 text="int"
LBrace 1307:1308
Newline 1309:1310
Return 1314:1320
Ident 1321:1332 text="abiUnboxI64"
LParen 1332:1333
Ident 1333:1343 text="abiListGet"
LParen 1343:1344
Ident 1344:1345 text="l"
Comma 1345:1346
Ident 1347:1348 text="i"
RParen 1348:1349
RParen 1349:1350
Newline 1351:1352
RBrace 1352:1353
Newline 1354:1355
Newline 1356:1357
Fn 1357:1359
Ident 1360:1364 text="main"
LParen 1364:1365
RParen 1365:1366
LBrace 1367:1368
Newline 1369:1370
Newline 1452:1453
Newline 1524:1525
Var 1529:1532
Ident 1533:1534 text="l"
Assign 1535:1536
Ident 1537:1544 text="listNew"
LParen 1544:1545
Number 1545:1546 text="0" suf="" isf=0 int=0
RParen 1546:1547
Newline 1548:1549
Unsafe 1553:1559
LBrace 1560:1561
Newline 1562:1563
Ident 1571:1578 text="println"
LParen 1578:1579
Str 1579:1594 T("class: ") E[Ident 1588:1589 text="l"; LBracket 1589:1590; Number 1590:1591 text="1" suf="" isf=0 int=1; RBracket 1591:1592; Eof 1593:1593]
RParen 1594:1595
Newline 1596:1597
Ident 1605:1612 text="println"
LParen 1612:1613
Str 1613:1627 T("size: ") E[Ident 1621:1622 text="l"; LBracket 1622:1623; Number 1623:1624 text="2" suf="" isf=0 int=2; RBracket 1624:1625; Eof 1626:1626]
RParen 1627:1628
Newline 1629:1630
Ident 1638:1645 text="println"
LParen 1645:1646
Str 1646:1659 T("len: ") E[Ident 1653:1654 text="l"; LBracket 1654:1655; Number 1655:1656 text="3" suf="" isf=0 int=3; RBracket 1656:1657; Eof 1658:1658]
RParen 1659:1660
Newline 1661:1662
Ident 1670:1677 text="println"
LParen 1677:1678
Str 1678:1691 T("cap: ") E[Ident 1685:1686 text="l"; LBracket 1686:1687; Number 1687:1688 text="4" suf="" isf=0 int=4; RBracket 1688:1689; Eof 1690:1690]
RParen 1691:1692
Newline 1693:1694
RBrace 1698:1699
Newline 1700:1701
Newline 1702:1703
Newline 1790:1791
Newline 1878:1879
Newline 1916:1917
Var 1921:1924
Ident 1925:1926 text="i"
Assign 1927:1928
Number 1929:1930 text="0" suf="" isf=0 int=0
Newline 1931:1932
While 1936:1941
LParen 1942:1943
Ident 1943:1944 text="i"
Lt 1945:1946
Number 1947:1949 text="20" suf="" isf=0 int=20
RParen 1949:1950
LBrace 1951:1952
Newline 1953:1954
Ident 1962:1973 text="abiListPush"
LParen 1973:1974
Ident 1974:1975 text="l"
Comma 1975:1976
Ident 1977:1986 text="abiBoxI64"
LParen 1986:1987
Ident 1987:1988 text="i"
Star 1989:1990
Number 1991:1992 text="3" suf="" isf=0 int=3
RParen 1992:1993
RParen 1993:1994
Newline 1995:1996
Ident 2004:2005 text="i"
Assign 2006:2007
Ident 2008:2009 text="i"
Plus 2010:2011
Number 2012:2013 text="1" suf="" isf=0 int=1
Newline 2014:2015
RBrace 2019:2020
Newline 2021:2022
Ident 2026:2033 text="println"
LParen 2033:2034
Str 2034:2062 T("grown len: ") E[Ident 2047:2057 text="abiListLen"; LParen 2057:2058; Ident 2058:2059 text="l"; RParen 2059:2060; Eof 2061:2061]
RParen 2062:2063
Newline 2064:2065
Var 2069:2072
Ident 2073:2076 text="sum"
Assign 2077:2078
Number 2079:2080 text="0" suf="" isf=0 int=0
Newline 2081:2082
Var 2086:2089
Ident 2090:2091 text="k"
Assign 2092:2093
Number 2094:2095 text="0" suf="" isf=0 int=0
Newline 2096:2097
While 2101:2106
LParen 2107:2108
Ident 2108:2109 text="k"
Lt 2110:2111
Number 2112:2114 text="20" suf="" isf=0 int=20
RParen 2114:2115
LBrace 2116:2117
Newline 2118:2119
Ident 2127:2130 text="sum"
Assign 2131:2132
Ident 2133:2136 text="sum"
Plus 2137:2138
Ident 2139:2141 text="at"
LParen 2141:2142
Ident 2142:2143 text="l"
Comma 2143:2144
Ident 2145:2146 text="k"
RParen 2146:2147
Newline 2148:2149
Ident 2157:2158 text="k"
Assign 2159:2160
Ident 2161:2162 text="k"
Plus 2163:2164
Number 2165:2166 text="1" suf="" isf=0 int=1
Newline 2167:2168
RBrace 2172:2173
Newline 2174:2175
Ident 2179:2186 text="println"
LParen 2186:2187
Str 2187:2205 T("grown sum: ") E[Ident 2200:2203 text="sum"; Eof 2204:2204]
RParen 2205:2206
Newline 2207:2208
Unsafe 2212:2218
LBrace 2219:2220
Newline 2221:2222
Ident 2230:2237 text="println"
LParen 2237:2238
Str 2238:2257 T("grown cap: ") E[Ident 2251:2252 text="l"; LBracket 2252:2253; Number 2253:2254 text="4" suf="" isf=0 int=4; RBracket 2254:2255; Eof 2256:2256]
RParen 2257:2258
Newline 2259:2260
RBrace 2264:2265
Newline 2266:2267
Newline 2268:2269
Newline 2346:2347
Ident 2351:2358 text="println"
LParen 2358:2359
Str 2359:2396 T("get oob: ") E[Ident 2370:2380 text="abiListGet"; LParen 2380:2381; Ident 2381:2382 text="l"; Comma 2382:2383; Number 2384:2386 text="20" suf="" isf=0 int=20; RParen 2386:2387; As 2388:2390; Ident 2391:2394 text="int"; Eof 2395:2395]
RParen 2396:2397
Newline 2398:2399
Ident 2403:2410 text="println"
LParen 2410:2411
Str 2411:2454 T("get far oob: ") E[Ident 2426:2436 text="abiListGet"; LParen 2436:2437; Ident 2437:2438 text="l"; Comma 2438:2439; Number 2440:2444 text="9999" suf="" isf=0 int=9999; RParen 2444:2445; As 2446:2448; Ident 2449:2452 text="int"; Eof 2453:2453]
RParen 2454:2455
Newline 2456:2457
Newline 2458:2459
Newline 2500:2501
Ident 2505:2512 text="println"
LParen 2512:2513
Str 2513:2553 T("pop last: ") E[Ident 2525:2536 text="abiUnboxI64"; LParen 2536:2537; Ident 2537:2547 text="abiListPop"; LParen 2547:2548; Ident 2548:2549 text="l"; RParen 2549:2550; RParen 2550:2551; Eof 2552:2552]
RParen 2553:2554
Newline 2555:2556
Ident 2560:2567 text="println"
LParen 2567:2568
Str 2568:2600 T("after pop len: ") E[Ident 2585:2595 text="abiListLen"; LParen 2595:2596; Ident 2596:2597 text="l"; RParen 2597:2598; Eof 2599:2599]
RParen 2600:2601
Newline 2602:2603
Newline 2604:2605
Newline 2665:2666
Var 2670:2673
Ident 2674:2675 text="r"
Assign 2676:2677
Ident 2678:2685 text="listNew"
LParen 2685:2686
Number 2686:2687 text="0" suf="" isf=0 int=0
RParen 2687:2688
Newline 2689:2690
Ident 2694:2705 text="abiListPush"
LParen 2705:2706
Ident 2706:2707 text="r"
Comma 2707:2708
Ident 2709:2718 text="abiBoxI64"
LParen 2718:2719
Number 2719:2721 text="10" suf="" isf=0 int=10
RParen 2721:2722
RParen 2722:2723
Newline 2724:2725
Ident 2729:2740 text="abiListPush"
LParen 2740:2741
Ident 2741:2742 text="r"
Comma 2742:2743
Ident 2744:2753 text="abiBoxI64"
LParen 2753:2754
Number 2754:2756 text="30" suf="" isf=0 int=30
RParen 2756:2757
RParen 2757:2758
Newline 2759:2760
Ident 2764:2777 text="abiListInsert"
LParen 2777:2778
Ident 2778:2779 text="r"
Comma 2779:2780
Number 2781:2782 text="1" suf="" isf=0 int=1
Comma 2782:2783
Ident 2784:2793 text="abiBoxI64"
LParen 2793:2794
Number 2794:2796 text="20" suf="" isf=0 int=20
RParen 2796:2797
RParen 2797:2798
Newline 2799:2800
Ident 2804:2811 text="println"
LParen 2811:2812
Str 2812:2843 T("inserted len: ") E[Ident 2828:2838 text="abiListLen"; LParen 2838:2839; Ident 2839:2840 text="r"; RParen 2840:2841; Eof 2842:2842]
RParen 2843:2844
Newline 2845:2846
Ident 2850:2857 text="println"
LParen 2857:2858
Str 2858:2883 T("inserted[1]: ") E[Ident 2873:2875 text="at"; LParen 2875:2876; Ident 2876:2877 text="r"; Comma 2877:2878; Number 2879:2880 text="1" suf="" isf=0 int=1; RParen 2880:2881; Eof 2882:2882]
RParen 2883:2884
Newline 2885:2886
Ident 2890:2897 text="println"
LParen 2897:2898
Str 2898:2943 T("removed: ") E[Ident 2909:2920 text="abiUnboxI64"; LParen 2920:2921; Ident 2921:2934 text="abiListRemove"; LParen 2934:2935; Ident 2935:2936 text="r"; Comma 2936:2937; Number 2938:2939 text="0" suf="" isf=0 int=0; RParen 2939:2940; RParen 2940:2941; Eof 2942:2942]
RParen 2943:2944
Newline 2945:2946
Ident 2950:2957 text="println"
LParen 2957:2958
Str 2958:2993 T("after remove len: ") E[Ident 2978:2988 text="abiListLen"; LParen 2988:2989; Ident 2989:2990 text="r"; RParen 2990:2991; Eof 2992:2992]
RParen 2993:2994
Newline 2995:2996
Ident 3000:3007 text="println"
LParen 3007:3008
Str 3008:3037 T("after remove[0]: ") E[Ident 3027:3029 text="at"; LParen 3029:3030; Ident 3030:3031 text="r"; Comma 3031:3032; Number 3033:3034 text="0" suf="" isf=0 int=0; RParen 3034:3035; Eof 3036:3036]
RParen 3037:3038
Newline 3039:3040
Newline 3041:3042
Newline 3132:3133
Var 3137:3140
Ident 3141:3142 text="s"
Assign 3143:3144
Ident 3145:3152 text="listNew"
LParen 3152:3153
Number 3153:3154 text="0" suf="" isf=0 int=0
RParen 3154:3155
Newline 3156:3157
Ident 3161:3172 text="abiListPush"
LParen 3172:3173
Ident 3173:3174 text="s"
Comma 3174:3175
Ident 3176:3185 text="abiBoxI64"
LParen 3185:3186
Number 3186:3187 text="5" suf="" isf=0 int=5
RParen 3187:3188
RParen 3188:3189
Newline 3190:3191
Ident 3195:3206 text="abiListPush"
LParen 3206:3207
Ident 3207:3208 text="s"
Comma 3208:3209
Ident 3210:3219 text="abiBoxI64"
LParen 3219:3220
Minus 3220:3221
Number 3221:3222 text="3" suf="" isf=0 int=3
RParen 3222:3223
RParen 3223:3224
Newline 3225:3226
Ident 3230:3241 text="abiListPush"
LParen 3241:3242
Ident 3242:3243 text="s"
Comma 3243:3244
Ident 3245:3254 text="abiBoxI64"
LParen 3254:3255
Number 3255:3256 text="5" suf="" isf=0 int=5
RParen 3256:3257
RParen 3257:3258
Newline 3259:3260
Ident 3264:3275 text="abiListPush"
LParen 3275:3276
Ident 3276:3277 text="s"
Comma 3277:3278
Ident 3279:3288 text="abiBoxI64"
LParen 3288:3289
Number 3289:3290 text="0" suf="" isf=0 int=0
RParen 3290:3291
RParen 3291:3292
Newline 3293:3294
Ident 3298:3309 text="abiListSort"
LParen 3309:3310
Ident 3310:3311 text="s"
Comma 3311:3312
Number 3313:3314 text="0" suf="" isf=0 int=0
RParen 3314:3315
Newline 3316:3317
Var 3321:3324
Ident 3325:3331 text="sorted"
Assign 3332:3333
Str 3334:3336
Newline 3337:3338
Var 3342:3345
Ident 3346:3347 text="m"
Assign 3348:3349
Number 3350:3351 text="0" suf="" isf=0 int=0
Newline 3352:3353
While 3357:3362
LParen 3363:3364
Ident 3364:3365 text="m"
Lt 3366:3367
Number 3368:3369 text="4" suf="" isf=0 int=4
RParen 3369:3370
LBrace 3371:3372
Newline 3373:3374
Ident 3382:3388 text="sorted"
Assign 3389:3390
Ident 3391:3397 text="sorted"
Plus 3398:3399
Str 3400:3413 E[Ident 3402:3404 text="at"; LParen 3404:3405; Ident 3405:3406 text="s"; Comma 3406:3407; Ident 3408:3409 text="m"; RParen 3409:3410; Eof 3411:3411] T(" ")
Newline 3414:3415
Ident 3423:3424 text="m"
Assign 3425:3426
Ident 3427:3428 text="m"
Plus 3429:3430
Number 3431:3432 text="1" suf="" isf=0 int=1
Newline 3433:3434
RBrace 3438:3439
Newline 3440:3441
Ident 3445:3452 text="println"
LParen 3452:3453
Str 3453:3471 T("sorted: ") E[Ident 3463:3469 text="sorted"; Eof 3470:3470]
RParen 3471:3472
Newline 3473:3474
Newline 3475:3476
Newline 3537:3538
Var 3542:3545
Ident 3546:3548 text="up"
Assign 3549:3550
Ident 3551:3559 text="abiRange"
LParen 3559:3560
Number 3560:3561 text="0" suf="" isf=0 int=0
Comma 3561:3562
Number 3563:3564 text="5" suf="" isf=0 int=5
Comma 3564:3565
Number 3566:3567 text="1" suf="" isf=0 int=1
RParen 3567:3568
Newline 3569:3570
Var 3574:3577
Ident 3578:3583 text="step3"
Assign 3584:3585
Ident 3586:3594 text="abiRange"
LParen 3594:3595
Number 3595:3596 text="2" suf="" isf=0 int=2
Comma 3596:3597
Number 3598:3600 text="11" suf="" isf=0 int=11
Comma 3600:3601
Number 3602:3603 text="3" suf="" isf=0 int=3
RParen 3603:3604
Newline 3605:3606
Var 3610:3613
Ident 3614:3618 text="down"
Assign 3619:3620
Ident 3621:3629 text="abiRange"
LParen 3629:3630
Number 3630:3631 text="5" suf="" isf=0 int=5
Comma 3631:3632
Number 3633:3634 text="0" suf="" isf=0 int=0
Comma 3634:3635
Minus 3636:3637
Number 3637:3638 text="2" suf="" isf=0 int=2
RParen 3638:3639
Newline 3640:3641
Var 3645:3648
Ident 3649:3657 text="zeroStep"
Assign 3658:3659
Ident 3660:3668 text="abiRange"
LParen 3668:3669
Number 3669:3670 text="0" suf="" isf=0 int=0
Comma 3670:3671
Number 3672:3674 text="10" suf="" isf=0 int=10
Comma 3674:3675
Number 3676:3677 text="0" suf="" isf=0 int=0
RParen 3677:3678
Newline 3679:3680
Ident 3684:3691 text="println"
LParen 3691:3692
Str 3692:3734 T("range 0..5: ") E[Ident 3706:3716 text="abiListLen"; LParen 3716:3717; Ident 3717:3719 text="up"; RParen 3719:3720; Eof 3721:3721] T(" ") E[Ident 3723:3725 text="at"; LParen 3725:3726; Ident 3726:3728 text="up"; Comma 3728:3729; Number 3730:3731 text="4" suf="" isf=0 int=4; RParen 3731:3732; Eof 3733:3733]
RParen 3734:3735
Newline 3736:3737
Ident 3741:3748 text="println"
LParen 3748:3749
Str 3749:3800 T("range 2..11/3: ") E[Ident 3766:3776 text="abiListLen"; LParen 3776:3777; Ident 3777:3782 text="step3"; RParen 3782:3783; Eof 3784:3784] T(" ") E[Ident 3786:3788 text="at"; LParen 3788:3789; Ident 3789:3794 text="step3"; Comma 3794:3795; Number 3796:3797 text="2" suf="" isf=0 int=2; RParen 3797:3798; Eof 3799:3799]
RParen 3800:3801
Newline 3802:3803
Ident 3807:3814 text="println"
LParen 3814:3815
Str 3815:3864 T("range 5..0/-2: ") E[Ident 3832:3842 text="abiListLen"; LParen 3842:3843; Ident 3843:3847 text="down"; RParen 3847:3848; Eof 3849:3849] T(" ") E[Ident 3851:3853 text="at"; LParen 3853:3854; Ident 3854:3858 text="down"; Comma 3858:3859; Number 3860:3861 text="2" suf="" isf=0 int=2; RParen 3861:3862; Eof 3863:3863]
RParen 3864:3865
Newline 3866:3867
Ident 3871:3878 text="println"
LParen 3878:3879
Str 3879:3917 T("range step 0: ") E[Ident 3895:3905 text="abiListLen"; LParen 3905:3906; Ident 3906:3914 text="zeroStep"; RParen 3914:3915; Eof 3916:3916]
RParen 3917:3918
Newline 3919:3920
Newline 3921:3922
Newline 4002:4003
Newline 4055:4056
Var 4060:4063
Ident 4064:4066 text="xs"
Assign 4067:4068
LBracket 4069:4070
Number 4070:4071 text="5" suf="" isf=0 int=5
Comma 4071:4072
Number 4073:4074 text="3" suf="" isf=0 int=3
Comma 4074:4075
Number 4076:4077 text="9" suf="" isf=0 int=9
Comma 4077:4078
Number 4079:4080 text="1" suf="" isf=0 int=1
RBracket 4080:4081
Newline 4082:4083
Ident 4087:4089 text="xs"
Dot 4089:4090
Ident 4090:4094 text="push"
LParen 4094:4095
Number 4095:4096 text="7" suf="" isf=0 int=7
RParen 4096:4097
Newline 4098:4099
Var 4103:4106
Ident 4107:4112 text="total"
Assign 4113:4114
Number 4115:4116 text="0" suf="" isf=0 int=0
Newline 4117:4118
Var 4122:4125
Ident 4126:4127 text="n"
Assign 4128:4129
Number 4130:4131 text="0" suf="" isf=0 int=0
Newline 4132:4133
While 4137:4142
LParen 4143:4144
Ident 4144:4145 text="n"
Lt 4146:4147
Ident 4148:4151 text="len"
LParen 4151:4152
Ident 4152:4154 text="xs"
RParen 4154:4155
RParen 4155:4156
LBrace 4157:4158
Newline 4159:4160
Ident 4168:4173 text="total"
Assign 4174:4175
Ident 4176:4181 text="total"
Plus 4182:4183
Ident 4184:4186 text="xs"
LBracket 4186:4187
Ident 4187:4188 text="n"
RBracket 4188:4189
Newline 4190:4191
Ident 4199:4200 text="n"
Assign 4201:4202
Ident 4203:4204 text="n"
Plus 4205:4206
Number 4207:4208 text="1" suf="" isf=0 int=1
Newline 4209:4210
RBrace 4214:4215
Newline 4216:4217
Ident 4221:4228 text="println"
LParen 4228:4229
Str 4229:4258 T("builtin list len: ") E[Ident 4249:4252 text="len"; LParen 4252:4253; Ident 4253:4255 text="xs"; RParen 4255:4256; Eof 4257:4257]
RParen 4258:4259
Newline 4260:4261
Ident 4265:4272 text="println"
LParen 4272:4273
Str 4273:4300 T("builtin list sum: ") E[Ident 4293:4298 text="total"; Eof 4299:4299]
RParen 4300:4301
Newline 4302:4303
RBrace 4303:4304
Newline 4305:4306
Eof 4306:4306
