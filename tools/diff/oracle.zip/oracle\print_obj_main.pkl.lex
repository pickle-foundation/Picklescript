Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Class 13:18
Ident 19:24 text="Point"
LBrace 25:26
Newline 26:27
Var 31:34
Ident 35:36 text="x"
Assign 37:38
Number 39:40 text="0" suf="" isf=0 int=0
Newline 40:41
Var 45:48
Ident 49:50 text="y"
Assign 51:52
Number 53:54 text="0" suf="" isf=0 int=0
Newline 54:55
RBrace 55:56
Newline 56:57
Newline 57:58
Enum 58:62
Ident 63:68 text="Color"
LBrace 69:70
Newline 70:71
Ident 75:78 text="Red"
Newline 78:79
Ident 83:88 text="Green"
Newline 88:89
Ident 93:97 text="Blue"
LParen 97:98
Ident 98:99 text="v"
Colon 99:100
Ident 101:104 text="int"
RParen 104:105
Newline 105:106
RBrace 106:107
Newline 107:108
Newline 108:109
Newline 189:190
Newline 252:253
Fn 253:255 doc="A generic parameter has no static rep, so the argument is boxed. That is the\nonly way to reach the BOX_* arms of print_obj from source."
Ident 256:260 text="show"
Lt 260:261
Ident 261:262 text="T"
Gt 262:263
LParen 263:264
Ident 264:265 text="x"
Colon 265:266
Ident 267:268 text="T"
RParen 268:269
LBrace 270:271
Newline 271:272
Ident 276:281 text="print"
LParen 281:282
Ident 282:283 text="x"
RParen 283:284
Newline 284:285
Ident 289:296 text="println"
LParen 296:297
Str 297:299
RParen 299:300
Newline 300:301
RBrace 301:302
Newline 302:303
Newline 303:304
Fn 304:306
Ident 307:311 text="main"
LParen 311:312
RParen 312:313
LBrace 314:315
Newline 315:316
Ident 320:325 text="print"
LParen 325:326
Str 326:333 T("hello")
RParen 333:334
Newline 334:335
Ident 339:346 text="println"
LParen 346:347
Str 347:349
RParen 349:350
Newline 350:351
Ident 355:360 text="print"
LParen 360:361
Str 361:363
RParen 363:364
Newline 364:365
Var 369:372
Ident 373:375 text="xs"
Colon 375:376
Ident 377:381 text="List"
Lt 381:382
Ident 382:385 text="int"
Gt 385:386
Assign 387:388
LBracket 389:390
Number 390:391 text="1" suf="" isf=0 int=1
Comma 391:392
Number 393:394 text="2" suf="" isf=0 int=2
Comma 394:395
Number 396:397 text="3" suf="" isf=0 int=3
RBracket 397:398
Newline 398:399
Ident 403:408 text="print"
LParen 408:409
Ident 409:411 text="xs"
RParen 411:412
Newline 412:413
Ident 417:424 text="println"
LParen 424:425
Str 425:427
RParen 427:428
Newline 428:429
Var 433:436
Ident 437:439 text="es"
Assign 440:441
Ident 442:447 text="range"
LParen 447:448
Number 448:449 text="0" suf="" isf=0 int=0
RParen 449:450
Newline 450:451
Ident 455:460 text="print"
LParen 460:461
Ident 461:463 text="es"
RParen 463:464
Newline 464:465
Ident 469:476 text="println"
LParen 476:477
Str 477:479
RParen 479:480
Newline 480:481
Var 485:488
Ident 489:490 text="m"
Colon 490:491
Ident 492:495 text="Map"
Lt 495:496
Ident 496:502 text="string"
Comma 502:503
Ident 504:507 text="int"
Gt 507:508
Assign 509:510
LBrace 511:512
Str 512:515 T("a")
Colon 515:516
Number 517:518 text="1" suf="" isf=0 int=1
Comma 518:519
Str 520:523 T("b")
Colon 523:524
Number 525:526 text="2" suf="" isf=0 int=2
RBrace 526:527
Newline 527:528
Ident 532:537 text="print"
LParen 537:538
Ident 538:539 text="m"
RParen 539:540
Newline 540:541
Ident 545:552 text="println"
LParen 552:553
Str 553:555
RParen 555:556
Newline 556:557
Ident 561:566 text="print"
LParen 566:567
Ident 567:572 text="Color"
Dot 572:573
Ident 573:576 text="Red"
RParen 576:577
Newline 577:578
Ident 582:589 text="println"
LParen 589:590
Str 590:592
RParen 592:593
Newline 593:594
Ident 598:603 text="print"
LParen 603:604
Ident 604:609 text="Color"
Dot 609:610
Ident 610:615 text="Green"
RParen 615:616
Newline 616:617
Ident 621:628 text="println"
LParen 628:629
Str 629:631
RParen 631:632
Newline 632:633
Ident 637:642 text="print"
LParen 642:643
Ident 643:648 text="Color"
Dot 648:649
Ident 649:653 text="Blue"
LParen 653:654
Number 654:655 text="7" suf="" isf=0 int=7
RParen 655:656
RParen 656:657
Newline 657:658
Ident 662:669 text="println"
LParen 669:670
Str 670:672
RParen 672:673
Newline 673:674
Var 678:681
Ident 682:684 text="ts"
Colon 684:685
Ident 686:690 text="List"
Lt 690:691
LParen 691:692
Ident 692:695 text="int"
Comma 695:696
Ident 697:703 text="string"
RParen 703:704
Gt 704:705
Assign 706:707
LBracket 708:709
LParen 709:710
Number 710:711 text="1" suf="" isf=0 int=1
Comma 711:712
Str 713:716 T("a")
RParen 716:717
Comma 717:718
LParen 719:720
Number 720:721 text="2" suf="" isf=0 int=2
Comma 721:722
Str 723:726 T("b")
RParen 726:727
RBracket 727:728
Newline 728:729
Ident 733:738 text="print"
LParen 738:739
Ellipsis 739:742
Ident 742:744 text="ts"
RParen 744:745
Newline 745:746
Ident 750:757 text="println"
LParen 757:758
Str 758:760
RParen 760:761
Newline 761:762
Var 766:769
Ident 770:771 text="p"
Assign 772:773
Ident 774:779 text="Point"
LParen 779:780
RParen 780:781
Newline 781:782
Ident 786:787 text="p"
Dot 787:788
Ident 788:789 text="x"
Assign 790:791
Number 792:793 text="3" suf="" isf=0 int=3
Newline 793:794
Ident 798:803 text="print"
LParen 803:804
Ident 804:805 text="p"
RParen 805:806
Newline 806:807
Ident 811:818 text="println"
LParen 818:819
Str 819:821
RParen 821:822
Newline 822:823
Ident 827:831 text="show"
LParen 831:832
Number 832:834 text="42" suf="" isf=0 int=42
RParen 834:835
Newline 835:836
Ident 840:844 text="show"
LParen 844:845
Minus 845:846
Number 846:848 text="42" suf="" isf=0 int=42
RParen 848:849
Newline 849:850
Ident 854:858 text="show"
LParen 858:859
Number 859:863 text="1.25" suf="" isf=1 int=-
RParen 863:864
Newline 864:865
Ident 869:873 text="show"
LParen 873:874
Number 874:877 text="0.1" suf="" isf=1 int=-
RParen 877:878
Newline 878:879
Ident 883:887 text="show"
LParen 887:888
Minus 888:889
Number 889:892 text="0.0" suf="" isf=1 int=-
RParen 892:893
Newline 893:894
Ident 898:902 text="show"
LParen 902:903
Number 903:908 text="1e308" suf="" isf=1 int=-
Star 909:910
Number 911:915 text="10.0" suf="" isf=1 int=-
RParen 915:916
Newline 916:917
Ident 921:925 text="show"
LParen 925:926
True 926:930
RParen 930:931
Newline 931:932
Ident 936:940 text="show"
LParen 940:941
False 941:946
RParen 946:947
Newline 947:948
Ident 952:956 text="show"
LParen 956:957
Char 957:960 ch='q' int=113
RParen 960:961
Newline 961:962
Ident 966:970 text="show"
LParen 970:971
Char 971:974 ch='Z' int=90
RParen 974:975
Newline 975:976
Ident 980:984 text="show"
LParen 984:985
Str 985:995 T("é")
RParen 995:996
Newline 996:997
RBrace 997:998
Newline 998:999
Eof 999:999
